import { useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, Briefcase, MessagesSquare, Octagon, ScanSearch, SlidersHorizontal } from "lucide-react";
import { BookView, DeskView, JournalView, Modal, ScannerView, SettingsView } from "@/components/desk/views";
import { decide } from "@/lib/desk/agents";
import { fmtUsd, signedClass } from "@/lib/desk/format";
import { fetchEnrichment, fetchPacket, fetchUniverse } from "@/lib/desk/market";
import { dampenersFromMemory, rankUniverse, withStatus } from "@/lib/desk/scanner";
import { accountNav, pricesFrom, useDesk } from "@/lib/desk/store";
import type { MarketPacket, ScoredSymbol, UniverseSnapshot } from "@/lib/desk/types";
import { uid } from "@/lib/desk/math";

type ViewId = "scan" | "desk" | "book" | "journal" | "settings";

const NAV: { id: ViewId; label: string; icon: typeof ScanSearch }[] = [
  { id: "scan", label: "Scanner", icon: ScanSearch },
  { id: "desk", label: "Desk", icon: MessagesSquare },
  { id: "book", label: "Book", icon: Briefcase },
  { id: "journal", label: "Journal", icon: BookOpen },
  { id: "settings", label: "Settings", icon: SlidersHorizontal },
];

const inflight = new Set<string>();

export function DeskApp({ initial }: { initial: UniverseSnapshot }) {
  const [view, setView] = useState<ViewId>("scan");
  const [rows, setRows] = useState(initial.rows);
  const [note, setNote] = useState(initial.note);
  const [venue, setVenue] = useState(initial.venue);
  const [fetchedAt, setFetchedAt] = useState(initial.fetchedAt);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState(initial.error ?? "");
  const [query, setQuery] = useState("");
  const [showAll, setShowAll] = useState(false);
  const [killOpen, setKillOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [packet, setPacket] = useState<MarketPacket | null>(null);
  const busy = useRef(false);
  const lastAuto = useRef("");

  const settings = useDesk((s) => s.settings);
  const equity = useDesk((s) => s.equity);
  const positions = useDesk((s) => s.positions);
  const watch = useDesk((s) => s.watch);
  const messages = useDesk((s) => s.messages);
  const journal = useDesk((s) => s.journal);
  const curve = useDesk((s) => s.curve);
  const killed = useDesk((s) => s.killed);
  const entriesPaused = useDesk((s) => s.entriesPaused);
  const pauseReason = useDesk((s) => s.pauseReason);
  const weeklyLock = useDesk((s) => s.weeklyLock);
  const fundingMemory = useDesk((s) => s.fundingMemory);
  const memories = useDesk((s) => s.memories);
  const dayStartNav = useDesk((s) => s.dayStartNav);
  const weekStartNav = useDesk((s) => s.weekStartNav);
  const lastPlan = useDesk((s) => s.lastPlan);
  const lastSkeptic = useDesk((s) => s.lastSkeptic);
  const busySymbol = useDesk((s) => s.busySymbol);

  useEffect(() => {
    setMounted(true);
    void Promise.resolve(useDesk.persist.rehydrate()).finally(() => setHydrated(true));
  }, []);

  const damp = useMemo(() => dampenersFromMemory(memories), [memories]);
  const watchSet = useMemo(
    () => new Set(Object.entries(watch).filter(([, v]) => v.active).map(([k]) => k)),
    [watch],
  );
  const ranked = useMemo(
    () => withStatus(rankUniverse(rows, fundingMemory, damp), watchSet, settings),
    [rows, fundingMemory, damp, watchSet, settings],
  );

  useEffect(() => {
    if (!hydrated) return;
    const state = useDesk.getState();
    const rankedNow = rankUniverse(rows, state.fundingMemory, dampenersFromMemory(state.memories));
    state.commitScan(rankedNow);
    state.markPrices(pricesFrom(rows, state.positions));
  }, [fetchedAt, hydrated, rows, settings.scoreThreshold, settings.minQuoteVolume, settings.watchlistSize, settings.demoteScans]);

  useEffect(() => {
    if (!hydrated || venue === "sim" || !rows.length) return;
    let cancel = false;
    const state = useDesk.getState();
    const active = new Set(Object.entries(state.watch).filter(([, v]) => v.active).map(([k]) => k));
    const pool = rankUniverse(rows, state.fundingMemory, dampenersFromMemory(state.memories));
    const picks = (active.size ? pool.filter((r) => active.has(r.symbol)) : pool).filter((r) => r.oiDeltaPct == null).slice(0, 6);
    if (!picks.length) return;
    void fetchEnrichment({
      data: { items: picks.map((p) => ({ symbol: p.symbol, contract: p.contract, venue: p.venue })) },
    })
      .then((found) => {
        if (cancel || !found?.length) return;
        setRows((prev) =>
          prev.map((row) => {
            const e = found.find((x) => x.symbol === row.symbol);
            if (!e) return row;
            return {
              ...row,
              oi: e.oi ?? row.oi,
              oiDeltaPct: e.oiDeltaPct,
              longShortRatio: e.longShortRatio,
              liqCluster: e.liqCluster || row.liqCluster,
              liqNotional: e.liqNotional,
            };
          }),
        );
      })
      .catch(() => undefined);
    return () => {
      cancel = true;
    };
  }, [fetchedAt, hydrated, venue]);

  useEffect(() => {
    if (!hydrated) return;
    const ms = Math.max(20, settings.scanIntervalSec) * 1000;
    const id = window.setInterval(() => void refresh(), ms);
    return () => window.clearInterval(id);
  }, [hydrated, settings.scanIntervalSec]);

  useEffect(() => {
    if (!hydrated || !settings.autoDeliberate) return;
    const state = useDesk.getState();
    if (state.killed || state.weeklyLock || state.entriesPaused || state.deliberating) return;
    const top = ranked.find(
      (r) => r.status === "WATCH" && !state.positions.some((p) => p.status === "OPEN" && p.symbol === r.symbol),
    );
    if (!top) return;
    const key = `${fetchedAt}:${top.symbol}`;
    if (lastAuto.current === key) return;
    lastAuto.current = key;
    void study(top, false);
  }, [fetchedAt, hydrated, ranked, settings.autoDeliberate]);

  async function refresh() {
    setScanning(true);
    try {
      const snap = await fetchUniverse();
      setRows(snap.rows);
      setNote(snap.note);
      setVenue(snap.venue);
      setFetchedAt(snap.fetchedAt);
      setError(snap.error ?? "");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Scan failed");
    } finally {
      setScanning(false);
    }
  }

  async function study(row: ScoredSymbol, focusDesk: boolean) {
    if (busy.current || inflight.has(row.symbol)) return;
    busy.current = true;
    inflight.add(row.symbol);
    if (focusDesk) setView("desk");
    useDesk.getState().setDeliberating(row.symbol);
    try {
      const next = await fetchPacket({
        data: {
          symbol: row.symbol,
          contract: row.contract,
          venue: row.venue,
          lastPrice: row.lastPrice,
          fundingRate: row.fundingRate,
        },
      });
      setPacket(next);
      const state = useDesk.getState();
      const had = state.positions.some((p) => p.status === "OPEN" && p.symbol === row.symbol);
      const prices = pricesFrom(rows, state.positions);
      if (next.lastPrice > 0) prices[row.symbol] = next.lastPrice;
      const nav = accountNav(state.equity, state.positions, prices);
      const scored: ScoredSymbol = {
        ...row,
        oiDeltaPct: next.oiDeltaPct ?? row.oiDeltaPct,
        longShortRatio: next.longShortRatio ?? row.longShortRatio,
        liqCluster: next.liqCluster || row.liqCluster,
        status: state.watch[row.symbol]?.active ? "WATCH" : row.status,
      };
      const decision = decide({
        packet: next,
        scored,
        settings: state.settings,
        nav,
        equity: state.equity,
        positions: state.positions,
        prices,
        dayStartNav: state.dayStartNav,
        weekStartNav: state.weekStartNav,
        weeklyLock: state.weeklyLock,
        killed: state.killed,
        entriesPaused: state.entriesPaused,
        memories: state.memories,
      });
      state.applyDecision(decision, next);
      if (had) useDesk.getState().reviewFlow(row.symbol, decision.flow, next.lastPrice || row.lastPrice);
      setError("");
    } catch (err) {
      useDesk.getState().setDeliberating(null);
      setError(err instanceof Error ? err.message : "The packet failed.");
    } finally {
      inflight.delete(row.symbol);
      busy.current = false;
    }
  }

  function override(reason: string) {
    const state = useDesk.getState();
    const row = ranked.find((r) => r.symbol === state.lastSymbol);
    if (!packet || !row || !state.lastPlan?.valid) return;
    const prices = pricesFrom(rows, state.positions);
    const nav = accountNav(state.equity, state.positions, prices);
    const decision = decide({
      packet,
      scored: { ...row, status: state.watch[row.symbol]?.active ? "WATCH" : row.status },
      settings: state.settings,
      nav,
      equity: state.equity,
      positions: state.positions,
      prices,
      dayStartNav: state.dayStartNav,
      weekStartNav: state.weekStartNav,
      weeklyLock: state.weeklyLock,
      killed: state.killed,
      entriesPaused: state.entriesPaused,
      memories: state.memories,
      overrideReason: reason,
    });
    state.applyDecision(decision, packet);
  }

  const prices = useMemo(() => pricesFrom(rows, positions), [rows, positions]);
  const nav = accountNav(equity, positions, prices);
  const open = positions.filter((p) => p.status === "OPEN");
  const heat = open.reduce((s, p) => s + Math.abs(p.entry - p.stop) * p.qty, 0) / Math.max(nav, 1);
  const dayPnl = nav - dayStartNav;
  const weekPnl = nav - weekStartNav;

  return (
    <div className="min-h-screen bg-bg text-fg">
      <div className="border-b border-border px-4 py-3 md:px-6">
        <p className="max-w-4xl text-xs leading-relaxed text-muted md:text-sm">
          Most systematic strategies do not keep a durable edge. This desk measures and refuses trades. It does not promise profit. Fills are paper. Stops live in this book, not on an exchange. Simulated losses are the honest version of real ones.
        </p>
      </div>
      <header className="sticky top-0 z-20 border-b border-border bg-bg px-4 py-3 md:px-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs tracking-widest text-subtle">PAPER</p>
            <h1 className="text-xl font-medium tracking-tight md:text-2xl">Volumetric Desk</h1>
          </div>
          <button type="button" className="btn btn-danger" onClick={() => setKillOpen(true)}>
            <Octagon className="size-4" aria-hidden />
            Kill
          </button>
        </div>
        <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm">
          <span>NAV <span className="num">{fmtUsd(nav)}</span></span>
          <span>Day <span className={`num ${signedClass(dayPnl)}`}>{fmtUsd(dayPnl)}</span></span>
          <span>Heat <span className="num">{(heat * 100).toFixed(2)}%</span></span>
          <span className="text-muted">{open.length} open</span>
          {(killed || entriesPaused) && <span className="text-down">Halted</span>}
        </div>
      </header>

      <div className="md:grid md:grid-cols-[11rem_minmax(0,1fr)]">
        <nav className="hidden border-r border-border md:flex md:flex-col md:gap-1 md:p-3" aria-label="Sections">
          {NAV.map((item) => (
            <NavButton key={item.id} item={item} active={view === item.id} onClick={() => setView(item.id)} />
          ))}
        </nav>
        <main className="min-w-0 px-4 py-4 pb-24 md:px-6 md:pb-8">
          <p className="mb-4 text-xs leading-relaxed text-subtle">{note}</p>
          {error && <p className="mb-4 text-sm text-down">{error}</p>}
          {view === "scan" && (
            <ScannerView
              rows={ranked}
              query={query}
              onQuery={setQuery}
              showAll={showAll}
              onShowAll={setShowAll}
              universeCount={rows.length}
              scanning={scanning}
              onScan={() => void refresh()}
              onStudy={(row) => void study(row, true)}
              busySymbol={busySymbol}
            />
          )}
          {view === "desk" && (
            <DeskView
              messages={messages}
              plan={lastPlan}
              skeptic={lastSkeptic}
              packet={packet}
              busy={Boolean(busySymbol)}
              onOverride={override}
            />
          )}
          {view === "book" && (
            <BookView
              positions={positions}
              prices={prices}
              nav={nav}
              heat={heat}
              heatCap={settings.maxHeatPct}
              dayPnl={dayPnl}
              weekPnl={weekPnl}
              dayLimit={settings.dailyLossPct}
              weekLimit={settings.weeklyLossPct}
              pauseReason={pauseReason}
              weeklyLock={weeklyLock}
              onAckWeek={() => useDesk.getState().acknowledgeWeek()}
            />
          )}
          {view === "journal" && <JournalView curve={curve} journal={journal} mounted={mounted} />}
          {view === "settings" && (
            <SettingsView
              settings={settings}
              paused={entriesPaused}
              killed={killed}
              onPatch={(patch) => useDesk.getState().patchSettings(patch)}
              onAddEvent={(name, at) => useDesk.getState().addEvent({ id: uid("ev"), name, at })}
              onRemoveEvent={(id) => useDesk.getState().removeEvent(id)}
              onReset={() => setResetOpen(true)}
              onResume={() => useDesk.getState().resumeEntries()}
            />
          )}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-surface md:hidden" aria-label="Sections">
        {NAV.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`flex min-h-14 flex-1 flex-col items-center justify-center gap-1 text-xs ${view === item.id ? "text-fg" : "text-subtle"}`}
            onClick={() => setView(item.id)}
          >
            <item.icon className="size-4" aria-hidden />
            {item.label}
          </button>
        ))}
      </nav>

      {killOpen && (
        <Modal
          title="Flatten the book"
          body="Cancel every working paper bracket and close every open position at the last mark. New entries stay halted until you resume."
          confirm="Kill switch"
          onClose={() => setKillOpen(false)}
          onConfirm={() => {
            useDesk.getState().kill(pricesFrom(rows, useDesk.getState().positions));
            setKillOpen(false);
            setView("book");
          }}
        />
      )}
      {resetOpen && (
        <Modal
          title="Reset the paper account"
          body="Clears positions, the journal, and the equity curve. Scanner settings stay. This cannot be undone."
          confirm="Reset account"
          onClose={() => setResetOpen(false)}
          onConfirm={() => {
            useDesk.getState().resetAccount();
            setResetOpen(false);
          }}
        />
      )}
    </div>
  );
}

function NavButton({
  item,
  active,
  onClick,
}: {
  item: (typeof NAV)[number];
  active: boolean;
  onClick: () => void;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-h-11 items-center gap-2 rounded-md px-3 text-left text-sm ${active ? "bg-surface-2 text-fg" : "text-muted"}`}
    >
      <Icon className="size-4" aria-hidden />
      {item.label}
    </button>
  );
}
