import type { ReactNode } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { buildVolumeProfile } from "@/lib/desk/volume-profile";
import { compact, fmtFunding, fmtPct, fmtPx, fmtQty, fmtTime, fmtUsd, signedClass } from "@/lib/desk/format";
import { AGENT_LABEL, type AgentMessage, type JournalEntry, type MarketPacket, type PlanResult, type Position, type ScoredSymbol, type Settings, type SkepticReport } from "@/lib/desk/types";
import { positionUpl } from "@/lib/desk/store";

export function ScannerView(props: {
  rows: ScoredSymbol[];
  query: string;
  onQuery: (q: string) => void;
  showAll: boolean;
  onShowAll: (v: boolean) => void;
  universeCount: number;
  scanning: boolean;
  onScan: () => void;
  onStudy: (row: ScoredSymbol) => void;
  busySymbol: string | null;
}) {
  const filtered = props.rows.filter((r) => {
    if (!props.query) return true;
    return r.symbol.toLowerCase().includes(props.query.trim().toLowerCase());
  });
  const visible = props.showAll ? filtered : filtered.slice(0, 40);
  const watched = props.rows.filter((r) => r.status === "WATCH").length;

  return (
    <section className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h2 className="text-lg font-medium tracking-tight">Universe</h2>
          <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted">
            {props.universeCount} perpetuals ranked. {watched} promoted to the watchlist. Promotion needs the score floor and a liquidity minimum — majors are not special.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            className="field sm:w-52"
            value={props.query}
            placeholder="Filter symbol"
            aria-label="Filter symbol"
            onChange={(e) => props.onQuery(e.target.value)}
          />
          <button type="button" className="btn btn-ghost" onClick={() => props.onShowAll(!props.showAll)}>
            {props.showAll ? "Top of book" : "Full universe"}
          </button>
          <button type="button" className="btn btn-primary" onClick={props.onScan} disabled={props.scanning}>
            {props.scanning ? "Scanning" : "Scan now"}
          </button>
        </div>
      </div>
      <div className="tape panel p-2 md:p-3">
        <table className="w-full border-separate border-spacing-0 text-left text-sm">
          <thead className="text-xs text-subtle">
            <tr>
              {["Symbol", "Last", "24h", "Funding", "OI", "OI Δ", "Book", "Flags", "Score", ""].map((h) => (
                <th key={h || "act"} className="px-2 py-2 font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.map((row) => (
              <tr key={row.symbol} className="border-t border-border">
                <td className="px-2 py-2">
                  <div className="font-medium">{row.symbol.replace("USDT", "")}</div>
                  <div className="text-xs text-subtle">{row.status === "WATCH" ? "Watch" : row.status === "CANDIDATE" ? "Candidate" : "Idle"}</div>
                </td>
                <td className="num px-2 py-2">{fmtPx(row.lastPrice)}</td>
                <td className={`num px-2 py-2 ${signedClass(row.priceChangePct)}`}>{fmtPct(row.priceChangePct)}</td>
                <td className={`num px-2 py-2 ${signedClass(row.fundingRate)}`}>{fmtFunding(row.fundingRate)}</td>
                <td className="num px-2 py-2 text-muted">{row.oi == null ? "—" : compact(row.oi)}</td>
                <td className={`num px-2 py-2 ${row.oiDeltaPct == null ? "text-subtle" : signedClass(row.oiDeltaPct)}`}>
                  {row.oiDeltaPct == null ? "—" : fmtPct(row.oiDeltaPct * 100, 1)}
                </td>
                <td className={`num px-2 py-2 ${signedClass(row.bookImbalance ?? 0)}`}>
                  {row.bookImbalance == null ? "—" : row.bookImbalance.toFixed(2)}
                </td>
                <td className="px-2 py-2 text-xs text-muted">
                  {[row.divergence > 0.6 ? "DIV" : null, row.liqCluster || row.liquidation > 0.7 ? "LIQ" : null, row.bias !== "NEUTRAL" ? row.bias : null]
                    .filter(Boolean)
                    .join(" · ") || "—"}
                </td>
                <td className="px-2 py-2">
                  <div className="num text-sm">{row.score.toFixed(1)}</div>
                  <div className="mt-1 h-1 w-16 rounded-full bg-surface-2">
                    <div className="h-1 rounded-full bg-accent" style={{ width: `${Math.max(4, Math.min(100, row.score))}%` }} />
                  </div>
                </td>
                <td className="px-2 py-2 text-right">
                  <button
                    type="button"
                    className="btn btn-ghost px-3"
                    onClick={() => props.onStudy(row)}
                    disabled={props.busySymbol === row.symbol}
                  >
                    {props.busySymbol === row.symbol ? "Reading" : "Study"}
                  </button>
                </td>
              </tr>
            ))}
            {!visible.length && (
              <tr>
                <td colSpan={10} className="px-2 py-8 text-sm text-muted">
                  Nothing matched. Lower the score floor in Settings, or wait for the next scan.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export function DeskView(props: {
  messages: AgentMessage[];
  plan: PlanResult | null;
  skeptic: SkepticReport | null;
  packet: MarketPacket | null;
  busy: boolean;
  onOverride: (reason: string) => void;
}) {
  const profile = props.packet ? buildVolumeProfile(props.packet.candles5) : null;
  const maxBin = profile ? Math.max(...profile.bins.map((b) => b.volume), 1) : 1;
  const canOverride = props.plan?.valid && props.skeptic && (props.skeptic.verdict === "BLOCK" || props.skeptic.verdict === "DELAY");

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(18rem,0.8fr)]">
      <section className="panel flex flex-col gap-3 p-4">
        <h2 className="text-lg font-medium tracking-tight">Live desk</h2>
        <p className="text-sm text-muted">
          Scanner, microstructure, structure, sentiment, and news speak first. The Skeptic can block. Risk can still refuse. The executor only papers a bracket after both.
        </p>
        <ol className="flex flex-col gap-3">
          {props.messages.length === 0 && (
            <li className="rounded-lg border border-border bg-bg p-4 text-sm text-muted">
              {props.busy ? "Agents are reading the tape." : "Pick a symbol on the scanner, or leave auto-study on. A quiet book is a valid outcome."}
            </li>
          )}
          {props.messages.slice(0, 24).map((m) => (
            <li key={m.id} className="rounded-lg border border-border bg-bg px-3 py-3">
              <div className="flex items-baseline justify-between gap-3">
                <span className="text-sm font-medium">{AGENT_LABEL[m.agent]}</span>
                <span className="num text-xs text-subtle">{fmtTime(m.ts)}</span>
              </div>
              <div className={`mt-1 text-sm ${m.tone === "block" ? "text-down" : m.tone === "pass" ? "text-up" : "text-fg"}`}>{m.title}</div>
              <p className="mt-1 text-sm leading-relaxed text-muted">{m.body}</p>
            </li>
          ))}
        </ol>
      </section>
      <aside className="flex flex-col gap-4">
        <section className="panel p-4">
          <h3 className="text-sm font-medium">Trade ticket</h3>
          {!props.plan && <p className="mt-3 text-sm text-muted">No plan yet.</p>}
          {props.plan && !props.plan.valid && (
            <p className="mt-3 text-sm leading-relaxed text-muted">NO TRADE. {props.plan.reason}</p>
          )}
          {props.plan?.valid && (
            <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
              <Stat k="Side" v={props.plan.side} />
              <Stat k="Setup" v={props.plan.setup} />
              <Stat k="Entry" v={fmtPx(props.plan.entry)} mono />
              <Stat k="Stop" v={fmtPx(props.plan.stop)} mono />
              <Stat k="Target" v={fmtPx(props.plan.target)} mono />
              <Stat k="Structural R" v={props.plan.rr.toFixed(2)} mono />
            </dl>
          )}
          {props.skeptic && (
            <p className={`mt-3 text-sm leading-relaxed ${props.skeptic.verdict === "BLOCK" ? "text-down" : "text-muted"}`}>
              Skeptic {props.skeptic.verdict}. {props.skeptic.objections[0]?.detail ?? props.skeptic.summary}
            </p>
          )}
          {canOverride && <OverrideBox onOverride={props.onOverride} />}
        </section>
        {profile && profile.bins.length > 0 && (
          <section className="panel p-4">
            <h3 className="text-sm font-medium">Volume profile</h3>
            <p className="mt-1 text-xs text-subtle">POC {fmtPx(profile.poc)} · VA {fmtPx(profile.val)} – {fmtPx(profile.vah)}</p>
            <div className="mt-3 flex h-28 items-end gap-px">
              {profile.bins.map((b) => {
                const poc = Math.abs(b.price - profile.poc) < Math.abs(profile.bins[1]?.price - profile.bins[0]?.price || 1);
                return (
                  <div
                    key={b.price}
                    className={poc ? "bg-accent" : "bg-surface-2"}
                    style={{ height: `${Math.max(6, (b.volume / maxBin) * 100)}%`, flex: 1 }}
                    title={`${fmtPx(b.price)} · ${(b.share * 100).toFixed(1)}%`}
                  />
                );
              })}
            </div>
          </section>
        )}
      </aside>
    </div>
  );
}

function OverrideBox({ onOverride }: { onOverride: (reason: string) => void }) {
  return (
    <form
      className="mt-4 flex flex-col gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const data = new FormData(e.currentTarget);
        const reason = String(data.get("reason") ?? "").trim();
        if (reason.length < 12) return;
        onOverride(reason);
        e.currentTarget.reset();
      }}
    >
      <label className="text-xs text-subtle" htmlFor="override-reason">
        Human override. A block is otherwise final. Risk limits still apply. Say why.
      </label>
      <textarea id="override-reason" name="reason" required minLength={12} className="field min-h-20 py-2" />
      <button type="submit" className="btn btn-ghost">Log override and resize</button>
    </form>
  );
}

function Stat({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div>
      <dt className="text-xs text-subtle">{k}</dt>
      <dd className={mono ? "num mt-1" : "mt-1"}>{v}</dd>
    </div>
  );
}

export function BookView(props: {
  positions: Position[];
  prices: Record<string, number>;
  nav: number;
  heat: number;
  heatCap: number;
  dayPnl: number;
  weekPnl: number;
  dayLimit: number;
  weekLimit: number;
  pauseReason: string;
  weeklyLock: boolean;
  onAckWeek: () => void;
}) {
  const open = props.positions.filter((p) => p.status === "OPEN");
  const closed = props.positions.filter((p) => p.status === "CLOSED").slice(0, 8);
  return (
    <section className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <Gauge label="Portfolio heat" value={props.heat} cap={props.heatCap} text={`${(props.heat * 100).toFixed(2)}% / ${(props.heatCap * 100).toFixed(1)}%`} />
        <Gauge label="Day P&L vs halt" value={Math.max(0, -props.dayPnl / Math.max(props.nav - props.dayPnl, 1))} cap={props.dayLimit} text={fmtUsd(props.dayPnl)} tone={props.dayPnl} />
        <Gauge label="Week P&L vs halt" value={Math.max(0, -props.weekPnl / Math.max(props.nav - props.weekPnl, 1))} cap={props.weekLimit} text={fmtUsd(props.weekPnl)} tone={props.weekPnl} />
      </div>
      {props.pauseReason && (
        <div className="panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-down">{props.pauseReason}</p>
          {props.weeklyLock && (
            <button type="button" className="btn btn-ghost" onClick={props.onAckWeek}>Acknowledge week</button>
          )}
        </div>
      )}
      <div className="panel p-4">
        <h2 className="text-lg font-medium">Open positions</h2>
        {!open.length && <p className="mt-3 text-sm text-muted">Flat. The book is empty, which is allowed.</p>}
        <ul className="mt-3 flex flex-col gap-3">
          {open.map((p) => {
            const px = props.prices[p.symbol] ?? p.entry;
            const upl = positionUpl(p, px);
            const risk = Math.abs(p.entry - p.initialStop) * p.qty;
            const r = risk > 0 ? upl / risk : 0;
            return (
              <li key={p.id} className="rounded-lg border border-border bg-bg p-3">
                <div className="flex items-baseline justify-between gap-3">
                  <span className="font-medium">{p.symbol} · {p.side}</span>
                  <span className={`num ${signedClass(upl)}`}>{fmtUsd(upl)} · {r.toFixed(2)}R</span>
                </div>
                <p className="num mt-2 text-xs text-muted">
                  Entry {fmtPx(p.entry)} · Stop {fmtPx(p.stop)}{p.breakevenArmed ? " (entry)" : ""} · Target {fmtPx(p.target)} · Qty {fmtQty(p.qty)}
                </p>
                <p className="mt-2 text-xs leading-relaxed text-subtle">{p.bracket.note}</p>
              </li>
            );
          })}
        </ul>
      </div>
      {closed.length > 0 && (
        <div className="panel p-4">
          <h3 className="text-sm font-medium">Recent closes</h3>
          <ul className="mt-2 flex flex-col gap-2 text-sm">
            {closed.map((p) => (
              <li key={p.id} className="flex items-baseline justify-between gap-3">
                <span>{p.symbol} · {p.closeReason}</span>
                <span className={`num ${signedClass(p.realizedPnl ?? 0)}`}>{(p.rMultiple ?? 0).toFixed(2)}R</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}

function Gauge({ label, value, cap, text, tone = 0 }: { label: string; value: number; cap: number; text: string; tone?: number }) {
  const pct = Math.max(0, Math.min(100, cap > 0 ? (value / cap) * 100 : 0));
  return (
    <div className="panel p-4">
      <div className="text-xs text-subtle">{label}</div>
      <div className={`num mt-2 text-lg ${signedClass(tone)}`}>{text}</div>
      <div className="mt-3 h-1.5 rounded-full bg-surface-2">
        <div className={`h-1.5 rounded-full ${pct > 85 ? "bg-down" : "bg-accent"}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function JournalView(props: { curve: { t: number; nav: number }[]; journal: JournalEntry[]; mounted: boolean }) {
  const closes = props.journal.filter((j) => j.kind === "CLOSE" && j.rMultiple != null);
  const wins = closes.filter((j) => (j.rMultiple ?? 0) > 0).length;
  const bySetup = new Map<string, { n: number; r: number }>();
  for (const j of closes) {
    const key = j.setup ?? "Other";
    const cur = bySetup.get(key) ?? { n: 0, r: 0 };
    cur.n += 1;
    cur.r += j.rMultiple ?? 0;
    bySetup.set(key, cur);
  }
  const bars = [...bySetup.entries()].map(([setup, v]) => ({ setup, avg: v.r / v.n, n: v.n }));
  const rs = closes.map((j) => ({ r: Number((j.rMultiple ?? 0).toFixed(2)) }));

  return (
    <section className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="panel p-4">
          <div className="text-xs text-subtle">Closed trades</div>
          <div className="num mt-2 text-lg">{closes.length}</div>
        </div>
        <div className="panel p-4">
          <div className="text-xs text-subtle">Win rate</div>
          <div className="num mt-2 text-lg">{closes.length ? `${((wins / closes.length) * 100).toFixed(0)}%` : "—"}</div>
        </div>
        <div className="panel p-4">
          <div className="text-xs text-subtle">Average R</div>
          <div className="num mt-2 text-lg">
            {closes.length ? (closes.reduce((s, j) => s + (j.rMultiple ?? 0), 0) / closes.length).toFixed(2) : "—"}
          </div>
        </div>
      </div>
      <div className="panel p-4">
        <h2 className="text-lg font-medium">Equity</h2>
        <div className="mt-3 h-52">
          {props.mounted && props.curve.length > 1 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={props.curve}>
                <XAxis dataKey="t" hide />
                <YAxis hide domain={["auto", "auto"]} />
                <Tooltip
                  formatter={(v) => fmtUsd(Number(v))}
                  labelFormatter={(t) => fmtTime(Number(t))}
                  contentStyle={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, color: "var(--color-fg)" }}
                />
                <Area dataKey="nav" stroke="var(--color-accent)" fill="var(--color-surface-2)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-sm text-muted">The curve starts after the first marks. One point is not a result.</p>
          )}
        </div>
      </div>
      {props.mounted && rs.length > 0 && (
        <div className="panel p-4">
          <h3 className="text-sm font-medium">R multiples</h3>
          <div className="mt-3 h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={rs}>
                <XAxis dataKey="r" hide />
                <YAxis hide />
                <Bar dataKey="r" fill="var(--color-muted)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {bars.length > 0 && (
            <ul className="mt-2 text-sm text-muted">
              {bars.map((b) => (
                <li key={b.setup}>{b.setup}: {b.n} trades, avg {b.avg.toFixed(2)}R</li>
              ))}
            </ul>
          )}
        </div>
      )}
      <div className="panel p-4">
        <h3 className="text-sm font-medium">Decision record</h3>
        <ul className="mt-3 flex flex-col gap-3">
          {props.journal.slice(0, 30).map((j) => (
            <li key={j.id} className="border-t border-border pt-3 first:border-0 first:pt-0">
              <div className="flex items-baseline justify-between gap-3">
                <span className="text-sm font-medium">{j.title}</span>
                <span className="num text-xs text-subtle">{fmtTime(j.ts)}</span>
              </div>
              <p className="mt-1 text-sm leading-relaxed text-muted">{j.body}</p>
            </li>
          ))}
          {!props.journal.length && <li className="text-sm text-muted">No decisions yet. Skips are recorded too.</li>}
        </ul>
      </div>
    </section>
  );
}

export function SettingsView(props: {
  settings: Settings;
  onPatch: (patch: Partial<Settings>) => void;
  onAddEvent: (name: string, at: number) => void;
  onRemoveEvent: (id: string) => void;
  onReset: () => void;
  onResume: () => void;
  paused: boolean;
  killed: boolean;
}) {
  const s = props.settings;
  return (
    <section className="grid gap-4 lg:grid-cols-2">
      <div className="panel flex flex-col gap-4 p-4">
        <h2 className="text-lg font-medium">Risk</h2>
        <NumberField label="Risk per trade" suffix="%" value={s.riskPerTradePct * 100} min={0.2} max={1} step={0.05} onChange={(n) => props.onPatch({ riskPerTradePct: n / 100 })} />
        <NumberField label="Max portfolio heat" suffix="%" value={s.maxHeatPct * 100} min={0.5} max={5} step={0.1} onChange={(n) => props.onPatch({ maxHeatPct: n / 100 })} />
        <NumberField label="Daily loss halt" suffix="%" value={s.dailyLossPct * 100} min={0.5} max={10} step={0.1} onChange={(n) => props.onPatch({ dailyLossPct: n / 100 })} />
        <NumberField label="Weekly loss halt" suffix="%" value={s.weeklyLossPct * 100} min={1} max={20} step={0.5} onChange={(n) => props.onPatch({ weeklyLossPct: n / 100 })} />
        <NumberField label="Minimum structural R:R" value={s.minRr} min={1.2} max={5} step={0.1} onChange={(n) => props.onPatch({ minRr: n })} />
        <NumberField label="Max correlated alts" value={s.maxCorrelated} min={1} max={6} step={1} onChange={(n) => props.onPatch({ maxCorrelated: n })} />
      </div>
      <div className="panel flex flex-col gap-4 p-4">
        <h2 className="text-lg font-medium">Scanner</h2>
        <NumberField label="Score threshold" value={s.scoreThreshold} min={30} max={90} step={1} onChange={(n) => props.onPatch({ scoreThreshold: n })} />
        <NumberField label="Watchlist size" value={s.watchlistSize} min={5} max={30} step={1} onChange={(n) => props.onPatch({ watchlistSize: n })} />
        <NumberField label="Demote after misses" value={s.demoteScans} min={1} max={8} step={1} onChange={(n) => props.onPatch({ demoteScans: n })} />
        <NumberField label="Min 24h quote volume" suffix="M" value={s.minQuoteVolume / 1_000_000} min={0.5} max={100} step={0.5} onChange={(n) => props.onPatch({ minQuoteVolume: n * 1_000_000 })} />
        <NumberField label="News blackout" suffix="min" value={s.newsBlackoutMin} min={5} max={180} step={5} onChange={(n) => props.onPatch({ newsBlackoutMin: n })} />
        <NumberField label="Scan every" suffix="s" value={s.scanIntervalSec} min={20} max={180} step={5} onChange={(n) => props.onPatch({ scanIntervalSec: n })} />
        <label className="flex min-h-11 items-center justify-between gap-3 text-sm">
          Auto-study the top watch name
          <input
            type="checkbox"
            checked={s.autoDeliberate}
            onChange={(e) => props.onPatch({ autoDeliberate: e.target.checked })}
          />
        </label>
      </div>
      <div className="panel flex flex-col gap-3 p-4">
        <h2 className="text-lg font-medium">Macro calendar</h2>
        <p className="text-sm text-muted">Entries block inside the blackout window around each event. Empty means the news agent only watches headlines.</p>
        <form
          className="flex flex-col gap-2 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            const data = new FormData(e.currentTarget);
            const name = String(data.get("name") ?? "").trim();
            const when = String(data.get("when") ?? "");
            const at = Date.parse(when);
            if (!name || !Number.isFinite(at)) return;
            props.onAddEvent(name, at);
            e.currentTarget.reset();
          }}
        >
          <input name="name" required placeholder="CPI, FOMC, unlock" aria-label="Event name" className="field" />
          <input name="when" required type="datetime-local" aria-label="Event time" className="field" />
          <button type="submit" className="btn btn-ghost">Add</button>
        </form>
        <ul className="flex flex-col gap-2 text-sm">
          {s.events.map((ev) => (
            <li key={ev.id} className="flex items-center justify-between gap-3">
              <span>{ev.name} · {new Date(ev.at).toLocaleString()}</span>
              <button type="button" className="btn btn-ghost px-3" onClick={() => props.onRemoveEvent(ev.id)}>Remove</button>
            </li>
          ))}
        </ul>
      </div>
      <div className="panel flex flex-col gap-3 p-4">
        <h2 className="text-lg font-medium">Venue</h2>
        <p className="text-sm leading-relaxed text-muted">
          This hosted desk does not place live orders. API keys are not requested and are not stored. A self-hosted worker would still need an environment flag, this confirmation, and a futures-enabled key — three gates — before any order left the machine. Here, all three stay shut.
        </p>
        <ol className="list-decimal pl-5 text-sm text-muted">
          <li>Live environment flag: off.</li>
          <li>Explicit confirmation: not available.</li>
          <li>Exchange keys: not collected.</li>
        </ol>
        <div className="flex flex-col gap-2 sm:flex-row">
          {(props.paused || props.killed) && (
            <button type="button" className="btn btn-primary" onClick={props.onResume}>Resume paper entries</button>
          )}
          <button type="button" className="btn btn-ghost" onClick={props.onReset}>Reset paper account</button>
        </div>
      </div>
    </section>
  );
}

function NumberField(props: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix?: string;
  onChange: (n: number) => void;
}) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="flex items-baseline justify-between text-muted">
        {props.label}
        <span className="num text-fg">
          {props.value.toFixed(props.step < 1 ? 2 : 0)}
          {props.suffix ? ` ${props.suffix}` : ""}
        </span>
      </span>
      <input
        type="range"
        min={props.min}
        max={props.max}
        step={props.step}
        value={props.value}
        onChange={(e) => props.onChange(Number(e.target.value))}
        className="w-full accent-current"
      />
    </label>
  );
}

export function Modal(props: { title: string; body: ReactNode; confirm: string; onConfirm: () => void; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/80 p-4 sm:items-center" role="presentation" onClick={props.onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        className="panel w-full max-w-md p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="modal-title" className="text-lg font-medium">{props.title}</h2>
        <div className="mt-2 text-sm leading-relaxed text-muted">{props.body}</div>
        <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button type="button" className="btn btn-ghost" onClick={props.onClose}>Cancel</button>
          <button type="button" className="btn btn-danger" onClick={props.onConfirm}>{props.confirm}</button>
        </div>
      </div>
    </div>
  );
}
