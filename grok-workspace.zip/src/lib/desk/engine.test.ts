import assert from "node:assert/strict";
import test from "node:test";
import { skepticReview, readChart, readNews } from "./agents.ts";
import { computeOrderFlow } from "./order-flow.ts";
import { flatten, markPosition, openPaper } from "./paper.ts";
import { planTrade } from "./planner.ts";
import { evaluateRisk } from "./risk.ts";
import { nextWatch, scoreSymbol } from "./scanner.ts";
import { buildVolumeProfile } from "./volume-profile.ts";
import { DEFAULT_SETTINGS, type Candle, type Settings, type TradePlan, type TradeTick } from "./types.ts";

function trendCandles(n = 80): Candle[] {
  const out: Candle[] = [];
  let price = 100;
  for (let i = 0; i < n; i++) {
    const o = price;
    const drift = i < 55 ? 0.12 : -0.05;
    const c = o + drift;
    const hi = Math.max(o, c) + 0.04;
    const lo = Math.min(o, c) - 0.04;
    const nearNode = c > 103.2 && c < 104.4;
    const nearTarget = c > 106.6 && c < 107.6;
    out.push({
      t: i * 300_000,
      o,
      h: hi,
      l: lo,
      c,
      v: nearNode || nearTarget ? 12 : 1,
    });
    price = c;
  }
  return out;
}

function buys(price: number): TradeTick[] {
  return Array.from({ length: 40 }, (_, i) => ({
    p: price * (1 + i * 0.00002),
    q: 2,
    m: i % 9 === 0,
    T: i,
  }));
}

test("volume profile puts the POC on the heavy node", () => {
  const candles: Candle[] = [];
  for (let i = 0; i < 30; i++) {
    const c = i < 20 ? 100 : 110;
    candles.push({ t: i, o: c, h: c + 0.2, l: c - 0.2, c, v: i < 20 ? 50 : 1 });
  }
  const profile = buildVolumeProfile(candles, 20);
  assert.ok(profile.poc < 104, `poc ${profile.poc}`);
  assert.ok(profile.hvns.length >= 1);
  assert.ok(profile.totalVolume > 0);
  assert.ok(profile.val <= profile.poc && profile.poc <= profile.vah);
});

test("opportunity score fades crowded positive funding", () => {
  const row = scoreSymbol({
    symbol: "ABCUSDT",
    contract: "ABC_USDT",
    venue: "gate",
    lastPrice: 10,
    markPrice: 10,
    priceChangePct: 0.2,
    quoteVolume: 20_000_000,
    fundingRate: 0.0007,
    nextFundingTime: null,
    oi: 1,
    oiDeltaPct: 0.05,
    bookImbalance: -0.2,
    longShortRatio: 1.8,
    liqCluster: false,
    liqNotional: 0,
  });
  assert.equal(row.bias, "SHORT");
  assert.ok(row.score >= 55, `score ${row.score}`);
});

test("promotion demotes only after consecutive misses", () => {
  const hot = scoreSymbol({
    symbol: "HOTUSDT",
    contract: "HOT_USDT",
    venue: "gate",
    lastPrice: 1,
    markPrice: 1,
    priceChangePct: 0.1,
    quoteVolume: 30_000_000,
    fundingRate: 0.0008,
    nextFundingTime: null,
    oi: 1,
    oiDeltaPct: 0.04,
    bookImbalance: 0.2,
    longShortRatio: null,
    liqCluster: true,
    liqNotional: 1,
  });
  const cold = { ...hot, score: 10, quoteVolume: 1000, symbol: "HOTUSDT" };
  const first = nextWatch([hot], {}, DEFAULT_SETTINGS);
  assert.ok(first.symbols.includes("HOTUSDT"));
  const second = nextWatch([cold], first.state, DEFAULT_SETTINGS);
  assert.equal(second.state.HOTUSDT.active, true);
  const third = nextWatch([cold], second.state, DEFAULT_SETTINGS);
  const fourth = nextWatch([cold], third.state, DEFAULT_SETTINGS);
  assert.equal(fourth.state.HOTUSDT.active, false);
});

test("planner stands down when flow does not agree", () => {
  const candles = trendCandles();
  const price = candles[candles.length - 1].c;
  const flow = computeOrderFlow(
    Array.from({ length: 30 }, (_, i) => ({ p: price, q: 1, m: i % 2 === 0, T: i })),
    price,
  );
  const plan = planTrade({ symbol: "BTCUSDT", price, candles, candlesHtf: candles, flow, minRr: 2 });
  assert.equal(plan.valid, false);
});

test("skeptic blocks a wick stop and a news blackout", () => {
  const plan: TradePlan = {
    valid: true,
    symbol: "ETHUSDT",
    side: "LONG",
    entry: 100,
    stop: 99.7,
    target: 106,
    rr: 20,
    setup: "HVN edge",
    reason: "test",
    confluence: { ofi: true, imbalance: true, vwap: false, votes: 2 },
    poc: 100,
    hvn: 100,
    atr: 2,
  };
  const flow = computeOrderFlow(buys(100), 100);
  const report = skepticReview({
    plan,
    flow,
    profileShare: 0.02,
    pocShare: 0.02,
    chart: { bias: "SHORT", dissent: true, summary: "fights the trend" },
    sentiment: { crowdedSide: "LONG", sameSide: true, extreme: true, summary: "crowded" },
    news: { blackout: true, reason: "CPI", summary: "blackout" },
    similar: [],
    atr: 2,
    settings: DEFAULT_SETTINGS,
    spreadBps: 2,
  });
  assert.equal(report.verdict, "BLOCK");
  assert.ok(report.objections.some((o) => o.code === "NEWS"));
  assert.ok(report.objections.some((o) => o.code === "STOP_WICK" || o.code === "HVN_WEAK"));
});

test("risk engine rejects claimed R:R when the levels do not pay", () => {
  const plan: TradePlan = {
    valid: true,
    symbol: "SOLUSDT",
    side: "LONG",
    entry: 100,
    stop: 99,
    target: 101,
    rr: 3,
    setup: "HVN edge",
    reason: "test",
    confluence: { ofi: true, imbalance: true, vwap: true, votes: 3 },
    poc: 100,
    hvn: 100,
    atr: 1,
  };
  const decision = evaluateRisk({
    plan,
    skeptic: { verdict: "PASS", sizeFactor: 1, objections: [], summary: "pass" },
    settings: DEFAULT_SETTINGS,
    equity: 100_000,
    nav: 100_000,
    positions: [],
    prices: {},
    dayStartNav: 100_000,
    weekStartNav: 100_000,
    weeklyLock: false,
    killed: false,
    entriesPaused: false,
    newsBlackout: false,
    spreadBps: 1,
    sizeFactor: 1,
  });
  assert.equal(decision.approved, false);
  assert.ok(decision.gates.some((g) => g.name === "R:R floor" && !g.pass));
});

test("risk engine blocks the kill switch and the heat cap", () => {
  const plan: TradePlan = {
    valid: true,
    symbol: "BTCUSDT",
    side: "LONG",
    entry: 100,
    stop: 98,
    target: 106,
    rr: 3,
    setup: "HVN edge",
    reason: "test",
    confluence: { ofi: true, imbalance: true, vwap: true, votes: 3 },
    poc: 100,
    hvn: 100,
    atr: 2,
  };
  const killed = evaluateRisk({
    plan,
    skeptic: { verdict: "PASS", sizeFactor: 1, objections: [], summary: "pass" },
    settings: DEFAULT_SETTINGS,
    equity: 100_000,
    nav: 100_000,
    positions: [],
    prices: {},
    dayStartNav: 100_000,
    weekStartNav: 100_000,
    weeklyLock: false,
    killed: true,
    entriesPaused: true,
    newsBlackout: false,
    spreadBps: 1,
    sizeFactor: 1,
  });
  assert.equal(killed.approved, false);
  assert.ok(killed.gates.some((g) => g.name === "Kill switch" && !g.pass));
});

test("paper bracket flattens on the stop and trails to breakeven", () => {
  const plan: TradePlan = {
    valid: true,
    symbol: "BTCUSDT",
    side: "LONG",
    entry: 100,
    stop: 98,
    target: 106,
    rr: 3,
    setup: "HVN edge",
    reason: "test",
    confluence: { ofi: true, imbalance: true, vwap: true, votes: 3 },
    poc: 100,
    hvn: 100,
    atr: 2,
  };
  const settings: Settings = { ...DEFAULT_SETTINGS, slippageBps: 0, feeBps: 4, breakevenR: 1 };
  const opened = openPaper({
    plan,
    qty: 2,
    leverage: 2,
    settings,
    fundingRate: 0.0001,
    oiDeltaPct: 0.01,
    contract: "BTC_USDT",
    now: 1,
  });
  assert.equal(opened.position.bracket.protection[0].type, "STOP_MARKET");
  assert.equal(opened.position.bracket.protection[1].type, "TAKE_PROFIT_MARKET");
  assert.equal(opened.position.bracket.marginType, "ISOLATED");

  const armed = markPosition(opened.position, 102, settings, 2);
  assert.equal(armed.closed, false);
  assert.equal(armed.position.breakevenArmed, true);
  assert.equal(armed.position.stop, armed.position.entry);

  const stopped = markPosition(opened.position, 97.5, settings, 3);
  assert.equal(stopped.closed, true);
  assert.equal(stopped.position.closeReason, "stop");
  assert.ok((stopped.position.realizedPnl ?? 0) < 0);

  const killed = flatten(opened.position, 101, "kill", settings, 4);
  assert.equal(killed.position.closeReason, "kill");
  assert.ok((killed.position.realizedPnl ?? 0) > 0);
});

test("chart dissent and news blackout are explicit", () => {
  const flat: Candle[] = Array.from({ length: 30 }, (_, i) => ({
    t: i,
    o: 100,
    h: 101,
    l: 99,
    c: 100 + (i % 2 ? 0.2 : -0.2),
    v: 1,
  }));
  const up: Candle[] = Array.from({ length: 40 }, (_, i) => ({
    t: i,
    o: 100 + i,
    h: 101 + i,
    l: 99 + i,
    c: 100.5 + i,
    v: 1,
  }));
  const chart = readChart(
    {
      symbol: "AAAUSDT",
      contract: "AAA_USDT",
      venue: "sim",
      lastPrice: 140,
      fundingRate: 0,
      fundingHistory: [],
      oi: null,
      oiDeltaPct: null,
      longShortRatio: null,
      liqCluster: false,
      liqNotional: 0,
      candles5: up,
      candles15: up,
      candles1h: up,
      trades: [],
      bids: [],
      asks: [],
      headlines: [],
      spreadBps: 1,
      bookImbalance: 0,
    },
    "SHORT",
  );
  assert.equal(chart.dissent, true);
  const news = readNews(
    {
      symbol: "BTCUSDT",
      contract: "BTC_USDT",
      venue: "sim",
      lastPrice: 1,
      fundingRate: 0,
      fundingHistory: [],
      oi: null,
      oiDeltaPct: null,
      longShortRatio: null,
      liqCluster: false,
      liqNotional: 0,
      candles5: flat,
      candles15: flat,
      candles1h: flat,
      trades: [],
      bids: [],
      asks: [],
      headlines: ["Bitcoin funding flips as open interest builds"],
      spreadBps: 1,
      bookImbalance: 0,
    },
    { ...DEFAULT_SETTINGS, events: [{ id: "1", name: "FOMC", at: 1_000 }] },
    1_000,
  );
  assert.equal(news.blackout, true);
});
