import { median } from "./math.ts";
import type { Candle, VolumeProfile } from "./types.ts";

/**
 * Distributes each candle's volume uniformly across the bins its range covers,
 * then marks the POC, a 70% value area, and local HVN / LVN nodes.
 */
export function buildVolumeProfile(candles: Candle[], binCount = 36): VolumeProfile {
  const empty: VolumeProfile = {
    bins: [],
    poc: candles.at(-1)?.c ?? 0,
    vah: candles.at(-1)?.c ?? 0,
    val: candles.at(-1)?.c ?? 0,
    hvns: [],
    lvns: [],
    totalVolume: 0,
  };
  if (candles.length < 4) return empty;

  const hi = Math.max(...candles.map((c) => c.h));
  const lo = Math.min(...candles.map((c) => c.l));
  const span = Math.max(hi - lo, lo * 1e-6, 1e-9);
  const binsN = Math.max(12, binCount);
  const step = span / binsN;
  const vols = new Array<number>(binsN).fill(0);

  for (const c of candles) {
    const i0 = Math.max(0, Math.min(binsN - 1, Math.floor((c.l - lo) / step)));
    const i1 = Math.max(0, Math.min(binsN - 1, Math.floor((Math.max(c.h, c.l + step * 0.01) - lo) / step)));
    const n = Math.max(1, i1 - i0 + 1);
    const share = (c.v > 0 ? c.v : 0) / n;
    for (let i = i0; i <= i1; i++) vols[i] += share;
  }

  const total = vols.reduce((a, b) => a + b, 0);
  if (total <= 0) return empty;

  const bins = vols.map((volume, i) => ({
    price: lo + (i + 0.5) * step,
    volume,
    share: volume / total,
  }));

  let pocIdx = 0;
  for (let i = 1; i < vols.length; i++) if (vols[i] > vols[pocIdx]) pocIdx = i;

  // Expand a 70% value area outward from the POC, taking the heavier neighbour.
  const included = new Set<number>([pocIdx]);
  let covered = vols[pocIdx];
  let left = pocIdx - 1;
  let right = pocIdx + 1;
  while (covered / total < 0.7 && (left >= 0 || right < binsN)) {
    const lv = left >= 0 ? vols[left] : -1;
    const rv = right < binsN ? vols[right] : -1;
    if (rv > lv) {
      included.add(right);
      covered += vols[right];
      right += 1;
    } else if (left >= 0) {
      included.add(left);
      covered += vols[left];
      left -= 1;
    } else break;
  }
  const areaIdx = [...included].sort((a, b) => a - b);
  const val = bins[areaIdx[0]].price;
  const vah = bins[areaIdx[areaIdx.length - 1]].price;

  const med = median(vols);
  const hvns: number[] = [];
  const lvns: number[] = [];
  for (let i = 1; i < binsN - 1; i++) {
    const peak = vols[i] >= vols[i - 1] && vols[i] >= vols[i + 1] && vols[i] >= med * 1.25;
    const trough = vols[i] <= vols[i - 1] && vols[i] <= vols[i + 1] && vols[i] <= med * 0.72;
    if (peak) hvns.push(bins[i].price);
    else if (trough) lvns.push(bins[i].price);
  }
  if (!hvns.length) hvns.push(bins[pocIdx].price);
  else if (!hvns.some((p) => Math.abs(p - bins[pocIdx].price) < step * 1.5)) hvns.push(bins[pocIdx].price);
  hvns.sort((a, b) => a - b);

  return { bins, poc: bins[pocIdx].price, vah, val, hvns, lvns, totalVolume: total };
}

export function binShareAt(profile: VolumeProfile, price: number): number {
  if (!profile.bins.length) return 0;
  let best = profile.bins[0];
  let dist = Math.abs(best.price - price);
  for (const b of profile.bins) {
    const d = Math.abs(b.price - price);
    if (d < dist) {
      best = b;
      dist = d;
    }
  }
  return best.share;
}
