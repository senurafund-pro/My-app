import type { Candle, MarketPacket, TradeTick, UniverseRow } from "./types.ts";

const NAMES = [
  "BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "ADA", "AVAX", "LINK", "SUI",
  "WLD", "INJ", "TIA", "SEI", "NEAR", "APT", "ARB", "OP", "FIL", "LTC",
  "BCH", "AAVE", "PENDLE", "ENA", "WIF", "PEPE", "TON", "DOT", "ATOM", "RUNE",
];

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function simulateUniverse(tick = 0): UniverseRow[] {
  const rand = mulberry32(0x51ed ^ (tick % 997));
  return NAMES.map((base, i) => {
    const r = mulberry32((i + 1) * 997 + (tick % 50));
    const price = (8 + r() * 200) * (base === "BTC" ? 400 : base === "ETH" ? 20 : 1);
    const funding = (r() - 0.42) * 0.0011;
    const change = (r() - 0.48) * 18;
    const imb = r() * 2 - 1;
    return {
      symbol: `${base}USDT`,
      contract: `${base}_USDT`,
      venue: "sim",
      lastPrice: price,
      markPrice: price * (1 + (r() - 0.5) * 0.0004),
      priceChangePct: change,
      quoteVolume: 2_000_000 + r() * 800_000_000,
      fundingRate: funding,
      nextFundingTime: null,
      oi: price * (1_000 + r() * 50_000),
      oiDeltaPct: (r() - 0.45) * 0.12,
      bookImbalance: imb * 0.6,
      longShortRatio: 0.7 + r() * 1.1,
      liqCluster: Math.abs(change) > 8 && Math.abs(funding) > 0.0004,
      liqNotional: Math.abs(change) > 8 ? price * 1000 : 0,
    };
  });
}

export function simulatePacket(row: UniverseRow, tick = 0): MarketPacket {
  const rand = mulberry32(row.symbol.split("").reduce((a, c) => a + c.charCodeAt(0), tick + 11));
  const price = row.lastPrice;
  const candles5 = walk(price, 100, 0.004, rand, 5 * 60_000);
  const candles15 = walk(price, 80, 0.007, rand, 15 * 60_000);
  const candles1h = walk(price, 60, 0.012, rand, 60 * 60_000);
  // Bias the tape with funding so confluence sometimes exists.
  const buyBias = row.fundingRate < 0 ? 0.62 : row.fundingRate > 0.0003 ? 0.38 : 0.5;
  const trades: TradeTick[] = [];
  for (let i = 0; i < 180; i++) {
    const buy = rand() < buyBias;
    trades.push({
      p: price * (1 + (rand() - 0.5) * 0.0015),
      q: 0.2 + rand() * 4,
      m: !buy,
      T: Date.now() - (180 - i) * 1000,
    });
  }
  const book = (sign: number): [number, number][] =>
    Array.from({ length: 12 }, (_, i) => [price * (1 + sign * (i + 1) * 0.00015), 1 + rand() * 20]);
  return {
    symbol: row.symbol,
    contract: row.contract,
    venue: "sim",
    lastPrice: price,
    fundingRate: row.fundingRate,
    fundingHistory: [
      { t: Date.now() - 8 * 3600_000, rate: row.fundingRate * 0.4 },
      { t: Date.now(), rate: row.fundingRate },
    ],
    oi: row.oi,
    oiDeltaPct: row.oiDeltaPct,
    longShortRatio: row.longShortRatio,
    liqCluster: row.liqCluster,
    liqNotional: row.liqNotional ?? 0,
    candles5,
    candles15,
    candles1h,
    trades,
    bids: book(-1),
    asks: book(1),
    headlines: [],
    spreadBps: 1.6,
    bookImbalance: row.bookImbalance ?? 0,
  };
}

function walk(price: number, n: number, step: number, rand: () => number, barMs: number): Candle[] {
  const out: Candle[] = [];
  let px = price * (1 - step * n * 0.15);
  const start = Date.now() - n * barMs;
  for (let i = 0; i < n; i++) {
    const drift = (price - px) * 0.04;
    const o = px;
    const move = drift + (rand() - 0.48) * price * step;
    const c = Math.max(price * 0.2, o + move);
    const h = Math.max(o, c) * (1 + rand() * step * 0.4);
    const l = Math.min(o, c) * (1 - rand() * step * 0.4);
    const near = Math.abs(c - price) / price < 0.01 || Math.abs(c - price * 0.985) / price < 0.008;
    out.push({ t: start + i * barMs, o, h, l, c, v: (near ? 8 : 1) * (0.5 + rand()) });
    px = c;
  }
  out[out.length - 1].c = price;
  out[out.length - 1].h = Math.max(out[out.length - 1].h, price);
  out[out.length - 1].l = Math.min(out[out.length - 1].l, price);
  return out;
}
