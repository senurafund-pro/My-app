import { buildVolumeProfile, binShareAt } from "./volume-profile.ts";
import { bookImbalance, computeOrderFlow, spreadBps } from "./order-flow.ts";
import { planTrade } from "./planner.ts";
import { evaluateRisk } from "./risk.ts";
import { atr, cosine, ema, mean, trendEfficiency, uid } from "./math.ts";
import type {
  AgentMessage,
  Bias,
  JournalEntry,
  MarketPacket,
  OrderFlow,
  PlanResult,
  Position,
  ScoredSymbol,
  Settings,
  SetupMemory,
  Side,
  SkepticObjection,
  SkepticReport,
  TradePlan,
  Verdict,
} from "./types.ts";

export interface ChartRead {
  bias: Bias;
  dissent: boolean;
  summary: string;
}

export interface SentimentRead {
  crowdedSide: Side | null;
  sameSide: boolean;
  extreme: boolean;
  summary: string;
}

export interface NewsRead {
  blackout: boolean;
  reason: string;
  summary: string;
}

export interface SimilarSetup {
  memory: SetupMemory;
  similarity: number;
}

function msg(
  agent: AgentMessage["agent"],
  title: string,
  body: string,
  tone: AgentMessage["tone"],
  symbol: string | undefined,
  now: number,
): AgentMessage {
  return { id: uid(agent), agent, ts: now, symbol, title, body, tone };
}

function emaBias(closes: number[]): Bias {
  if (closes.length < 22) return "NEUTRAL";
  const fast = ema(closes, 8);
  const slow = ema(closes, 21);
  if (fast > slow * 1.0015) return "LONG";
  if (fast < slow * 0.9985) return "SHORT";
  return "NEUTRAL";
}

export function readChart(packet: MarketPacket, side: Side | null): ChartRead {
  const h1 = packet.candles1h.map((c) => c.c);
  const m15 = packet.candles15.map((c) => c.c);
  const b1 = emaBias(h1);
  const b15 = emaBias(m15);
  const eff = trendEfficiency(packet.candles1h.length ? packet.candles1h : packet.candles15);
  const bias: Bias = b1 === "NEUTRAL" ? (b15 === "NEUTRAL" ? "NEUTRAL" : b15) : b1;
  const dissent = Boolean(side && bias !== "NEUTRAL" && bias !== side);
  const summary = dissent
    ? `Dissent. ${side} fights the ${bias === "LONG" ? "higher-timeframe uptrend" : "higher-timeframe downtrend"} (1h ${b1}, 15m ${b15}, efficiency ${eff.toFixed(2)}).`
    : `Structure ${bias === "NEUTRAL" ? "is balanced" : `leans ${bias}`}. 1h ${b1}, 15m ${b15}, efficiency ${eff.toFixed(2)}. No dissent${side ? ` against ${side}` : ""}.`;
  return { bias, dissent, summary };
}

export function readSentiment(packet: MarketPacket, side: Side | null): SentimentRead {
  const f = packet.fundingRate;
  const oiUp = (packet.oiDeltaPct ?? 0) > 0.015;
  const lsr = packet.longShortRatio;
  let crowdedSide: Side | null = null;
  if (f > 0.0003 && (oiUp || (lsr != null && lsr > 1.3))) crowdedSide = "LONG";
  else if (f < -0.00022 && (oiUp || (lsr != null && lsr < 0.78))) crowdedSide = "SHORT";
  else if (f > 0.00055) crowdedSide = "LONG";
  else if (f < -0.0004) crowdedSide = "SHORT";
  const sameSide = Boolean(side && crowdedSide === side);
  const extreme = Math.abs(f) > 0.0007 || (lsr != null && (lsr > 2.1 || lsr < 0.48));
  const lsrTxt = lsr == null ? "long/short unavailable" : `account long/short ${lsr.toFixed(2)}`;
  const oiTxt = packet.oiDeltaPct == null ? "OI delta unavailable" : `OI ${packet.oiDeltaPct >= 0 ? "+" : ""}${(packet.oiDeltaPct * 100).toFixed(1)}%`;
  const summary = crowdedSide
    ? `Crowded ${crowdedSide === "LONG" ? "longs" : "shorts"}. Funding ${(f * 100).toFixed(4)}%, ${oiTxt}, ${lsrTxt}.${sameSide ? " The proposed side is the crowd." : " The proposed side fades the crowd."}`
    : `Positioning is not extreme. Funding ${(f * 100).toFixed(4)}%, ${oiTxt}, ${lsrTxt}.`;
  return { crowdedSide, sameSide, extreme, summary };
}

export function readNews(packet: MarketPacket, settings: Settings, now: number): NewsRead {
  const windowMs = settings.newsBlackoutMin * 60_000;
  const hit = settings.events.find((e) => Math.abs(e.at - now) <= windowMs);
  const base = packet.symbol.replace(/USDT$/, "").replace(/_/g, "");
  const related = packet.headlines.filter((h) => {
    const u = h.toUpperCase();
    return u.includes(base) || (base === "BTC" && u.includes("BITCOIN"));
  });
  const lead = related[0] ?? packet.headlines[0];
  if (hit) {
    return {
      blackout: true,
      reason: hit.name,
      summary: `Blackout. “${hit.name}” is inside ±${settings.newsBlackoutMin} minutes. No new entries.${lead ? ` Context: ${lead}` : ""}`,
    };
  }
  return {
    blackout: false,
    reason: "",
    summary: lead
      ? `Calendar clear. Latest headline: ${lead}`
      : "Calendar clear. No headline feed on this pass — blackout is driven only by events you add in Settings.",
  };
}

export function recallSimilar(
  memories: SetupMemory[],
  side: Side,
  funding: number,
  flow: OrderFlow,
): SimilarSetup[] {
  const q = features(side, funding, flow.ofi, flow.imbalance, flow.vwapDev);
  return memories
    .filter((m) => m.outcome !== "OPEN")
    .map((memory) => ({
      memory,
      similarity: cosine(q, features(memory.side, memory.funding, memory.ofi, memory.imbalance, memory.vwapDev)),
    }))
    .filter((s) => s.similarity >= 0.8)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, 3);
}

function features(side: Side, funding: number, ofi: number, imb: number, vwapDev: number): number[] {
  const cap = (n: number, lim: number) => Math.max(-lim, Math.min(lim, n));
  return [side === "LONG" ? 1 : -1, cap(funding / 0.0003, 3), cap(ofi, 1), cap(imb, 1), cap(vwapDev / 0.005, 3)];
}

export function skepticReview(input: {
  plan: PlanResult;
  flow: OrderFlow;
  profileShare: number;
  pocShare: number;
  chart: ChartRead;
  sentiment: SentimentRead;
  news: NewsRead;
  similar: SimilarSetup[];
  atr: number;
  settings: Settings;
  spreadBps: number;
}): SkepticReport {
  const objections: SkepticObjection[] = [];
  if (!input.plan.valid) {
    return {
      verdict: "PASS",
      sizeFactor: 0,
      objections: [{ code: "STAND_DOWN", severity: "NOTE", detail: input.plan.reason }],
      summary: "Nothing to approve. The stand-down is accepted.",
    };
  }
  const plan = input.plan;
  const stopDist = Math.abs(plan.entry - plan.stop);

  if (input.pocShare < 0.055) {
    objections.push({
      code: "POC_THIN",
      severity: "DOWNSIZE",
      detail: `POC holds only ${(input.pocShare * 100).toFixed(1)}% of profile volume. The node may be an artefact of the window.`,
    });
  }
  if (input.profileShare < 0.04) {
    objections.push({
      code: "HVN_WEAK",
      severity: "BLOCK",
      detail: `The entry node is ${(input.profileShare * 100).toFixed(1)}% of volume — not a real high-volume area.`,
    });
  }

  if (plan.confluence.votes < 2) {
    objections.push({
      code: "CONFLUENCE",
      severity: "BLOCK",
      detail: "Fewer than two of OFI, imbalance, and VWAP agree. That is a cherry-pick, not a setup.",
    });
  } else if (plan.confluence.votes === 2) {
    objections.push({
      code: "CONFLUENCE_PARTIAL",
      severity: "DOWNSIZE",
      detail: "Only 2 of 3 flow signals agree. Size is cut until the third confirms.",
    });
  }

  if (input.flow.divergence === "BULLISH" && plan.side === "SHORT") {
    objections.push({
      code: "CVD",
      severity: "DOWNSIZE",
      detail: "CVD is diverging bullishly against this short.",
    });
  } else if (input.flow.divergence === "BEARISH" && plan.side === "LONG") {
    objections.push({
      code: "CVD",
      severity: "DOWNSIZE",
      detail: "CVD is diverging bearishly against this long.",
    });
  }

  if (input.atr > 0 && stopDist < input.atr * 0.38) {
    objections.push({
      code: "STOP_WICK",
      severity: "BLOCK",
      detail: `Stop is ${(stopDist / input.atr).toFixed(2)} ATR away — tucked where a liquidity sweep takes it without breaking structure.`,
    });
  }

  if (input.sentiment.sameSide && input.sentiment.extreme) {
    objections.push({
      code: "CROWD",
      severity: "BLOCK",
      detail: `Funding, OI, and positioning say ${plan.side} is already the crowded side. This is late, not early.`,
    });
  } else if (input.sentiment.sameSide) {
    objections.push({
      code: "CROWD",
      severity: "DOWNSIZE",
      detail: "Crowding is on the same side as the trade, but not at an extreme. Size halved.",
    });
  }

  const slip = (input.settings.slippageBps + Math.max(0, input.spreadBps) * 0.25) / 10_000;
  const fee = (input.settings.feeBps * 2) / 10_000;
  const dir = plan.side === "LONG" ? 1 : -1;
  const risk = (plan.entry * (1 + slip * dir) - plan.stop * (1 - slip * dir)) * dir;
  const reward = (plan.target * (1 - slip * dir) - plan.entry * (1 + slip * dir)) * dir - plan.entry * fee;
  const rrNet = risk > 0 ? reward / risk : 0;
  if (rrNet < input.settings.minRr) {
    objections.push({
      code: "RR_NET",
      severity: "BLOCK",
      detail: `After fees and slippage the target pays ${rrNet.toFixed(2)}R, under the ${input.settings.minRr.toFixed(1)} floor. The quoted ${plan.rr.toFixed(2)}R does not survive the book.`,
    });
  }

  if (input.news.blackout) {
    objections.push({
      code: "NEWS",
      severity: "BLOCK",
      detail: `High-impact window: ${input.news.reason}. The setup is not holdable through the print.`,
    });
  }

  if (input.chart.dissent) {
    objections.push({
      code: "HTF",
      severity: "DELAY",
      detail: input.chart.summary,
    });
  }

  const losers = input.similar.filter((s) => (s.memory.rMultiple ?? 0) < 0);
  if (input.similar.length >= 2 && losers.length >= 2) {
    const avg = mean(input.similar.map((s) => s.memory.rMultiple ?? 0));
    objections.push({
      code: "MEMORY",
      severity: avg < -0.4 ? "BLOCK" : "DOWNSIZE",
      detail: `Retrieval memory: ${input.similar.length} similar flow-and-funding setups, average ${avg.toFixed(2)}R. The pattern has not been paying.`,
    });
  }

  const verdict = worst(objections);
  const sizeFactor = verdict === "BLOCK" || verdict === "DELAY" ? 0 : verdict === "DOWNSIZE" ? 0.5 : 1;
  const summary =
    objections.length === 0
      ? "No structural, flow, crowding, or calendar objection survived. Pass."
      : objections.map((o) => `${o.severity} ${o.code}: ${o.detail}`).join(" ");

  return { verdict, sizeFactor, objections, summary };
}

function worst(objections: SkepticObjection[]): Verdict {
  if (objections.some((o) => o.severity === "BLOCK")) return "BLOCK";
  if (objections.some((o) => o.severity === "DELAY")) return "DELAY";
  if (objections.some((o) => o.severity === "DOWNSIZE")) return "DOWNSIZE";
  return "PASS";
}

export interface Decision {
  messages: AgentMessage[];
  plan: PlanResult;
  skeptic: SkepticReport;
  chart: ChartRead;
  sentiment: SentimentRead;
  news: NewsRead;
  flow: OrderFlow;
  approved: boolean;
  qty: number;
  leverage: number;
  riskReason: string;
  gates: { name: string; pass: boolean; detail: string }[];
  rrNet: number;
  journal: JournalEntry;
  memory: SetupMemory | null;
  similar: SimilarSetup[];
}

export function decide(input: {
  packet: MarketPacket;
  scored: ScoredSymbol | null;
  settings: Settings;
  nav: number;
  equity: number;
  positions: Position[];
  prices: Record<string, number>;
  dayStartNav: number;
  weekStartNav: number;
  weeklyLock: boolean;
  killed: boolean;
  entriesPaused: boolean;
  memories: SetupMemory[];
  now?: number;
  /** When set, skeptic BLOCK/DELAY is rewritten to a logged DOWNSIZE. Risk gates still apply. */
  overrideReason?: string;
}): Decision {
  const now = input.now ?? Date.now();
  const packet = input.packet;
  const flow = computeOrderFlow(packet.trades, packet.lastPrice);
  const depthImb = bookImbalance(packet.bids, packet.asks);
  const flowUse: OrderFlow = {
    ...flow,
    imbalance: packet.trades.length > 20 ? flow.imbalance : depthImb,
  };
  const profile = buildVolumeProfile(packet.candles5);
  const spread = packet.spreadBps || spreadBps(packet.bids, packet.asks);
  const plan = planTrade({
    symbol: packet.symbol,
    price: packet.lastPrice,
    candles: packet.candles5,
    candlesHtf: packet.candles1h.length ? packet.candles1h : packet.candles15,
    flow: flowUse,
    minRr: input.settings.minRr,
    profile,
  });
  const side = plan.valid ? plan.side : null;
  const chart = readChart(packet, side);
  const sentiment = readSentiment(packet, side);
  const news = readNews(packet, input.settings, now);
  const similar = side ? recallSimilar(input.memories, side, packet.fundingRate, flowUse) : [];
  const range = atr(packet.candles5, 14);
  let skeptic = skepticReview({
    plan,
    flow: flowUse,
    profileShare: plan.valid ? binShareAt(profile, plan.hvn) : 0,
    pocShare: binShareAt(profile, profile.poc),
    chart,
    sentiment,
    news,
    similar,
    atr: Math.max(range, packet.lastPrice * 0.0018),
    settings: input.settings,
    spreadBps: spread,
  });

  if (input.overrideReason && plan.valid && (skeptic.verdict === "BLOCK" || skeptic.verdict === "DELAY")) {
    skeptic = {
      ...skeptic,
      verdict: "DOWNSIZE",
      sizeFactor: 0.5,
      summary: `Human override logged: ${input.overrideReason} Original verdict stood down to half size. ${skeptic.summary}`,
    };
  }

  const onWatch = input.scored?.status === "WATCH";
  const risk = evaluateRisk({
    plan,
    skeptic,
    settings: input.settings,
    equity: input.equity,
    nav: input.nav,
    positions: input.positions,
    prices: input.prices,
    dayStartNav: input.dayStartNav,
    weekStartNav: input.weekStartNav,
    weeklyLock: input.weeklyLock,
    killed: input.killed,
    entriesPaused: input.entriesPaused,
    newsBlackout: news.blackout,
    spreadBps: spread,
    sizeFactor: plan.valid && onWatch ? skeptic.sizeFactor : 0,
  });
  if (plan.valid && !onWatch) {
    risk.gates.push({
      name: "Watchlist",
      pass: false,
      detail: "Scanner has not promoted this pair. Study only — the executor will not send an order.",
    });
    risk.approved = false;
    risk.reason = "Not on the watchlist.";
  }

  const messages: AgentMessage[] = [];
  const score = input.scored;
  messages.push(
    msg(
      "scanner",
      score ? `Score ${score.score.toFixed(1)} · ${score.status}` : "Unranked",
      score
        ? `${packet.symbol} bias ${score.bias}. Funding extreme ${(score.fundingExtreme * 100).toFixed(0)}, OI burst ${(score.oiBurst * 100).toFixed(0)}, divergence ${(score.divergence * 100).toFixed(0)}, liquidation ${(score.liquidation * 100).toFixed(0)}, book ${(score.book * 100).toFixed(0)}. Dampener ${score.dampener.toFixed(2)}. ${score.status === "WATCH" ? "Promoted." : "Not on the active watchlist — study only, no order."}`
        : `${packet.symbol} was studied without a scanner row.`,
      "info",
      packet.symbol,
      now,
    ),
  );
  messages.push(
    msg(
      "microstructure",
      plan.valid ? `${plan.side} ${plan.setup}` : "NO_TRADE",
      plan.valid
        ? plan.reason
        : plan.reason +
            ` OFI ${flowUse.ofi.toFixed(2)}, imbalance ${flowUse.imbalance.toFixed(2)}, VWAP dev ${(flowUse.vwapDev * 100).toFixed(2)}%, CVD ${flowUse.divergence.toLowerCase()}.`,
      plan.valid ? "info" : "warn",
      packet.symbol,
      now,
    ),
  );
  messages.push(
    msg("chart", chart.dissent ? "Dissent" : "Aligned", chart.summary, chart.dissent ? "warn" : "pass", packet.symbol, now),
  );
  messages.push(
    msg(
      "sentiment",
      sentiment.sameSide ? "Crowded with the trade" : "Positioning",
      sentiment.summary,
      sentiment.sameSide ? "warn" : "info",
      packet.symbol,
      now,
    ),
  );
  messages.push(
    msg("news", news.blackout ? "Blackout" : "Clear", news.summary, news.blackout ? "block" : "info", packet.symbol, now),
  );
  messages.push(
    msg(
      "skeptic",
      skeptic.verdict,
      skeptic.summary,
      skeptic.verdict === "PASS" ? "pass" : skeptic.verdict === "BLOCK" ? "block" : "warn",
      packet.symbol,
      now,
    ),
  );

  let approved = risk.approved && plan.valid && onWatch && skeptic.verdict !== "BLOCK" && skeptic.verdict !== "DELAY";
  let riskReason = risk.reason;
  if (plan.valid && !onWatch) {
    approved = false;
    riskReason = "Not promoted. The scanner has not put this pair on the watchlist, so the executor will not trade it.";
  }
  messages.push(
    msg(
      "risk",
      approved ? "Approved" : "Rejected",
      risk.gates.map((g) => `${g.pass ? "pass" : "fail"} · ${g.name}: ${g.detail}`).join(" "),
      approved ? "pass" : "block",
      packet.symbol,
      now,
    ),
  );

  const memory: SetupMemory | null =
    plan.valid && approved
      ? {
          id: uid("mem"),
          symbol: packet.symbol,
          setup: plan.setup,
          side: plan.side,
          funding: packet.fundingRate,
          ofi: flowUse.ofi,
          imbalance: flowUse.imbalance,
          vwapDev: flowUse.vwapDev,
          rr: plan.rr,
          rMultiple: null,
          outcome: "OPEN",
          ts: now,
        }
      : null;

  const journal: JournalEntry = {
    id: uid("tdr"),
    ts: now,
    kind: input.overrideReason ? "OVERRIDE" : approved ? "DECISION" : "SKIP",
    symbol: packet.symbol,
    title: approved
      ? `Paper ${plan.valid ? plan.side : ""} ${packet.symbol}`
      : `No fill · ${packet.symbol}`,
    body: [
      plan.valid ? plan.reason : plan.reason,
      `Skeptic ${skeptic.verdict}. ${skeptic.summary}`,
      riskReason,
      input.overrideReason ? `Override: ${input.overrideReason}` : "",
      similar.length
        ? `Similar history: ${similar.map((s) => `${s.memory.symbol} ${s.memory.rMultiple?.toFixed(2) ?? "n/a"}R`).join("; ")}.`
        : "",
    ]
      .filter(Boolean)
      .join(" "),
    setup: plan.valid ? plan.setup : undefined,
    plannedRr: plan.valid ? plan.rr : undefined,
  };

  messages.push(
    msg(
      "executor",
      approved ? "Paper bracket armed" : "No order",
      approved && plan.valid
        ? `Isolated paper fill planned. Qty ${risk.qty.toPrecision(4)}, notional ${risk.notional.toFixed(0)}, leverage ${risk.leverage.toFixed(2)}x, stop ${plan.stop.toPrecision(6)}, target ${plan.target.toPrecision(6)}. STOP_MARKET and TAKE_PROFIT_MARKET are attached on the desk book.`
        : riskReason,
      approved ? "pass" : "warn",
      packet.symbol,
      now,
    ),
  );
  messages.push(
    msg(
      "journal",
      "Decision recorded",
      journal.body.slice(0, 420),
      "info",
      packet.symbol,
      now,
    ),
  );

  return {
    messages,
    plan,
    skeptic,
    chart,
    sentiment,
    news,
    flow: flowUse,
    approved,
    qty: approved ? risk.qty : 0,
    leverage: risk.leverage,
    riskReason,
    gates: risk.gates,
    rrNet: risk.rrNet,
    journal,
    memory,
    similar,
  };
}

export function autopsy(pos: Position): string {
  const r = pos.rMultiple ?? 0;
  const planned = Math.abs(pos.target - pos.entry) / Math.max(Math.abs(pos.entry - pos.initialStop), 1e-9);
  const bits = [
    `${pos.symbol} ${pos.side} closed on ${pos.closeReason ?? "mark"} at ${r.toFixed(2)}R (planned structure about ${planned.toFixed(2)}R).`,
    `MAE ${pos.mae.toPrecision(4)}, MFE ${pos.mfe.toPrecision(4)} in price units.`,
    `Funding at entry ${(pos.fundingAtEntry * 100).toFixed(4)}%.`,
  ];
  if (pos.closeReason === "stop") {
    bits.push(
      pos.breakevenArmed
        ? "Stop had already moved to entry. The give-back was a failed follow-through, not the original invalidation."
        : "The structural stop was tagged. If the wick only ran the node and reclaimed, the invalidation was too tight.",
    );
  } else if (pos.closeReason === "target") {
    bits.push("Target tagged the opposing volume node. The path paid.");
  } else if (pos.closeReason === "flow-reversal") {
    bits.push("CVD and aggressive flow flipped before the hard stop. The desk flushed early.");
  } else if (pos.closeReason === "kill") {
    bits.push("Closed by the kill switch at the mark, not by the thesis.");
  }
  if (pos.oiDeltaAtEntry != null && Math.abs(pos.oiDeltaAtEntry) > 0.03) {
    bits.push(`Open interest was ${pos.oiDeltaAtEntry > 0 ? "building" : "unwinding"} into the entry (${(pos.oiDeltaAtEntry * 100).toFixed(1)}%).`);
  }
  return bits.join(" ");
}
