export type Side = "LONG" | "SHORT";
export type Venue = "binance" | "gate" | "sim";
export type Bias = Side | "NEUTRAL";
export type Verdict = "PASS" | "DOWNSIZE" | "DELAY" | "BLOCK";
export type AgentId =
  | "scanner"
  | "microstructure"
  | "chart"
  | "sentiment"
  | "news"
  | "skeptic"
  | "risk"
  | "executor"
  | "journal";

export interface Candle {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
}

export interface TradeTick {
  p: number;
  q: number;
  /** True when the buyer is the maker, i.e. the aggressor sold. */
  m: boolean;
  T: number;
}

export interface UniverseRow {
  symbol: string;
  contract: string;
  venue: Venue;
  lastPrice: number;
  markPrice: number;
  priceChangePct: number;
  quoteVolume: number;
  fundingRate: number;
  nextFundingTime: number | null;
  oi: number | null;
  oiDeltaPct: number | null;
  bookImbalance: number | null;
  longShortRatio: number | null;
  liqCluster: boolean;
  liqNotional: number | null;
}

export interface ScoreParts {
  fundingExtreme: number;
  fundingVelocity: number;
  oiBurst: number;
  divergence: number;
  liquidation: number;
  book: number;
}

export interface ScoredSymbol extends UniverseRow, ScoreParts {
  score: number;
  bias: Bias;
  dampener: number;
  status: "WATCH" | "CANDIDATE" | "IDLE";
}

export interface VolumeBin {
  price: number;
  volume: number;
  share: number;
}

export interface VolumeProfile {
  bins: VolumeBin[];
  poc: number;
  vah: number;
  val: number;
  hvns: number[];
  lvns: number[];
  totalVolume: number;
}

export interface OrderFlow {
  cvd: number;
  cvdSlope: number;
  ofi: number;
  imbalance: number;
  vwap: number;
  vwapDev: number;
  buyVol: number;
  sellVol: number;
  divergence: "BULLISH" | "BEARISH" | "NONE";
}

export interface Confluence {
  ofi: boolean;
  imbalance: boolean;
  vwap: boolean;
  votes: number;
}

export interface TradePlan {
  valid: true;
  symbol: string;
  side: Side;
  entry: number;
  stop: number;
  target: number;
  rr: number;
  setup: string;
  reason: string;
  confluence: Confluence;
  poc: number;
  hvn: number;
  atr: number;
}

export interface NoTrade {
  valid: false;
  symbol: string;
  reason: string;
  confluence: Confluence;
}

export type PlanResult = TradePlan | NoTrade;

export interface MacroEvent {
  id: string;
  name: string;
  at: number;
}

export interface Settings {
  equityStart: number;
  riskPerTradePct: number;
  maxHeatPct: number;
  dailyLossPct: number;
  weeklyLossPct: number;
  minRr: number;
  maxCorrelated: number;
  scoreThreshold: number;
  watchlistSize: number;
  demoteScans: number;
  minQuoteVolume: number;
  newsBlackoutMin: number;
  scanIntervalSec: number;
  feeBps: number;
  slippageBps: number;
  breakevenR: number;
  autoDeliberate: boolean;
  events: MacroEvent[];
}

export interface SkepticObjection {
  code: string;
  severity: "BLOCK" | "DOWNSIZE" | "DELAY" | "NOTE";
  detail: string;
}

export interface SkepticReport {
  verdict: Verdict;
  sizeFactor: number;
  objections: SkepticObjection[];
  summary: string;
}

export interface RiskGate {
  name: string;
  pass: boolean;
  detail: string;
}

export interface RiskDecision {
  approved: boolean;
  reason: string;
  qty: number;
  notional: number;
  riskUsd: number;
  heatAfter: number;
  leverage: number;
  rrNet: number;
  gates: RiskGate[];
}

export interface BracketIntent {
  marginType: "ISOLATED";
  leverage: number;
  venue: "paper";
  entry: { type: "MARKET"; side: "BUY" | "SELL"; quantity: string };
  protection: [
    { type: "STOP_MARKET"; stopPrice: string; closePosition: true },
    { type: "TAKE_PROFIT_MARKET"; stopPrice: string; closePosition: true },
  ];
  note: string;
}

export interface Position {
  id: string;
  symbol: string;
  contract: string;
  side: Side;
  qty: number;
  entry: number;
  stop: number;
  initialStop: number;
  target: number;
  openedAt: number;
  status: "OPEN" | "CLOSED";
  exit?: number;
  closedAt?: number;
  closeReason?: string;
  fees: number;
  realizedPnl?: number;
  rMultiple?: number;
  mae: number;
  mfe: number;
  setup: string;
  fundingAtEntry: number;
  oiDeltaAtEntry: number | null;
  breakevenArmed: boolean;
  bracket: BracketIntent;
  overrideReason?: string;
}

export interface AgentMessage {
  id: string;
  agent: AgentId;
  ts: number;
  symbol?: string;
  title: string;
  body: string;
  tone: "info" | "warn" | "block" | "pass";
}

export interface JournalEntry {
  id: string;
  ts: number;
  kind: "DECISION" | "CLOSE" | "OVERRIDE" | "KILL" | "SKIP";
  symbol?: string;
  title: string;
  body: string;
  rMultiple?: number;
  pnl?: number;
  setup?: string;
  plannedRr?: number;
}

export interface SetupMemory {
  id: string;
  symbol: string;
  setup: string;
  side: Side;
  funding: number;
  ofi: number;
  imbalance: number;
  vwapDev: number;
  rr: number;
  rMultiple: number | null;
  outcome: "OPEN" | "WIN" | "LOSS" | "FLAT" | "SKIP";
  ts: number;
}

export interface MarketPacket {
  symbol: string;
  contract: string;
  venue: Venue;
  lastPrice: number;
  fundingRate: number;
  fundingHistory: { t: number; rate: number }[];
  oi: number | null;
  oiDeltaPct: number | null;
  longShortRatio: number | null;
  liqCluster: boolean;
  liqNotional: number;
  candles5: Candle[];
  candles15: Candle[];
  candles1h: Candle[];
  trades: TradeTick[];
  bids: [number, number][];
  asks: [number, number][];
  headlines: string[];
  spreadBps: number;
  bookImbalance: number;
}

export interface UniverseSnapshot {
  venue: Venue;
  note: string;
  fetchedAt: number;
  headlines: string[];
  rows: UniverseRow[];
  error?: string;
}

export interface Enrichment {
  symbol: string;
  oi: number | null;
  oiDeltaPct: number | null;
  longShortRatio: number | null;
  liqCluster: boolean;
  liqNotional: number;
}

export const AGENT_LABEL: Record<AgentId, string> = {
  scanner: "Universe Scanner",
  microstructure: "Microstructure",
  chart: "Chart / Structure",
  sentiment: "Sentiment",
  news: "News & Macro",
  skeptic: "Skeptic",
  risk: "Risk Engine",
  executor: "Executor",
  journal: "Journal",
};

export const DEFAULT_SETTINGS: Settings = {
  equityStart: 100_000,
  riskPerTradePct: 0.0075,
  maxHeatPct: 0.025,
  dailyLossPct: 0.03,
  weeklyLossPct: 0.06,
  minRr: 2,
  maxCorrelated: 2,
  scoreThreshold: 58,
  watchlistSize: 18,
  demoteScans: 3,
  minQuoteVolume: 2_000_000,
  newsBlackoutMin: 45,
  scanIntervalSec: 40,
  feeBps: 4,
  slippageBps: 2,
  breakevenR: 1,
  autoDeliberate: true,
  events: [],
};
