import { atr, clamp, trendEfficiency } from "./math.ts";
import { buildVolumeProfile } from "./volume-profile.ts";
import type { Candle, Confluence, NoTrade, OrderFlow, PlanResult, Side, TradePlan, VolumeProfile } from "./types.ts";

const EMPTY_CONF: Confluence = { ofi: false, imbalance: false, vwap: false, votes: 0 };

function noTrade(symbol: string, reason: string, confluence: Confluence = EMPTY_CONF): NoTrade {
  return { valid: false, symbol, reason, confluence };
}

function nearest(levels: number[], price: number): number | null {
  if (!levels.length) return null;
  return levels.reduce((best, h) => (Math.abs(h - price) < Math.abs(best - price) ? h : best));
}

/**
 * Structural plan. A trade exists only when order-flow confluence aligns AND
 * the next volume node pays the configured R:R against a real invalidation.
 * Otherwise the agent stands down. It does not invent an R multiple.
 */
export function planTrade(input: {
  symbol: string;
  price: number;
  candles: Candle[];
  candlesHtf: Candle[];
  flow: OrderFlow;
  minRr: number;
  profile?: VolumeProfile;
}): PlanResult {
  const { symbol, price, candles, flow } = input;
  if (!(price > 0) || candles.length < 20) {
    return noTrade(symbol, "Not enough execution-timeframe tape to build a profile.");
  }

  const htf = input.candlesHtf.length >= 12 ? input.candlesHtf : candles;
  const efficiency = trendEfficiency(htf);
  if (efficiency < 0.16) {
    return noTrade(
      symbol,
      `Regime gate: higher-timeframe efficiency ${efficiency.toFixed(2)} is chop. No trade until a direction exists.`,
    );
  }

  const ofiLong = flow.ofi > 0.07;
  const ofiShort = flow.ofi < -0.07;
  const imbLong = flow.imbalance > 0.07;
  const imbShort = flow.imbalance < -0.07;
  const vwapLong = flow.vwapDev > -0.004 && flow.vwapDev < 0.009;
  const vwapShort = flow.vwapDev < 0.004 && flow.vwapDev > -0.009;
  const longVotes = [ofiLong, imbLong, vwapLong].filter(Boolean).length;
  const shortVotes = [ofiShort, imbShort, vwapShort].filter(Boolean).length;

  let side: Side | null = null;
  let confluence: Confluence = EMPTY_CONF;
  if (longVotes >= 2 && longVotes > shortVotes) {
    side = "LONG";
    confluence = { ofi: ofiLong, imbalance: imbLong, vwap: vwapLong, votes: longVotes };
  } else if (shortVotes >= 2 && shortVotes > longVotes) {
    side = "SHORT";
    confluence = { ofi: ofiShort, imbalance: imbShort, vwap: vwapShort, votes: shortVotes };
  }
  if (!side) {
    return noTrade(
      symbol,
      "Confluence gate: OFI, volume imbalance, and VWAP deviation do not agree. Standing down.",
      {
        ofi: false,
        imbalance: false,
        vwap: false,
        votes: Math.max(longVotes, shortVotes),
      },
    );
  }

  const profile = input.profile ?? buildVolumeProfile(candles);
  const range = atr(candles, 14);
  const a = Math.max(range, price * 0.0018);
  const anchor = nearest([...profile.hvns, profile.poc], price);
  if (anchor == null || Math.abs(anchor - price) > a * 0.95) {
    return noTrade(
      symbol,
      "Price is not interacting with a high-volume node or the POC. No structural entry.",
      confluence,
    );
  }

  const dir = side === "LONG" ? 1 : -1;
  const entry = clampToward(price, anchor, a * 0.15);
  const defensive = profile.hvns.filter((h) => (entry - h) * dir > a * 0.05);
  const swing = side === "LONG" ? Math.min(...candles.slice(-24).map((c) => c.l)) : Math.max(...candles.slice(-24).map((c) => c.h));
  const node = nearest(defensive, entry);
  let stop =
    side === "LONG"
      ? Math.min(swing, (node ?? entry) - a * 0.22)
      : Math.max(swing, (node ?? entry) + a * 0.22);

  const minDist = a * 0.42;
  const maxDist = a * 4.2;
  let dist = (entry - stop) * dir;
  if (dist < minDist) {
    stop = entry - dir * minDist;
    dist = minDist;
  }
  if (dist > maxDist) {
    return noTrade(
      symbol,
      "The structural invalidation is too far away to size without pretending the stop is closer.",
      confluence,
    );
  }

  const favorable = [
    ...profile.hvns.filter((h) => (h - entry) * dir > a * 0.45),
    (profile.poc - entry) * dir > a * 0.45 ? profile.poc : NaN,
    side === "LONG" ? profile.vah : profile.val,
  ].filter((t) => Number.isFinite(t) && (t - entry) * dir > 0);

  const unique = [...new Set(favorable.map((t) => Number(t.toFixed(8))))].sort((x, y) => (x - y) * dir);
  const minRr = input.minRr;
  let target: number | null = null;
  for (const t of unique) {
    const reward = (t - entry) * dir;
    if (reward / dist >= minRr) {
      target = t;
      break;
    }
  }
  if (target == null) {
    const best = unique[unique.length - 1];
    const bestRr = best != null ? ((best - entry) * dir) / dist : 0;
    return noTrade(
      symbol,
      `No volume node pays ${minRr.toFixed(1)}R. Best structural target is ${bestRr.toFixed(2)}R. Refusing to stretch the target.`,
      confluence,
    );
  }

  const rr = ((target - entry) * dir) / dist;
  const setup = setupName(profile, entry, a, side);
  const plan: TradePlan = {
    valid: true,
    symbol,
    side,
    entry,
    stop,
    target,
    rr,
    setup,
    reason: prose(side, setup, confluence, rr, profile),
    confluence,
    poc: profile.poc,
    hvn: anchor,
    atr: a,
  };
  return plan;
}

function clampToward(price: number, anchor: number, maxShift: number): number {
  const delta = clamp(anchor - price, -maxShift, maxShift);
  return price + delta * 0.35;
}

function setupName(profile: VolumeProfile, entry: number, a: number, _side: Side): string {
  const hvn = nearest(profile.hvns, entry);
  if (hvn != null && Math.abs(hvn - entry) <= a * 0.35) return "HVN edge";
  const lvn = nearest(profile.lvns, entry);
  if (lvn != null && Math.abs(lvn - entry) <= a * 0.35) return "LVN rejection";
  if (Math.abs(profile.poc - entry) <= a * 0.5) return "POC response";
  return "Node path";
}

function prose(side: Side, setup: string, c: Confluence, rr: number, profile: VolumeProfile): string {
  const bits = [
    c.ofi ? "OFI" : null,
    c.imbalance ? "tape imbalance" : null,
    c.vwap ? "VWAP location" : null,
  ].filter(Boolean);
  return `${side === "LONG" ? "Long" : "Short"} ${setup}. Confluence ${c.votes}/3 (${bits.join(", ")}). Target is the next volume node, not a fixed multiple — structural R:R ${rr.toFixed(2)} against invalidation beyond the defending node. POC ${profile.poc.toPrecision(6)}.`;
}
