import { clamp } from "./math.ts";
import type { Bias, ScoredSymbol, Settings, UniverseRow } from "./types.ts";

export interface ScoreContext {
  prevFunding?: number;
  dampener?: number;
}

/**
 * Composite opportunity score, 0–100.
 * Direction is contrarian to crowded funding: extreme positive funding biases SHORT.
 * Missing OI does not zero the score — weights shift onto funding, divergence, and the book.
 */
export function scoreSymbol(row: UniverseRow, ctx: ScoreContext = {}): ScoredSymbol {
  const f = row.fundingRate;
  const longCrowd = clamp(f / 0.0005, 0, 1);
  const shortCrowd = clamp(-f / 0.0004, 0, 1);
  const fundingExtreme = Math.max(longCrowd, shortCrowd);
  let bias: Bias = "NEUTRAL";
  if (longCrowd >= shortCrowd && longCrowd >= 0.35) bias = "SHORT";
  else if (shortCrowd > longCrowd && shortCrowd >= 0.35) bias = "LONG";

  const prev = ctx.prevFunding;
  const fundingVelocity =
    prev == null || !Number.isFinite(prev) ? 0 : clamp(Math.abs(f - prev) / 0.00015, 0, 1);

  const oiBurst =
    row.oiDeltaPct == null ? 0 : clamp(Math.abs(row.oiDeltaPct) / 0.08, 0, 1);

  let divergence = 0;
  const stalled = Math.abs(row.priceChangePct) < 1.4;
  if (row.oiDeltaPct != null && row.oiDeltaPct > 0.02 && Math.abs(row.priceChangePct) < 1.5) {
    divergence = 0.9;
    if (bias === "NEUTRAL") bias = row.priceChangePct <= 0 ? "SHORT" : "LONG";
  } else if (f > 0.00025 && row.priceChangePct < -0.8) divergence = 0.75;
  else if (f < -0.0002 && row.priceChangePct > 0.8) divergence = 0.75;
  else if (fundingExtreme > 0.55 && stalled) divergence = 0.62;

  let liquidation = 0;
  if (row.liqCluster) liquidation = 1;
  else if (Math.abs(row.priceChangePct) > 7 && fundingExtreme > 0.45) liquidation = 0.85;
  else if (Math.abs(row.priceChangePct) > 12) liquidation = 0.45;

  const book = row.bookImbalance == null ? 0 : clamp(Math.abs(row.bookImbalance), 0, 1);

  const w =
    row.oiDeltaPct == null
      ? { f: 0.4, v: 0.14, o: 0, d: 0.2, l: 0.16, b: 0.1 }
      : { f: 0.26, v: 0.1, o: 0.24, d: 0.18, l: 0.12, b: 0.1 };

  const raw =
    w.f * fundingExtreme +
    w.v * fundingVelocity +
    w.o * oiBurst +
    w.d * divergence +
    w.l * liquidation +
    w.b * book;

  const dampener = clamp(ctx.dampener ?? 1, 0.55, 1.15);
  const score = clamp(raw * 100 * dampener, 0, 100);

  return {
    ...row,
    fundingExtreme,
    fundingVelocity,
    oiBurst,
    divergence,
    liquidation,
    book,
    score,
    bias,
    dampener,
    status: "IDLE",
  };
}

export function rankUniverse(
  rows: UniverseRow[],
  fundingMemory: Record<string, number>,
  dampeners: Record<string, number>,
): ScoredSymbol[] {
  return rows
    .map((row) =>
      scoreSymbol(row, {
        prevFunding: fundingMemory[row.symbol],
        dampener: dampeners[row.symbol] ?? 1,
      }),
    )
    .sort((a, b) => b.score - a.score || b.quoteVolume - a.quoteVolume);
}

export interface WatchState {
  below: number;
  active: boolean;
}

/** Promote liquid names over the score floor; demote only after M consecutive misses. */
export function nextWatch(
  ranked: ScoredSymbol[],
  prev: Record<string, WatchState>,
  settings: Pick<Settings, "scoreThreshold" | "watchlistSize" | "demoteScans" | "minQuoteVolume">,
): { state: Record<string, WatchState>; symbols: string[] } {
  const state: Record<string, WatchState> = {};
  const active: ScoredSymbol[] = [];

  for (const row of ranked) {
    const prior = prev[row.symbol] ?? { below: 0, active: false };
    const liquid = row.quoteVolume >= settings.minQuoteVolume;
    const hot = row.score >= settings.scoreThreshold && liquid;
    let rec: WatchState;
    if (hot) rec = { below: 0, active: true };
    else if (prior.active) {
      const below = prior.below + 1;
      rec = { below, active: below < settings.demoteScans };
    } else rec = { below: 0, active: false };
    state[row.symbol] = rec;
    if (rec.active) active.push(row);
  }

  active.sort((a, b) => b.score - a.score);
  const symbols = active.slice(0, settings.watchlistSize).map((r) => r.symbol);
  const keep = new Set(symbols);
  for (const sym of Object.keys(state)) {
    if (state[sym].active && !keep.has(sym)) state[sym] = { ...state[sym], active: false };
  }
  return { state, symbols };
}

export function withStatus(ranked: ScoredSymbol[], watch: Set<string>, settings: Settings): ScoredSymbol[] {
  return ranked.map((row) => ({
    ...row,
    status: watch.has(row.symbol)
      ? "WATCH"
      : row.score >= settings.scoreThreshold * 0.85 && row.quoteVolume >= settings.minQuoteVolume
        ? "CANDIDATE"
        : "IDLE",
  }));
}

export function dampenersFromMemory(
  memories: { symbol: string; rMultiple: number | null }[],
): Record<string, number> {
  const by = new Map<string, number[]>();
  for (const m of memories) {
    if (m.rMultiple == null) continue;
    const arr = by.get(m.symbol) ?? [];
    arr.push(m.rMultiple);
    by.set(m.symbol, arr);
  }
  const out: Record<string, number> = {};
  for (const [symbol, rs] of by) {
    if (rs.length < 3) continue;
    const wins = rs.filter((r) => r > 0).length / rs.length;
    const avg = rs.reduce((a, b) => a + b, 0) / rs.length;
    if (wins < 0.34 && avg < 0) out[symbol] = 0.68;
    else if (wins > 0.62 && avg > 0.35) out[symbol] = 1.08;
  }
  return out;
}
