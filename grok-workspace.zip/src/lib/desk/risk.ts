import type { PlanResult, Position, RiskDecision, Settings, SkepticReport, TradePlan } from "./types.ts";

const MAJORS = new Set(["BTCUSDT", "ETHUSDT"]);

export function openRiskUsd(pos: Position): number {
  return Math.abs(pos.entry - pos.stop) * pos.qty;
}

export function unrealizedPnl(pos: Position, price: number): number {
  if (!(price > 0)) return 0;
  const dir = pos.side === "LONG" ? 1 : -1;
  return (price - pos.entry) * dir * pos.qty;
}

export function navOf(equity: number, positions: Position[], prices: Record<string, number>): number {
  let u = 0;
  for (const p of positions) {
    if (p.status !== "OPEN") continue;
    u += unrealizedPnl(p, prices[p.symbol] ?? p.entry);
  }
  return equity + u;
}

export function evaluateRisk(input: {
  plan: PlanResult;
  skeptic: SkepticReport | null;
  settings: Settings;
  equity: number;
  nav: number;
  positions: Position[];
  prices: Record<string, number>;
  dayStartNav: number;
  weekStartNav: number;
  weeklyLock: boolean;
  killed: boolean;
  entriesPaused: boolean;
  newsBlackout: boolean;
  spreadBps: number;
  sizeFactor: number;
}): RiskDecision {
  const gates: RiskDecision["gates"] = [];
  const fail = (name: string, detail: string) => gates.push({ name, pass: false, detail });
  const ok = (name: string, detail: string) => gates.push({ name, pass: true, detail });

  if (input.killed) fail("Kill switch", "Entries halted. Flatten is armed until you resume.");
  else ok("Kill switch", "Clear.");

  if (input.weeklyLock) fail("Weekly loss", "Weekly loss limit is latched. Manual acknowledgement required.");
  else ok("Weekly loss", "Within the weekly budget.");

  const dayDd = input.dayStartNav > 0 ? (input.dayStartNav - input.nav) / input.dayStartNav : 0;
  const weekDd = input.weekStartNav > 0 ? (input.weekStartNav - input.nav) / input.weekStartNav : 0;
  if (dayDd >= input.settings.dailyLossPct) {
    fail("Daily loss", `Day drawdown ${(dayDd * 100).toFixed(2)}% has hit the ${ (input.settings.dailyLossPct * 100).toFixed(1)}% halt.`);
  } else ok("Daily loss", `Day drawdown ${(Math.max(0, dayDd) * 100).toFixed(2)}%.`);

  if (weekDd >= input.settings.weeklyLossPct) {
    fail("Weekly loss", `Week drawdown ${(weekDd * 100).toFixed(2)}% breaches the hard pause.`);
  }

  if (input.entriesPaused) fail("Pause", "New entries are paused.");
  else if (!input.killed && !input.weeklyLock) ok("Pause", "Entries enabled.");

  if (input.newsBlackout) fail("News blackout", "Inside the configured high-impact window.");
  else ok("News blackout", "No blackout.");

  if (!input.plan.valid) {
    fail("Structure", input.plan.reason);
    return rejected(input.plan.reason, gates);
  }
  const plan = input.plan;

  if (input.skeptic && (input.skeptic.verdict === "BLOCK" || input.skeptic.verdict === "DELAY")) {
    fail("Skeptic", `${input.skeptic.verdict}. ${input.skeptic.summary}`);
  } else if (input.skeptic) {
    ok("Skeptic", `${input.skeptic.verdict}. ${input.skeptic.summary}`);
  } else fail("Skeptic", "No skeptic report. Execution refused.");

  const structural = structuralRr(plan);
  if (structural < input.settings.minRr) {
    fail(
      "R:R floor",
      `Recomputed structural R:R is ${structural.toFixed(2)}, below ${input.settings.minRr.toFixed(1)}. The agent's claim is ignored.`,
    );
  } else ok("R:R floor", `Structural R:R ${structural.toFixed(2)} from the actual levels.`);

  const stopDist = Math.abs(plan.entry - plan.stop);
  if (!(stopDist > 0) || stopDist / plan.entry < 0.001) {
    fail("Stop distance", "Stop is inside noise relative to price.");
  } else ok("Stop distance", `Invalidation is ${((stopDist / plan.entry) * 100).toFixed(2)}% away.`);

  const slip = (input.settings.slippageBps + Math.max(0, input.spreadBps - 1.5) * 0.5) / 10_000;
  const fee = (input.settings.feeBps * 2) / 10_000;
  const dir = plan.side === "LONG" ? 1 : -1;
  const entryPx = plan.entry * (1 + slip * dir);
  const targetPx = plan.target * (1 - slip * dir);
  const stopPx = plan.stop * (1 - slip * dir);
  const riskPerUnit = (entryPx - stopPx) * dir;
  const rewardPerUnit = (targetPx - entryPx) * dir - entryPx * fee;
  const rrNet = riskPerUnit > 0 ? rewardPerUnit / riskPerUnit : 0;
  if (rrNet < input.settings.minRr) {
    fail("Slippage", `After spread, slippage, and fees the R:R is ${rrNet.toFixed(2)}. Skipped.`);
  } else ok("Slippage", `Net R:R ${rrNet.toFixed(2)} after costs. Spread ${input.spreadBps.toFixed(1)} bps.`);

  const factor = clampFactor(input.sizeFactor);
  let riskUsd = input.nav * input.settings.riskPerTradePct * factor;
  let qty = riskPerUnit > 0 ? riskUsd / riskPerUnit : 0;
  const maxLev = 5;
  const lev0 = input.nav > 0 ? (qty * entryPx) / input.nav : 99;
  if (lev0 > maxLev && entryPx > 0) {
    qty = (input.nav * maxLev) / entryPx;
    riskUsd = qty * riskPerUnit;
    ok("Leverage cap", `Size cut so isolated leverage stays at ${maxLev}x.`);
  } else ok("Leverage cap", `Implied leverage ${lev0.toFixed(2)}x.`);

  const thisRisk = qty * Math.abs(entryPx - plan.stop);
  let heat = thisRisk;
  for (const p of input.positions) {
    if (p.status !== "OPEN") continue;
    heat += openRiskUsd(p);
  }
  const heatPct = input.nav > 0 ? heat / input.nav : 1;
  if (heatPct > input.settings.maxHeatPct && thisRisk > 0) {
    const room = input.settings.maxHeatPct * input.nav - (heat - thisRisk);
    if (room <= input.nav * 0.001) {
      fail("Portfolio heat", `Open risk already uses the ${(input.settings.maxHeatPct * 100).toFixed(1)}% heat budget.`);
    } else {
      const scale = room / thisRisk;
      qty *= scale;
      riskUsd *= scale;
      heat = input.settings.maxHeatPct * input.nav;
      ok("Portfolio heat", "Downsized to fit inside remaining heat.");
    }
  } else ok("Portfolio heat", `Heat after fill ${(heatPct * 100).toFixed(2)}%.`);

  const sameSideAlts = input.positions.filter(
    (p) =>
      p.status === "OPEN" &&
      p.side === plan.side &&
      !MAJORS.has(p.symbol) &&
      !MAJORS.has(plan.symbol),
  ).length;
  if (!MAJORS.has(plan.symbol) && sameSideAlts >= input.settings.maxCorrelated) {
    fail(
      "Correlation",
      `${sameSideAlts} correlated alt positions already point ${plan.side}. Cap is ${input.settings.maxCorrelated}.`,
    );
  } else ok("Correlation", "Beta bucket has room.");

  const approved = gates.every((g) => g.pass) && qty > 0 && riskUsd > 0;
  const notional = qty * entryPx;
  const leverage = input.nav > 0 ? notional / input.nav : 0;
  const reason = approved
    ? `Approved. Risk ${riskUsd.toFixed(2)} USDT, heat ${((heat / Math.max(input.nav, 1)) * 100).toFixed(2)}%.`
    : (gates.find((g) => !g.pass)?.detail ?? "Rejected.");

  return {
    approved,
    reason,
    qty: approved ? qty : 0,
    notional: approved ? notional : 0,
    riskUsd: approved ? qty * Math.abs(entryPx - plan.stop) : 0,
    heatAfter: input.nav > 0 ? heat / input.nav : 0,
    leverage,
    rrNet,
    gates,
  };
}

function structuralRr(plan: TradePlan): number {
  const risk = Math.abs(plan.entry - plan.stop);
  const reward = Math.abs(plan.target - plan.entry);
  if (!(risk > 0)) return 0;
  const rightSide =
    plan.side === "LONG" ? plan.stop < plan.entry && plan.target > plan.entry : plan.stop > plan.entry && plan.target < plan.entry;
  if (!rightSide) return 0;
  return reward / risk;
}

function rejected(reason: string, gates: RiskDecision["gates"]): RiskDecision {
  return {
    approved: false,
    reason,
    qty: 0,
    notional: 0,
    riskUsd: 0,
    heatAfter: 0,
    leverage: 0,
    rrNet: 0,
    gates,
  };
}

function clampFactor(n: number): number {
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.min(1, n);
}

export function dailyBreach(nav: number, dayStartNav: number, settings: Settings): boolean {
  if (!(dayStartNav > 0)) return false;
  return (dayStartNav - nav) / dayStartNav >= settings.dailyLossPct;
}

export function weeklyBreach(nav: number, weekStartNav: number, settings: Settings): boolean {
  if (!(weekStartNav > 0)) return false;
  return (weekStartNav - nav) / weekStartNav >= settings.weeklyLossPct;
}
