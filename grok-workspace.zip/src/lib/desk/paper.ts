import { uid } from "./math.ts";
import type { BracketIntent, OrderFlow, Position, Settings, TradePlan } from "./types.ts";

export interface OpenResult {
  position: Position;
  fee: number;
}

export function buildBracket(plan: TradePlan, qty: number, leverage: number): BracketIntent {
  const side = plan.side === "LONG" ? "BUY" : "SELL";
  return {
    marginType: "ISOLATED",
    leverage: Math.max(1, Math.round(leverage * 100) / 100),
    venue: "paper",
    entry: { type: "MARKET", side, quantity: qty.toFixed(6) },
    protection: [
      { type: "STOP_MARKET", stopPrice: plan.stop.toPrecision(8), closePosition: true },
      { type: "TAKE_PROFIT_MARKET", stopPrice: plan.target.toPrecision(8), closePosition: true },
    ],
    note: "Paper venue. A live worker would submit these as native Binance brackets before returning, so the position survives a dead process. This desk enforces the same prices on every mark.",
  };
}

export function openPaper(input: {
  plan: TradePlan;
  qty: number;
  leverage: number;
  settings: Settings;
  fundingRate: number;
  oiDeltaPct: number | null;
  contract: string;
  now?: number;
  overrideReason?: string;
}): OpenResult {
  const { plan, qty, settings } = input;
  const slip = settings.slippageBps / 10_000;
  const dir = plan.side === "LONG" ? 1 : -1;
  const fill = plan.entry * (1 + slip * dir);
  const fee = Math.abs(fill * qty) * (settings.feeBps / 10_000);
  const position: Position = {
    id: uid("pos"),
    symbol: plan.symbol,
    contract: input.contract,
    side: plan.side,
    qty,
    entry: fill,
    stop: plan.stop,
    initialStop: plan.stop,
    target: plan.target,
    openedAt: input.now ?? Date.now(),
    status: "OPEN",
    fees: fee,
    mae: 0,
    mfe: 0,
    setup: plan.setup,
    fundingAtEntry: input.fundingRate,
    oiDeltaAtEntry: input.oiDeltaPct,
    breakevenArmed: false,
    bracket: buildBracket(plan, qty, input.leverage),
    overrideReason: input.overrideReason,
  };
  return { position, fee };
}

export interface MarkResult {
  position: Position;
  closed: boolean;
  /** Cash change from the close (pnl net of exit fee). Entry fee was already taken. */
  cashDelta: number;
}

/**
 * Enforce stop, target, and breakeven on a single mark.
 * If both stop and target are touched (gap), the stop wins.
 */
export function markPosition(pos: Position, price: number, settings: Settings, now = Date.now()): MarkResult {
  if (pos.status !== "OPEN" || !(price > 0)) return { position: pos, closed: false, cashDelta: 0 };
  const dir = pos.side === "LONG" ? 1 : -1;
  const excursion = (price - pos.entry) * dir;
  const next: Position = {
    ...pos,
    mae: Math.min(pos.mae, excursion),
    mfe: Math.max(pos.mfe, excursion),
  };
  const riskUnit = Math.abs(next.entry - next.initialStop);
  const rNow = riskUnit > 0 ? excursion / riskUnit : 0;
  if (!next.breakevenArmed && rNow >= settings.breakevenR) {
    next.stop = next.entry;
    next.breakevenArmed = true;
    next.bracket = {
      ...next.bracket,
      protection: [
        { type: "STOP_MARKET", stopPrice: next.stop.toPrecision(8), closePosition: true },
        next.bracket.protection[1],
      ],
    };
  }

  const hitStop = dir === 1 ? price <= next.stop : price >= next.stop;
  const hitTarget = dir === 1 ? price >= next.target : price <= next.target;
  if (hitStop) return closeAt(next, next.stop, "stop", settings, now);
  if (hitTarget) return closeAt(next, next.target, "target", settings, now);
  return { position: next, closed: false, cashDelta: 0 };
}

/** Exit before the hard stop when tape and CVD both flip. Never worse than the stop. */
export function flowExit(pos: Position, flow: OrderFlow, price: number, settings: Settings, now = Date.now()): MarkResult {
  if (pos.status !== "OPEN") return { position: pos, closed: false, cashDelta: 0 };
  const againstFlow = pos.side === "LONG" ? flow.ofi < -0.18 : flow.ofi > 0.18;
  const againstCvd =
    pos.side === "LONG" ? flow.divergence === "BEARISH" || flow.cvdSlope < 0 : flow.divergence === "BULLISH" || flow.cvdSlope > 0;
  if (!againstFlow || !againstCvd) return { position: pos, closed: false, cashDelta: 0 };
  const dir = pos.side === "LONG" ? 1 : -1;
  const worseThanStop = dir === 1 ? price <= pos.stop : price >= pos.stop;
  if (worseThanStop) return markPosition(pos, price, settings, now);
  return closeAt(pos, price, "flow-reversal", settings, now);
}

function closeAt(pos: Position, exit: number, reason: string, settings: Settings, now: number): MarkResult {
  const dir = pos.side === "LONG" ? 1 : -1;
  const slip = settings.slippageBps / 10_000;
  const filled = exit * (1 - slip * dir);
  const exitFee = Math.abs(filled * pos.qty) * (settings.feeBps / 10_000);
  const gross = (filled - pos.entry) * dir * pos.qty;
  const realized = gross - exitFee;
  const riskCash = Math.abs(pos.entry - pos.initialStop) * pos.qty;
  const rMultiple = riskCash > 0 ? (gross - pos.fees - exitFee) / riskCash : 0;
  const closed: Position = {
    ...pos,
    status: "CLOSED",
    exit: filled,
    closedAt: now,
    closeReason: reason,
    fees: pos.fees + exitFee,
    realizedPnl: gross - exitFee - pos.fees,
    rMultiple,
  };
  // Entry fee already left cash at the open. Close only settles gross minus the exit fee.
  return { position: closed, closed: true, cashDelta: gross - exitFee };
}

export function flatten(pos: Position, price: number, reason: string, settings: Settings, now = Date.now()): MarkResult {
  if (pos.status !== "OPEN" || !(price > 0)) return { position: pos, closed: false, cashDelta: 0 };
  return closeAt(pos, price, reason, settings, now);
}
