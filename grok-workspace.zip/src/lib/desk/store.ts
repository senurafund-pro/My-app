import { create } from "zustand";
import { persist } from "zustand/middleware";
import { autopsy, decide, type Decision } from "./agents.ts";
import { dayKey, uid, weekKey } from "./math.ts";
import { flatten, flowExit, markPosition, openPaper } from "./paper.ts";
import { dailyBreach, navOf, unrealizedPnl, weeklyBreach } from "./risk.ts";
import { nextWatch, type WatchState } from "./scanner.ts";
import {
  DEFAULT_SETTINGS,
  type AgentMessage,
  type JournalEntry,
  type MacroEvent,
  type MarketPacket,
  type OrderFlow,
  type PlanResult,
  type Position,
  type ScoredSymbol,
  type Settings,
  type SetupMemory,
  type SkepticReport,
} from "./types.ts";

export interface CurvePoint {
  t: number;
  nav: number;
}

interface DeskState {
  settings: Settings;
  equity: number;
  dayKey: string;
  weekKey: string;
  dayStartNav: number;
  weekStartNav: number;
  weeklyLock: boolean;
  killed: boolean;
  entriesPaused: boolean;
  pauseReason: string;
  positions: Position[];
  journal: JournalEntry[];
  messages: AgentMessage[];
  memories: SetupMemory[];
  curve: CurvePoint[];
  fundingMemory: Record<string, number>;
  watch: Record<string, WatchState>;
  deliberating: boolean;
  lastSymbol: string | null;
  lastPlan: PlanResult | null;
  lastSkeptic: SkepticReport | null;
  lastFlow: OrderFlow | null;
  busySymbol: string | null;

  commitScan: (ranked: ScoredSymbol[]) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  addEvent: (event: MacroEvent) => void;
  removeEvent: (id: string) => void;
  applyDecision: (decision: Decision, packet: MarketPacket) => void;
  markPrices: (prices: Record<string, number>) => void;
  reviewFlow: (symbol: string, flow: OrderFlow, price: number) => void;
  kill: (prices: Record<string, number>) => void;
  resumeEntries: () => void;
  acknowledgeWeek: () => void;
  resetAccount: () => void;
  setDeliberating: (symbol: string | null) => void;
}

function freshClock(equity: number) {
  const now = new Date();
  return {
    equity,
    dayKey: dayKey(now),
    weekKey: weekKey(now),
    dayStartNav: equity,
    weekStartNav: equity,
    weeklyLock: false,
    killed: false,
    entriesPaused: false,
    pauseReason: "",
    positions: [] as Position[],
    journal: [] as JournalEntry[],
    messages: [] as AgentMessage[],
    memories: [] as SetupMemory[],
    curve: [{ t: Date.now(), nav: equity }] as CurvePoint[],
    fundingMemory: {} as Record<string, number>,
    watch: {} as Record<string, WatchState>,
  };
}

function pushCurve(curve: CurvePoint[], nav: number): CurvePoint[] {
  const last = curve[curve.length - 1];
  if (last && Date.now() - last.t < 20_000 && Math.abs(last.nav - nav) < 0.5) return curve;
  return [...curve, { t: Date.now(), nav }].slice(-400);
}

export const useDesk = create<DeskState>()(
  persist(
    (set) => ({
      settings: DEFAULT_SETTINGS,
      ...freshClock(DEFAULT_SETTINGS.equityStart),
      deliberating: false,
      lastSymbol: null,
      lastPlan: null,
      lastSkeptic: null,
      lastFlow: null,
      busySymbol: null,

      commitScan: (ranked) =>
        set((s) => {
          const { state } = nextWatch(ranked, s.watch, s.settings);
          const fundingMemory: Record<string, number> = {};
          for (const row of ranked.slice(0, 250)) fundingMemory[row.symbol] = row.fundingRate;
          return { watch: state, fundingMemory };
        }),

      patchSettings: (patch) =>
        set((s) => ({
          settings: {
            ...s.settings,
            ...patch,
            riskPerTradePct: clampNum(patch.riskPerTradePct ?? s.settings.riskPerTradePct, 0.002, 0.01),
            maxHeatPct: clampNum(patch.maxHeatPct ?? s.settings.maxHeatPct, 0.005, 0.05),
            dailyLossPct: clampNum(patch.dailyLossPct ?? s.settings.dailyLossPct, 0.005, 0.1),
            weeklyLossPct: clampNum(patch.weeklyLossPct ?? s.settings.weeklyLossPct, 0.01, 0.2),
            minRr: clampNum(patch.minRr ?? s.settings.minRr, 1.2, 5),
            scoreThreshold: clampNum(patch.scoreThreshold ?? s.settings.scoreThreshold, 30, 90),
            events: patch.events ?? s.settings.events,
          },
        })),

      addEvent: (event) => set((s) => ({ settings: { ...s.settings, events: [...s.settings.events, event].slice(-20) } })),
      removeEvent: (id) =>
        set((s) => ({ settings: { ...s.settings, events: s.settings.events.filter((e) => e.id !== id) } })),

      setDeliberating: (symbol) => set({ deliberating: Boolean(symbol), busySymbol: symbol }),

      applyDecision: (decision, packet) =>
        set((s) => {
          let equity = s.equity;
          let positions = s.positions;
          const memories = decision.memory ? [decision.memory, ...s.memories].slice(0, 200) : s.memories;
          if (decision.approved && decision.plan.valid && decision.qty > 0) {
            const already = positions.some((p) => p.status === "OPEN" && p.symbol === packet.symbol);
            if (!already) {
              const opened = openPaper({
                plan: decision.plan,
                qty: decision.qty,
                leverage: Math.max(1, decision.leverage),
                settings: s.settings,
                fundingRate: packet.fundingRate,
                oiDeltaPct: packet.oiDeltaPct,
                contract: packet.contract,
                overrideReason: decision.journal.kind === "OVERRIDE" ? decision.journal.body : undefined,
              });
              equity -= opened.fee;
              positions = [opened.position, ...positions];
            }
          }
          return {
            equity,
            positions,
            memories,
            messages: [...decision.messages, ...s.messages].slice(0, 140),
            journal: [decision.journal, ...s.journal].slice(0, 300),
            lastSymbol: packet.symbol,
            lastPlan: decision.plan,
            lastSkeptic: decision.skeptic,
            lastFlow: decision.flow,
            deliberating: false,
            busySymbol: null,
          };
        }),

      markPrices: (prices) =>
        set((s) => {
          const rolled = rollLimits(s, prices);
          let equity = rolled.equity;
          const journal = [...rolled.journal];
          const messages = [...rolled.messages];
          const memories = rolled.memories.map((m) => ({ ...m }));
          const positions: Position[] = [];
          for (const pos of rolled.positions) {
            if (pos.status !== "OPEN") {
              positions.push(pos);
              continue;
            }
            const px = prices[pos.symbol];
            if (!(px > 0)) {
              positions.push(pos);
              continue;
            }
            const marked = markPosition(pos, px, rolled.settings);
            if (marked.closed) {
              equity += marked.cashDelta;
              positions.push(marked.position);
              settleClose(marked.position, memories, journal, messages);
            } else positions.push(marked.position);
          }
          const nav = navOf(equity, positions, prices);
          return {
            ...applyBreaches({ ...rolled, equity, positions, journal, messages, memories }, nav),
            curve: pushCurve(rolled.curve, nav),
          };
        }),

      reviewFlow: (symbol, flow, price) =>
        set((s) => {
          const idx = s.positions.findIndex((p) => p.status === "OPEN" && p.symbol === symbol);
          if (idx < 0) return {};
          const marked = flowExit(s.positions[idx], flow, price, s.settings);
          if (!marked.closed) return {};
          const positions = s.positions.slice();
          positions[idx] = marked.position;
          const memories = s.memories.map((m) => ({ ...m }));
          const journal = [...s.journal];
          const messages = [...s.messages];
          settleClose(marked.position, memories, journal, messages);
          const equity = s.equity + marked.cashDelta;
          return { positions, memories, journal: journal.slice(0, 300), messages: messages.slice(0, 140), equity };
        }),

      kill: (prices) =>
        set((s) => {
          let equity = s.equity;
          const journal = [...s.journal];
          const messages = [...s.messages];
          const memories = s.memories.map((m) => ({ ...m }));
          const positions = s.positions.map((pos) => {
            if (pos.status !== "OPEN") return pos;
            const px = prices[pos.symbol] ?? pos.entry;
            const marked = flatten(pos, px, "kill", s.settings);
            if (!marked.closed) return pos;
            equity += marked.cashDelta;
            settleClose(marked.position, memories, journal, messages);
            return marked.position;
          });
          const entry: JournalEntry = {
            id: uid("kill"),
            ts: Date.now(),
            kind: "KILL",
            title: "Kill switch",
            body: "All paper positions flattened at the mark. Open brackets cancelled. New entries halted.",
          };
          messages.unshift({
            id: uid("risk"),
            agent: "risk",
            ts: Date.now(),
            title: "Kill switch",
            body: entry.body,
            tone: "block",
          });
          return {
            equity,
            positions,
            memories,
            journal: [entry, ...journal].slice(0, 300),
            messages: messages.slice(0, 140),
            killed: true,
            entriesPaused: true,
            pauseReason: "Kill switch. Resume entries when you mean to trade again.",
          };
        }),

      resumeEntries: () =>
        set((s) => {
          if (s.weeklyLock) return {};
          return { killed: false, entriesPaused: false, pauseReason: "" };
        }),

      acknowledgeWeek: () =>
        set((s) => ({
          weeklyLock: false,
          killed: false,
          entriesPaused: false,
          pauseReason: "",
          weekStartNav: navOf(
            s.equity,
            s.positions,
            Object.fromEntries(s.positions.filter((p) => p.status === "OPEN").map((p) => [p.symbol, p.entry])),
          ),
          journal: [
            {
              id: uid("week"),
              ts: Date.now(),
              kind: "OVERRIDE" as const,
              title: "Weekly halt acknowledged",
              body: "Manual re-enable after the weekly loss limit. The week baseline was reset to current NAV.",
            },
            ...s.journal,
          ].slice(0, 300),
        })),

      resetAccount: () =>
        set((s) => ({
          ...freshClock(s.settings.equityStart),
          settings: s.settings,
          deliberating: false,
          lastSymbol: null,
          lastPlan: null,
          lastSkeptic: null,
          lastFlow: null,
          busySymbol: null,
        })),
    }),
    {
      name: "volumetric-desk-v1",
      skipHydration: true,
      partialize: (s) => ({
        settings: s.settings,
        equity: s.equity,
        dayKey: s.dayKey,
        weekKey: s.weekKey,
        dayStartNav: s.dayStartNav,
        weekStartNav: s.weekStartNav,
        weeklyLock: s.weeklyLock,
        killed: s.killed,
        entriesPaused: s.entriesPaused,
        pauseReason: s.pauseReason,
        positions: s.positions,
        journal: s.journal.slice(0, 200),
        messages: s.messages.slice(0, 80),
        memories: s.memories.slice(0, 150),
        curve: s.curve.slice(-200),
        fundingMemory: s.fundingMemory,
        watch: s.watch,
      }),
    },
  ),
);

function clampNum(n: number, lo: number, hi: number): number {
  if (!Number.isFinite(n)) return lo;
  return Math.min(hi, Math.max(lo, n));
}

function settleClose(
  pos: Position,
  memories: SetupMemory[],
  journal: JournalEntry[],
  messages: AgentMessage[],
) {
  const mem = memories.find((m) => m.symbol === pos.symbol && m.outcome === "OPEN" && m.setup === pos.setup);
  if (mem && pos.rMultiple != null) {
    mem.rMultiple = pos.rMultiple;
    mem.outcome = pos.rMultiple > 0.05 ? "WIN" : pos.rMultiple < -0.05 ? "LOSS" : "FLAT";
  }
  const body = autopsy(pos);
  journal.unshift({
    id: uid("close"),
    ts: pos.closedAt ?? Date.now(),
    kind: "CLOSE",
    symbol: pos.symbol,
    title: `${pos.symbol} ${pos.closeReason ?? "closed"} · ${(pos.rMultiple ?? 0).toFixed(2)}R`,
    body,
    rMultiple: pos.rMultiple,
    pnl: pos.realizedPnl,
    setup: pos.setup,
  });
  messages.unshift({
    id: uid("journal"),
    agent: "journal",
    ts: pos.closedAt ?? Date.now(),
    symbol: pos.symbol,
    title: "Post-trade autopsy",
    body,
    tone: (pos.rMultiple ?? 0) >= 0 ? "pass" : "warn",
  });
}

function rollLimits<T extends DeskState>(s: T, prices: Record<string, number>): T {
  const nav = navOf(s.equity, s.positions, prices);
  const dk = dayKey();
  const wk = weekKey();
  if (dk === s.dayKey && wk === s.weekKey) return s;
  let entriesPaused = s.entriesPaused;
  let pauseReason = s.pauseReason;
  if (dk !== s.dayKey && pauseReason.startsWith("Daily")) {
    entriesPaused = s.weeklyLock || s.killed;
    pauseReason = entriesPaused ? s.pauseReason : "";
  }
  return {
    ...s,
    dayKey: dk,
    weekKey: wk,
    dayStartNav: dk === s.dayKey ? s.dayStartNav : nav,
    weekStartNav: wk === s.weekKey ? s.weekStartNav : nav,
    entriesPaused,
    pauseReason,
  };
}

function applyBreaches<T extends { settings: Settings; dayStartNav: number; weekStartNav: number; weeklyLock: boolean; killed: boolean; entriesPaused: boolean; pauseReason: string }>(
  s: T,
  nav: number,
): T {
  if (weeklyBreach(nav, s.weekStartNav, s.settings)) {
    return {
      ...s,
      weeklyLock: true,
      entriesPaused: true,
      pauseReason: "Weekly loss limit. Entries stay off until you acknowledge it.",
    };
  }
  if (!s.weeklyLock && !s.killed && dailyBreach(nav, s.dayStartNav, s.settings)) {
    return {
      ...s,
      entriesPaused: true,
      pauseReason: "Daily loss limit. New entries halt until the next UTC day.",
    };
  }
  return s;
}

export function pricesFrom(rows: { symbol: string; lastPrice: number }[], positions: Position[]): Record<string, number> {
  const map: Record<string, number> = {};
  for (const row of rows) map[row.symbol] = row.lastPrice;
  for (const p of positions) if (map[p.symbol] == null) map[p.symbol] = p.entry;
  return map;
}

export function accountNav(equity: number, positions: Position[], prices: Record<string, number>): number {
  return navOf(equity, positions, prices);
}

export function positionUpl(pos: Position, price: number): number {
  return unrealizedPnl(pos, price);
}

export { decide };
