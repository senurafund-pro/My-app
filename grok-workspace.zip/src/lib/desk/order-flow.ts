import type { OrderFlow, TradeTick } from "./types.ts";

/** Aggressive buy when the buyer is the taker (`m` false on Binance, positive size on Gate). */
export function computeOrderFlow(trades: TradeTick[], price: number): OrderFlow {
  let buy = 0;
  let sell = 0;
  let cvd = 0;
  let pv = 0;
  let vol = 0;
  const cvdSeries: number[] = [];
  const prices: number[] = [];

  for (const t of trades) {
    if (!(t.q > 0) || !(t.p > 0)) continue;
    const signed = t.m ? -t.q : t.q;
    cvd += signed;
    if (t.m) sell += t.q;
    else buy += t.q;
    pv += t.p * t.q;
    vol += t.q;
    cvdSeries.push(cvd);
    prices.push(t.p);
  }

  const vwap = vol > 0 ? pv / vol : price;
  const denom = Math.max(buy + sell, 1e-12);
  const ofi = (buy - sell) / denom;
  const n = cvdSeries.length;
  const early = n ? cvdSeries[Math.min(n - 1, Math.floor(n * 0.3))] : 0;
  const late = n ? cvdSeries[n - 1] : 0;
  const cvdSlope = late - early;
  const first = prices[0] ?? price;
  const last = prices[prices.length - 1] ?? price;
  let divergence: OrderFlow["divergence"] = "NONE";
  const priceUp = last > first * 1.0003;
  const priceDown = last < first * 0.9997;
  if (priceUp && cvdSlope < 0) divergence = "BEARISH";
  else if (priceDown && cvdSlope > 0) divergence = "BULLISH";

  return {
    cvd,
    cvdSlope,
    ofi,
    imbalance: ofi,
    vwap,
    vwapDev: vwap > 0 ? (price - vwap) / vwap : 0,
    buyVol: buy,
    sellVol: sell,
    divergence,
  };
}

export function bookImbalance(bids: [number, number][], asks: [number, number][], levels = 10): number {
  const b = bids.slice(0, levels).reduce((s, x) => s + (x[1] > 0 ? x[1] : 0), 0);
  const a = asks.slice(0, levels).reduce((s, x) => s + (x[1] > 0 ? x[1] : 0), 0);
  const d = b + a;
  if (d <= 0) return 0;
  return (b - a) / d;
}

export function spreadBps(bids: [number, number][], asks: [number, number][]): number {
  const bid = bids[0]?.[0] ?? 0;
  const ask = asks[0]?.[0] ?? 0;
  if (bid <= 0 || ask <= 0) return 50;
  const mid = (bid + ask) / 2;
  return ((ask - bid) / mid) * 10_000;
}
