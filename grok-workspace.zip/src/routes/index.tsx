import { createFileRoute } from "@tanstack/react-router";
import { DeskApp } from "@/components/desk/desk-app";
import { fetchUniverse } from "@/lib/desk/market";
import type { UniverseSnapshot } from "@/lib/desk/types";

export const Route = createFileRoute("/")({
  loader: async (): Promise<UniverseSnapshot> => {
    try {
      return await fetchUniverse();
    } catch (error) {
      return {
        venue: "sim",
        note: "The tape could not be loaded. Refresh the scan.",
        fetchedAt: Date.now(),
        headlines: [],
        rows: [],
        error: error instanceof Error ? error.message : "Scan failed",
      };
    }
  },
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  return <DeskApp initial={initial} />;
}
