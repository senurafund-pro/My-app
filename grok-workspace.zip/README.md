# Volumetric Desk

A paper trading desk for USDT perpetuals. It ranks the whole universe on funding, open interest, and order-flow stress, then refuses any trade the microstructure, the Skeptic, or the risk engine cannot defend.

**Most systematic strategies do not keep a durable edge.** The point of this desk is disciplined risk and honest measurement, not a profit claim. Paper fills ignore queue position. Stops in this build are enforced by the desk, not by an exchange. Nothing here is advice or a solicitation to trade.

## What it does

- Scores every liquid USDT perpetual. There is no hard-coded majors list.
- Promotes a watchlist and demotes names whose score fades.
- Builds a volume profile (POC, value area, HVN, LVN) and requires OFI, imbalance, and VWAP to agree before a plan exists.
- Places stops and targets on those nodes. If the structure does not pay the minimum R:R, the answer is `NO_TRADE`.
- Runs a Skeptic that can `BLOCK`, `DELAY`, or `DOWNSIZE`. A block sticks unless you log an override. Risk limits cannot be overridden.
- Sizes from the stop distance. Caps heat, daily loss, weekly loss, correlation, news windows, and slippage.
- Papers an isolated-margin bracket (entry plus stop and target). Trails the stop to entry after 1R. Flattens if flow reverses, or if you hit Kill.
- Writes a decision record for skips and fills, and an autopsy when a trade closes.

## Venue

Live Binance order routing is **off**. Keys are never collected. If Binance public market data is region-blocked, the tape falls through to Gate.io USDT perpetuals and says so on screen. If both fail, a clearly labeled simulation keeps the agents runnable.

## Risk defaults

| Control | Default |
| --- | --- |
| Risk per trade | 0.75% of NAV |
| Portfolio heat | 2.5% |
| Daily halt | 3% |
| Weekly halt | 6%, manual re-enable |
| Minimum structural R:R | 2.0 |
| Correlated alt cap | 2 |
| Score threshold | 58 |
| News blackout | 45 minutes |
