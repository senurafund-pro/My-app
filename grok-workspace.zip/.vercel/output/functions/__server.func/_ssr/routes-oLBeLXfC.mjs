import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ema, c as trendEfficiency, i as dayKey, l as uid, n as clamp, o as mean, r as cosine, s as median, t as atr, u as weekKey } from "./math-B29EofKM.mjs";
import { a as MessagesSquare, i as Octagon, n as SlidersHorizontal, o as Briefcase, r as ScanSearch, s as BookOpen } from "../_libs/lucide-react.mjs";
import { a as fetchUniverse, i as fetchPacket, n as Route, r as fetchEnrichment } from "./router-Dr5yw7Ua.mjs";
import { a as Area, c as Tooltip, i as XAxis, n as BarChart, o as Bar, r as YAxis, s as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-oLBeLXfC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Distributes each candle's volume uniformly across the bins its range covers,
* then marks the POC, a 70% value area, and local HVN / LVN nodes.
*/
function buildVolumeProfile(candles, binCount = 36) {
	const empty = {
		bins: [],
		poc: candles.at(-1)?.c ?? 0,
		vah: candles.at(-1)?.c ?? 0,
		val: candles.at(-1)?.c ?? 0,
		hvns: [],
		lvns: [],
		totalVolume: 0
	};
	if (candles.length < 4) return empty;
	const hi = Math.max(...candles.map((c) => c.h));
	const lo = Math.min(...candles.map((c) => c.l));
	const span = Math.max(hi - lo, lo * 1e-6, 1e-9);
	const binsN = Math.max(12, binCount);
	const step = span / binsN;
	const vols = new Array(binsN).fill(0);
	for (const c of candles) {
		const i0 = Math.max(0, Math.min(binsN - 1, Math.floor((c.l - lo) / step)));
		const i1 = Math.max(0, Math.min(binsN - 1, Math.floor((Math.max(c.h, c.l + step * .01) - lo) / step)));
		const n = Math.max(1, i1 - i0 + 1);
		const share = (c.v > 0 ? c.v : 0) / n;
		for (let i = i0; i <= i1; i++) vols[i] += share;
	}
	const total = vols.reduce((a, b) => a + b, 0);
	if (total <= 0) return empty;
	const bins = vols.map((volume, i) => ({
		price: lo + (i + .5) * step,
		volume,
		share: volume / total
	}));
	let pocIdx = 0;
	for (let i = 1; i < vols.length; i++) if (vols[i] > vols[pocIdx]) pocIdx = i;
	const included = /* @__PURE__ */ new Set([pocIdx]);
	let covered = vols[pocIdx];
	let left = pocIdx - 1;
	let right = pocIdx + 1;
	while (covered / total < .7 && (left >= 0 || right < binsN)) {
		const lv = left >= 0 ? vols[left] : -1;
		if ((right < binsN ? vols[right] : -1) > lv) {
			included.add(right);
			covered += vols[right];
			right += 1;
		} else if (left >= 0) {
			included.add(left);
			covered += vols[left];
			left -= 1;
		} else break;
	}
	const areaIdx = [...included].sort((a, b) => a - b);
	const val = bins[areaIdx[0]].price;
	const vah = bins[areaIdx[areaIdx.length - 1]].price;
	const med = median(vols);
	const hvns = [];
	const lvns = [];
	for (let i = 1; i < binsN - 1; i++) {
		const peak = vols[i] >= vols[i - 1] && vols[i] >= vols[i + 1] && vols[i] >= med * 1.25;
		const trough = vols[i] <= vols[i - 1] && vols[i] <= vols[i + 1] && vols[i] <= med * .72;
		if (peak) hvns.push(bins[i].price);
		else if (trough) lvns.push(bins[i].price);
	}
	if (!hvns.length) hvns.push(bins[pocIdx].price);
	else if (!hvns.some((p) => Math.abs(p - bins[pocIdx].price) < step * 1.5)) hvns.push(bins[pocIdx].price);
	hvns.sort((a, b) => a - b);
	return {
		bins,
		poc: bins[pocIdx].price,
		vah,
		val,
		hvns,
		lvns,
		totalVolume: total
	};
}
function binShareAt(profile, price) {
	if (!profile.bins.length) return 0;
	let best = profile.bins[0];
	let dist = Math.abs(best.price - price);
	for (const b of profile.bins) {
		const d = Math.abs(b.price - price);
		if (d < dist) {
			best = b;
			dist = d;
		}
	}
	return best.share;
}
function fmtPx(n) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	const d = abs >= 1e3 ? 2 : abs >= 100 ? 3 : abs >= 1 ? 4 : abs >= .01 ? 5 : 7;
	return n.toLocaleString("en-US", {
		minimumFractionDigits: Math.min(2, d),
		maximumFractionDigits: d
	});
}
function fmtUsd(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	return (n < 0 ? "−" : "") + "$" + Math.abs(n).toLocaleString("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function fmtPct(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	return `${n > 0 ? "+" : n < 0 ? "−" : ""}${Math.abs(n).toFixed(digits)}%`;
}
function fmtFunding(rate) {
	if (!Number.isFinite(rate)) return "—";
	return fmtPct(rate * 100, 4);
}
function compact(n) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	const sign = n < 0 ? "−" : "";
	if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(2)}B`;
	if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(2)}M`;
	if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(1)}K`;
	return `${sign}${abs.toFixed(0)}`;
}
function fmtQty(n) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	const d = abs >= 1e3 ? 2 : abs >= 1 ? 4 : 6;
	return n.toLocaleString("en-US", { maximumFractionDigits: d });
}
function fmtTime(ts) {
	if (!ts) return "—";
	return new Date(ts).toLocaleTimeString("en-GB", {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
}
function signedClass(n) {
	if (n > 0) return "text-up";
	if (n < 0) return "text-down";
	return "text-muted";
}
var AGENT_LABEL = {
	scanner: "Universe Scanner",
	microstructure: "Microstructure",
	chart: "Chart / Structure",
	sentiment: "Sentiment",
	news: "News & Macro",
	skeptic: "Skeptic",
	risk: "Risk Engine",
	executor: "Executor",
	journal: "Journal"
};
var DEFAULT_SETTINGS = {
	equityStart: 1e5,
	riskPerTradePct: .0075,
	maxHeatPct: .025,
	dailyLossPct: .03,
	weeklyLossPct: .06,
	minRr: 2,
	maxCorrelated: 2,
	scoreThreshold: 58,
	watchlistSize: 18,
	demoteScans: 3,
	minQuoteVolume: 2e6,
	newsBlackoutMin: 45,
	scanIntervalSec: 40,
	feeBps: 4,
	slippageBps: 2,
	breakevenR: 1,
	autoDeliberate: true,
	events: []
};
/** Aggressive buy when the buyer is the taker (`m` false on Binance, positive size on Gate). */
function computeOrderFlow(trades, price) {
	let buy = 0;
	let sell = 0;
	let cvd = 0;
	let pv = 0;
	let vol = 0;
	const cvdSeries = [];
	const prices = [];
	for (const t of trades) {
		if (!(t.q > 0) || !(t.p > 0)) continue;
		const signed = t.m ? -t.q : t.q;
		cvd += signed;
		if (t.m) sell += t.q;
		else buy += t.q;
		pv += t.p * t.q;
		vol += t.q;
		cvdSeries.push(cvd);
		prices.push(t.p);
	}
	const vwap = vol > 0 ? pv / vol : price;
	const denom = Math.max(buy + sell, 1e-12);
	const ofi = (buy - sell) / denom;
	const n = cvdSeries.length;
	const early = n ? cvdSeries[Math.min(n - 1, Math.floor(n * .3))] : 0;
	const cvdSlope = (n ? cvdSeries[n - 1] : 0) - early;
	const first = prices[0] ?? price;
	const last = prices[prices.length - 1] ?? price;
	let divergence = "NONE";
	const priceUp = last > first * 1.0003;
	const priceDown = last < first * .9997;
	if (priceUp && cvdSlope < 0) divergence = "BEARISH";
	else if (priceDown && cvdSlope > 0) divergence = "BULLISH";
	return {
		cvd,
		cvdSlope,
		ofi,
		imbalance: ofi,
		vwap,
		vwapDev: vwap > 0 ? (price - vwap) / vwap : 0,
		buyVol: buy,
		sellVol: sell,
		divergence
	};
}
function bookImbalance(bids, asks, levels = 10) {
	const b = bids.slice(0, levels).reduce((s, x) => s + (x[1] > 0 ? x[1] : 0), 0);
	const a = asks.slice(0, levels).reduce((s, x) => s + (x[1] > 0 ? x[1] : 0), 0);
	const d = b + a;
	if (d <= 0) return 0;
	return (b - a) / d;
}
function spreadBps(bids, asks) {
	const bid = bids[0]?.[0] ?? 0;
	const ask = asks[0]?.[0] ?? 0;
	if (bid <= 0 || ask <= 0) return 50;
	const mid = (bid + ask) / 2;
	return (ask - bid) / mid * 1e4;
}
var EMPTY_CONF = {
	ofi: false,
	imbalance: false,
	vwap: false,
	votes: 0
};
function noTrade(symbol, reason, confluence = EMPTY_CONF) {
	return {
		valid: false,
		symbol,
		reason,
		confluence
	};
}
function nearest(levels, price) {
	if (!levels.length) return null;
	return levels.reduce((best, h) => Math.abs(h - price) < Math.abs(best - price) ? h : best);
}
/**
* Structural plan. A trade exists only when order-flow confluence aligns AND
* the next volume node pays the configured R:R against a real invalidation.
* Otherwise the agent stands down. It does not invent an R multiple.
*/
function planTrade(input) {
	const { symbol, price, candles, flow } = input;
	if (!(price > 0) || candles.length < 20) return noTrade(symbol, "Not enough execution-timeframe tape to build a profile.");
	const htf = input.candlesHtf.length >= 12 ? input.candlesHtf : candles;
	const efficiency = trendEfficiency(htf);
	if (efficiency < .16) return noTrade(symbol, `Regime gate: higher-timeframe efficiency ${efficiency.toFixed(2)} is chop. No trade until a direction exists.`);
	const ofiLong = flow.ofi > .07;
	const ofiShort = flow.ofi < -.07;
	const imbLong = flow.imbalance > .07;
	const imbShort = flow.imbalance < -.07;
	const vwapLong = flow.vwapDev > -.004 && flow.vwapDev < .009;
	const vwapShort = flow.vwapDev < .004 && flow.vwapDev > -.009;
	const longVotes = [
		ofiLong,
		imbLong,
		vwapLong
	].filter(Boolean).length;
	const shortVotes = [
		ofiShort,
		imbShort,
		vwapShort
	].filter(Boolean).length;
	let side = null;
	let confluence = EMPTY_CONF;
	if (longVotes >= 2 && longVotes > shortVotes) {
		side = "LONG";
		confluence = {
			ofi: ofiLong,
			imbalance: imbLong,
			vwap: vwapLong,
			votes: longVotes
		};
	} else if (shortVotes >= 2 && shortVotes > longVotes) {
		side = "SHORT";
		confluence = {
			ofi: ofiShort,
			imbalance: imbShort,
			vwap: vwapShort,
			votes: shortVotes
		};
	}
	if (!side) return noTrade(symbol, "Confluence gate: OFI, volume imbalance, and VWAP deviation do not agree. Standing down.", {
		ofi: false,
		imbalance: false,
		vwap: false,
		votes: Math.max(longVotes, shortVotes)
	});
	const profile = input.profile ?? buildVolumeProfile(candles);
	const range = atr(candles, 14);
	const a = Math.max(range, price * .0018);
	const anchor = nearest([...profile.hvns, profile.poc], price);
	if (anchor == null || Math.abs(anchor - price) > a * .95) return noTrade(symbol, "Price is not interacting with a high-volume node or the POC. No structural entry.", confluence);
	const dir = side === "LONG" ? 1 : -1;
	const entry = clampToward(price, anchor, a * .15);
	const defensive = profile.hvns.filter((h) => (entry - h) * dir > a * .05);
	const swing = side === "LONG" ? Math.min(...candles.slice(-24).map((c) => c.l)) : Math.max(...candles.slice(-24).map((c) => c.h));
	const node = nearest(defensive, entry);
	let stop = side === "LONG" ? Math.min(swing, (node ?? entry) - a * .22) : Math.max(swing, (node ?? entry) + a * .22);
	const minDist = a * .42;
	const maxDist = a * 4.2;
	let dist = (entry - stop) * dir;
	if (dist < minDist) {
		stop = entry - dir * minDist;
		dist = minDist;
	}
	if (dist > maxDist) return noTrade(symbol, "The structural invalidation is too far away to size without pretending the stop is closer.", confluence);
	const favorable = [
		...profile.hvns.filter((h) => (h - entry) * dir > a * .45),
		(profile.poc - entry) * dir > a * .45 ? profile.poc : NaN,
		side === "LONG" ? profile.vah : profile.val
	].filter((t) => Number.isFinite(t) && (t - entry) * dir > 0);
	const unique = [...new Set(favorable.map((t) => Number(t.toFixed(8))))].sort((x, y) => (x - y) * dir);
	const minRr = input.minRr;
	let target = null;
	for (const t of unique) if ((t - entry) * dir / dist >= minRr) {
		target = t;
		break;
	}
	if (target == null) {
		const best = unique[unique.length - 1];
		const bestRr = best != null ? (best - entry) * dir / dist : 0;
		return noTrade(symbol, `No volume node pays ${minRr.toFixed(1)}R. Best structural target is ${bestRr.toFixed(2)}R. Refusing to stretch the target.`, confluence);
	}
	const rr = (target - entry) * dir / dist;
	const setup = setupName(profile, entry, a, side);
	return {
		valid: true,
		symbol,
		side,
		entry,
		stop,
		target,
		rr,
		setup,
		reason: prose(side, setup, confluence, rr, profile),
		confluence,
		poc: profile.poc,
		hvn: anchor,
		atr: a
	};
}
function clampToward(price, anchor, maxShift) {
	return price + clamp(anchor - price, -maxShift, maxShift) * .35;
}
function setupName(profile, entry, a, _side) {
	const hvn = nearest(profile.hvns, entry);
	if (hvn != null && Math.abs(hvn - entry) <= a * .35) return "HVN edge";
	const lvn = nearest(profile.lvns, entry);
	if (lvn != null && Math.abs(lvn - entry) <= a * .35) return "LVN rejection";
	if (Math.abs(profile.poc - entry) <= a * .5) return "POC response";
	return "Node path";
}
function prose(side, setup, c, rr, profile) {
	const bits = [
		c.ofi ? "OFI" : null,
		c.imbalance ? "tape imbalance" : null,
		c.vwap ? "VWAP location" : null
	].filter(Boolean);
	return `${side === "LONG" ? "Long" : "Short"} ${setup}. Confluence ${c.votes}/3 (${bits.join(", ")}). Target is the next volume node, not a fixed multiple — structural R:R ${rr.toFixed(2)} against invalidation beyond the defending node. POC ${profile.poc.toPrecision(6)}.`;
}
var MAJORS = /* @__PURE__ */ new Set(["BTCUSDT", "ETHUSDT"]);
function openRiskUsd(pos) {
	return Math.abs(pos.entry - pos.stop) * pos.qty;
}
function unrealizedPnl(pos, price) {
	if (!(price > 0)) return 0;
	const dir = pos.side === "LONG" ? 1 : -1;
	return (price - pos.entry) * dir * pos.qty;
}
function navOf(equity, positions, prices) {
	let u = 0;
	for (const p of positions) {
		if (p.status !== "OPEN") continue;
		u += unrealizedPnl(p, prices[p.symbol] ?? p.entry);
	}
	return equity + u;
}
function evaluateRisk(input) {
	const gates = [];
	const fail = (name, detail) => gates.push({
		name,
		pass: false,
		detail
	});
	const ok = (name, detail) => gates.push({
		name,
		pass: true,
		detail
	});
	if (input.killed) fail("Kill switch", "Entries halted. Flatten is armed until you resume.");
	else ok("Kill switch", "Clear.");
	if (input.weeklyLock) fail("Weekly loss", "Weekly loss limit is latched. Manual acknowledgement required.");
	else ok("Weekly loss", "Within the weekly budget.");
	const dayDd = input.dayStartNav > 0 ? (input.dayStartNav - input.nav) / input.dayStartNav : 0;
	const weekDd = input.weekStartNav > 0 ? (input.weekStartNav - input.nav) / input.weekStartNav : 0;
	if (dayDd >= input.settings.dailyLossPct) fail("Daily loss", `Day drawdown ${(dayDd * 100).toFixed(2)}% has hit the ${(input.settings.dailyLossPct * 100).toFixed(1)}% halt.`);
	else ok("Daily loss", `Day drawdown ${(Math.max(0, dayDd) * 100).toFixed(2)}%.`);
	if (weekDd >= input.settings.weeklyLossPct) fail("Weekly loss", `Week drawdown ${(weekDd * 100).toFixed(2)}% breaches the hard pause.`);
	if (input.entriesPaused) fail("Pause", "New entries are paused.");
	else if (!input.killed && !input.weeklyLock) ok("Pause", "Entries enabled.");
	if (input.newsBlackout) fail("News blackout", "Inside the configured high-impact window.");
	else ok("News blackout", "No blackout.");
	if (!input.plan.valid) {
		fail("Structure", input.plan.reason);
		return rejected(input.plan.reason, gates);
	}
	const plan = input.plan;
	if (input.skeptic && (input.skeptic.verdict === "BLOCK" || input.skeptic.verdict === "DELAY")) fail("Skeptic", `${input.skeptic.verdict}. ${input.skeptic.summary}`);
	else if (input.skeptic) ok("Skeptic", `${input.skeptic.verdict}. ${input.skeptic.summary}`);
	else fail("Skeptic", "No skeptic report. Execution refused.");
	const structural = structuralRr(plan);
	if (structural < input.settings.minRr) fail("R:R floor", `Recomputed structural R:R is ${structural.toFixed(2)}, below ${input.settings.minRr.toFixed(1)}. The agent's claim is ignored.`);
	else ok("R:R floor", `Structural R:R ${structural.toFixed(2)} from the actual levels.`);
	const stopDist = Math.abs(plan.entry - plan.stop);
	if (!(stopDist > 0) || stopDist / plan.entry < .001) fail("Stop distance", "Stop is inside noise relative to price.");
	else ok("Stop distance", `Invalidation is ${(stopDist / plan.entry * 100).toFixed(2)}% away.`);
	const slip = (input.settings.slippageBps + Math.max(0, input.spreadBps - 1.5) * .5) / 1e4;
	const fee = input.settings.feeBps * 2 / 1e4;
	const dir = plan.side === "LONG" ? 1 : -1;
	const entryPx = plan.entry * (1 + slip * dir);
	const targetPx = plan.target * (1 - slip * dir);
	const riskPerUnit = (entryPx - plan.stop * (1 - slip * dir)) * dir;
	const rewardPerUnit = (targetPx - entryPx) * dir - entryPx * fee;
	const rrNet = riskPerUnit > 0 ? rewardPerUnit / riskPerUnit : 0;
	if (rrNet < input.settings.minRr) fail("Slippage", `After spread, slippage, and fees the R:R is ${rrNet.toFixed(2)}. Skipped.`);
	else ok("Slippage", `Net R:R ${rrNet.toFixed(2)} after costs. Spread ${input.spreadBps.toFixed(1)} bps.`);
	const factor = clampFactor(input.sizeFactor);
	let riskUsd = input.nav * input.settings.riskPerTradePct * factor;
	let qty = riskPerUnit > 0 ? riskUsd / riskPerUnit : 0;
	const maxLev = 5;
	const lev0 = input.nav > 0 ? qty * entryPx / input.nav : 99;
	if (lev0 > maxLev && entryPx > 0) {
		qty = input.nav * maxLev / entryPx;
		riskUsd = qty * riskPerUnit;
		ok("Leverage cap", `Size cut so isolated leverage stays at ${maxLev}x.`);
	} else ok("Leverage cap", `Implied leverage ${lev0.toFixed(2)}x.`);
	const thisRisk = qty * Math.abs(entryPx - plan.stop);
	let heat = thisRisk;
	for (const p of input.positions) {
		if (p.status !== "OPEN") continue;
		heat += openRiskUsd(p);
	}
	const heatPct = input.nav > 0 ? heat / input.nav : 1;
	if (heatPct > input.settings.maxHeatPct && thisRisk > 0) {
		const room = input.settings.maxHeatPct * input.nav - (heat - thisRisk);
		if (room <= input.nav * .001) fail("Portfolio heat", `Open risk already uses the ${(input.settings.maxHeatPct * 100).toFixed(1)}% heat budget.`);
		else {
			const scale = room / thisRisk;
			qty *= scale;
			riskUsd *= scale;
			heat = input.settings.maxHeatPct * input.nav;
			ok("Portfolio heat", "Downsized to fit inside remaining heat.");
		}
	} else ok("Portfolio heat", `Heat after fill ${(heatPct * 100).toFixed(2)}%.`);
	const sameSideAlts = input.positions.filter((p) => p.status === "OPEN" && p.side === plan.side && !MAJORS.has(p.symbol) && !MAJORS.has(plan.symbol)).length;
	if (!MAJORS.has(plan.symbol) && sameSideAlts >= input.settings.maxCorrelated) fail("Correlation", `${sameSideAlts} correlated alt positions already point ${plan.side}. Cap is ${input.settings.maxCorrelated}.`);
	else ok("Correlation", "Beta bucket has room.");
	const approved = gates.every((g) => g.pass) && qty > 0 && riskUsd > 0;
	const notional = qty * entryPx;
	const leverage = input.nav > 0 ? notional / input.nav : 0;
	return {
		approved,
		reason: approved ? `Approved. Risk ${riskUsd.toFixed(2)} USDT, heat ${(heat / Math.max(input.nav, 1) * 100).toFixed(2)}%.` : gates.find((g) => !g.pass)?.detail ?? "Rejected.",
		qty: approved ? qty : 0,
		notional: approved ? notional : 0,
		riskUsd: approved ? qty * Math.abs(entryPx - plan.stop) : 0,
		heatAfter: input.nav > 0 ? heat / input.nav : 0,
		leverage,
		rrNet,
		gates
	};
}
function structuralRr(plan) {
	const risk = Math.abs(plan.entry - plan.stop);
	const reward = Math.abs(plan.target - plan.entry);
	if (!(risk > 0)) return 0;
	if (!(plan.side === "LONG" ? plan.stop < plan.entry && plan.target > plan.entry : plan.stop > plan.entry && plan.target < plan.entry)) return 0;
	return reward / risk;
}
function rejected(reason, gates) {
	return {
		approved: false,
		reason,
		qty: 0,
		notional: 0,
		riskUsd: 0,
		heatAfter: 0,
		leverage: 0,
		rrNet: 0,
		gates
	};
}
function clampFactor(n) {
	if (!Number.isFinite(n) || n <= 0) return 0;
	return Math.min(1, n);
}
function dailyBreach(nav, dayStartNav, settings) {
	if (!(dayStartNav > 0)) return false;
	return (dayStartNav - nav) / dayStartNav >= settings.dailyLossPct;
}
function weeklyBreach(nav, weekStartNav, settings) {
	if (!(weekStartNav > 0)) return false;
	return (weekStartNav - nav) / weekStartNav >= settings.weeklyLossPct;
}
function msg(agent, title, body, tone, symbol, now) {
	return {
		id: uid(agent),
		agent,
		ts: now,
		symbol,
		title,
		body,
		tone
	};
}
function emaBias(closes) {
	if (closes.length < 22) return "NEUTRAL";
	const fast = ema(closes, 8);
	const slow = ema(closes, 21);
	if (fast > slow * 1.0015) return "LONG";
	if (fast < slow * .9985) return "SHORT";
	return "NEUTRAL";
}
function readChart(packet, side) {
	const h1 = packet.candles1h.map((c) => c.c);
	const m15 = packet.candles15.map((c) => c.c);
	const b1 = emaBias(h1);
	const b15 = emaBias(m15);
	const eff = trendEfficiency(packet.candles1h.length ? packet.candles1h : packet.candles15);
	const bias = b1 === "NEUTRAL" ? b15 === "NEUTRAL" ? "NEUTRAL" : b15 : b1;
	const dissent = Boolean(side && bias !== "NEUTRAL" && bias !== side);
	return {
		bias,
		dissent,
		summary: dissent ? `Dissent. ${side} fights the ${bias === "LONG" ? "higher-timeframe uptrend" : "higher-timeframe downtrend"} (1h ${b1}, 15m ${b15}, efficiency ${eff.toFixed(2)}).` : `Structure ${bias === "NEUTRAL" ? "is balanced" : `leans ${bias}`}. 1h ${b1}, 15m ${b15}, efficiency ${eff.toFixed(2)}. No dissent${side ? ` against ${side}` : ""}.`
	};
}
function readSentiment(packet, side) {
	const f = packet.fundingRate;
	const oiUp = (packet.oiDeltaPct ?? 0) > .015;
	const lsr = packet.longShortRatio;
	let crowdedSide = null;
	if (f > 3e-4 && (oiUp || lsr != null && lsr > 1.3)) crowdedSide = "LONG";
	else if (f < -22e-5 && (oiUp || lsr != null && lsr < .78)) crowdedSide = "SHORT";
	else if (f > 55e-5) crowdedSide = "LONG";
	else if (f < -4e-4) crowdedSide = "SHORT";
	const sameSide = Boolean(side && crowdedSide === side);
	const extreme = Math.abs(f) > 7e-4 || lsr != null && (lsr > 2.1 || lsr < .48);
	const lsrTxt = lsr == null ? "long/short unavailable" : `account long/short ${lsr.toFixed(2)}`;
	const oiTxt = packet.oiDeltaPct == null ? "OI delta unavailable" : `OI ${packet.oiDeltaPct >= 0 ? "+" : ""}${(packet.oiDeltaPct * 100).toFixed(1)}%`;
	const summary = crowdedSide ? `Crowded ${crowdedSide === "LONG" ? "longs" : "shorts"}. Funding ${(f * 100).toFixed(4)}%, ${oiTxt}, ${lsrTxt}.${sameSide ? " The proposed side is the crowd." : " The proposed side fades the crowd."}` : `Positioning is not extreme. Funding ${(f * 100).toFixed(4)}%, ${oiTxt}, ${lsrTxt}.`;
	return {
		crowdedSide,
		sameSide,
		extreme,
		summary
	};
}
function readNews(packet, settings, now) {
	const windowMs = settings.newsBlackoutMin * 6e4;
	const hit = settings.events.find((e) => Math.abs(e.at - now) <= windowMs);
	const base = packet.symbol.replace(/USDT$/, "").replace(/_/g, "");
	const lead = packet.headlines.filter((h) => {
		const u = h.toUpperCase();
		return u.includes(base) || base === "BTC" && u.includes("BITCOIN");
	})[0] ?? packet.headlines[0];
	if (hit) return {
		blackout: true,
		reason: hit.name,
		summary: `Blackout. “${hit.name}” is inside ±${settings.newsBlackoutMin} minutes. No new entries.${lead ? ` Context: ${lead}` : ""}`
	};
	return {
		blackout: false,
		reason: "",
		summary: lead ? `Calendar clear. Latest headline: ${lead}` : "Calendar clear. No headline feed on this pass — blackout is driven only by events you add in Settings."
	};
}
function recallSimilar(memories, side, funding, flow) {
	const q = features(side, funding, flow.ofi, flow.imbalance, flow.vwapDev);
	return memories.filter((m) => m.outcome !== "OPEN").map((memory) => ({
		memory,
		similarity: cosine(q, features(memory.side, memory.funding, memory.ofi, memory.imbalance, memory.vwapDev))
	})).filter((s) => s.similarity >= .8).sort((a, b) => b.similarity - a.similarity).slice(0, 3);
}
function features(side, funding, ofi, imb, vwapDev) {
	const cap = (n, lim) => Math.max(-lim, Math.min(lim, n));
	return [
		side === "LONG" ? 1 : -1,
		cap(funding / 3e-4, 3),
		cap(ofi, 1),
		cap(imb, 1),
		cap(vwapDev / .005, 3)
	];
}
function skepticReview(input) {
	const objections = [];
	if (!input.plan.valid) return {
		verdict: "PASS",
		sizeFactor: 0,
		objections: [{
			code: "STAND_DOWN",
			severity: "NOTE",
			detail: input.plan.reason
		}],
		summary: "Nothing to approve. The stand-down is accepted."
	};
	const plan = input.plan;
	const stopDist = Math.abs(plan.entry - plan.stop);
	if (input.pocShare < .055) objections.push({
		code: "POC_THIN",
		severity: "DOWNSIZE",
		detail: `POC holds only ${(input.pocShare * 100).toFixed(1)}% of profile volume. The node may be an artefact of the window.`
	});
	if (input.profileShare < .04) objections.push({
		code: "HVN_WEAK",
		severity: "BLOCK",
		detail: `The entry node is ${(input.profileShare * 100).toFixed(1)}% of volume — not a real high-volume area.`
	});
	if (plan.confluence.votes < 2) objections.push({
		code: "CONFLUENCE",
		severity: "BLOCK",
		detail: "Fewer than two of OFI, imbalance, and VWAP agree. That is a cherry-pick, not a setup."
	});
	else if (plan.confluence.votes === 2) objections.push({
		code: "CONFLUENCE_PARTIAL",
		severity: "DOWNSIZE",
		detail: "Only 2 of 3 flow signals agree. Size is cut until the third confirms."
	});
	if (input.flow.divergence === "BULLISH" && plan.side === "SHORT") objections.push({
		code: "CVD",
		severity: "DOWNSIZE",
		detail: "CVD is diverging bullishly against this short."
	});
	else if (input.flow.divergence === "BEARISH" && plan.side === "LONG") objections.push({
		code: "CVD",
		severity: "DOWNSIZE",
		detail: "CVD is diverging bearishly against this long."
	});
	if (input.atr > 0 && stopDist < input.atr * .38) objections.push({
		code: "STOP_WICK",
		severity: "BLOCK",
		detail: `Stop is ${(stopDist / input.atr).toFixed(2)} ATR away — tucked where a liquidity sweep takes it without breaking structure.`
	});
	if (input.sentiment.sameSide && input.sentiment.extreme) objections.push({
		code: "CROWD",
		severity: "BLOCK",
		detail: `Funding, OI, and positioning say ${plan.side} is already the crowded side. This is late, not early.`
	});
	else if (input.sentiment.sameSide) objections.push({
		code: "CROWD",
		severity: "DOWNSIZE",
		detail: "Crowding is on the same side as the trade, but not at an extreme. Size halved."
	});
	const slip = (input.settings.slippageBps + Math.max(0, input.spreadBps) * .25) / 1e4;
	const fee = input.settings.feeBps * 2 / 1e4;
	const dir = plan.side === "LONG" ? 1 : -1;
	const risk = (plan.entry * (1 + slip * dir) - plan.stop * (1 - slip * dir)) * dir;
	const reward = (plan.target * (1 - slip * dir) - plan.entry * (1 + slip * dir)) * dir - plan.entry * fee;
	const rrNet = risk > 0 ? reward / risk : 0;
	if (rrNet < input.settings.minRr) objections.push({
		code: "RR_NET",
		severity: "BLOCK",
		detail: `After fees and slippage the target pays ${rrNet.toFixed(2)}R, under the ${input.settings.minRr.toFixed(1)} floor. The quoted ${plan.rr.toFixed(2)}R does not survive the book.`
	});
	if (input.news.blackout) objections.push({
		code: "NEWS",
		severity: "BLOCK",
		detail: `High-impact window: ${input.news.reason}. The setup is not holdable through the print.`
	});
	if (input.chart.dissent) objections.push({
		code: "HTF",
		severity: "DELAY",
		detail: input.chart.summary
	});
	const losers = input.similar.filter((s) => (s.memory.rMultiple ?? 0) < 0);
	if (input.similar.length >= 2 && losers.length >= 2) {
		const avg = mean(input.similar.map((s) => s.memory.rMultiple ?? 0));
		objections.push({
			code: "MEMORY",
			severity: avg < -.4 ? "BLOCK" : "DOWNSIZE",
			detail: `Retrieval memory: ${input.similar.length} similar flow-and-funding setups, average ${avg.toFixed(2)}R. The pattern has not been paying.`
		});
	}
	const verdict = worst(objections);
	return {
		verdict,
		sizeFactor: verdict === "BLOCK" || verdict === "DELAY" ? 0 : verdict === "DOWNSIZE" ? .5 : 1,
		objections,
		summary: objections.length === 0 ? "No structural, flow, crowding, or calendar objection survived. Pass." : objections.map((o) => `${o.severity} ${o.code}: ${o.detail}`).join(" ")
	};
}
function worst(objections) {
	if (objections.some((o) => o.severity === "BLOCK")) return "BLOCK";
	if (objections.some((o) => o.severity === "DELAY")) return "DELAY";
	if (objections.some((o) => o.severity === "DOWNSIZE")) return "DOWNSIZE";
	return "PASS";
}
function decide(input) {
	const now = input.now ?? Date.now();
	const packet = input.packet;
	const flow = computeOrderFlow(packet.trades, packet.lastPrice);
	const depthImb = bookImbalance(packet.bids, packet.asks);
	const flowUse = {
		...flow,
		imbalance: packet.trades.length > 20 ? flow.imbalance : depthImb
	};
	const profile = buildVolumeProfile(packet.candles5);
	const spread = packet.spreadBps || spreadBps(packet.bids, packet.asks);
	const plan = planTrade({
		symbol: packet.symbol,
		price: packet.lastPrice,
		candles: packet.candles5,
		candlesHtf: packet.candles1h.length ? packet.candles1h : packet.candles15,
		flow: flowUse,
		minRr: input.settings.minRr,
		profile
	});
	const side = plan.valid ? plan.side : null;
	const chart = readChart(packet, side);
	const sentiment = readSentiment(packet, side);
	const news = readNews(packet, input.settings, now);
	const similar = side ? recallSimilar(input.memories, side, packet.fundingRate, flowUse) : [];
	const range = atr(packet.candles5, 14);
	let skeptic = skepticReview({
		plan,
		flow: flowUse,
		profileShare: plan.valid ? binShareAt(profile, plan.hvn) : 0,
		pocShare: binShareAt(profile, profile.poc),
		chart,
		sentiment,
		news,
		similar,
		atr: Math.max(range, packet.lastPrice * .0018),
		settings: input.settings,
		spreadBps: spread
	});
	if (input.overrideReason && plan.valid && (skeptic.verdict === "BLOCK" || skeptic.verdict === "DELAY")) skeptic = {
		...skeptic,
		verdict: "DOWNSIZE",
		sizeFactor: .5,
		summary: `Human override logged: ${input.overrideReason} Original verdict stood down to half size. ${skeptic.summary}`
	};
	const onWatch = input.scored?.status === "WATCH";
	const risk = evaluateRisk({
		plan,
		skeptic,
		settings: input.settings,
		equity: input.equity,
		nav: input.nav,
		positions: input.positions,
		prices: input.prices,
		dayStartNav: input.dayStartNav,
		weekStartNav: input.weekStartNav,
		weeklyLock: input.weeklyLock,
		killed: input.killed,
		entriesPaused: input.entriesPaused,
		newsBlackout: news.blackout,
		spreadBps: spread,
		sizeFactor: plan.valid && onWatch ? skeptic.sizeFactor : 0
	});
	if (plan.valid && !onWatch) {
		risk.gates.push({
			name: "Watchlist",
			pass: false,
			detail: "Scanner has not promoted this pair. Study only — the executor will not send an order."
		});
		risk.approved = false;
		risk.reason = "Not on the watchlist.";
	}
	const messages = [];
	const score = input.scored;
	messages.push(msg("scanner", score ? `Score ${score.score.toFixed(1)} · ${score.status}` : "Unranked", score ? `${packet.symbol} bias ${score.bias}. Funding extreme ${(score.fundingExtreme * 100).toFixed(0)}, OI burst ${(score.oiBurst * 100).toFixed(0)}, divergence ${(score.divergence * 100).toFixed(0)}, liquidation ${(score.liquidation * 100).toFixed(0)}, book ${(score.book * 100).toFixed(0)}. Dampener ${score.dampener.toFixed(2)}. ${score.status === "WATCH" ? "Promoted." : "Not on the active watchlist — study only, no order."}` : `${packet.symbol} was studied without a scanner row.`, "info", packet.symbol, now));
	messages.push(msg("microstructure", plan.valid ? `${plan.side} ${plan.setup}` : "NO_TRADE", plan.valid ? plan.reason : plan.reason + ` OFI ${flowUse.ofi.toFixed(2)}, imbalance ${flowUse.imbalance.toFixed(2)}, VWAP dev ${(flowUse.vwapDev * 100).toFixed(2)}%, CVD ${flowUse.divergence.toLowerCase()}.`, plan.valid ? "info" : "warn", packet.symbol, now));
	messages.push(msg("chart", chart.dissent ? "Dissent" : "Aligned", chart.summary, chart.dissent ? "warn" : "pass", packet.symbol, now));
	messages.push(msg("sentiment", sentiment.sameSide ? "Crowded with the trade" : "Positioning", sentiment.summary, sentiment.sameSide ? "warn" : "info", packet.symbol, now));
	messages.push(msg("news", news.blackout ? "Blackout" : "Clear", news.summary, news.blackout ? "block" : "info", packet.symbol, now));
	messages.push(msg("skeptic", skeptic.verdict, skeptic.summary, skeptic.verdict === "PASS" ? "pass" : skeptic.verdict === "BLOCK" ? "block" : "warn", packet.symbol, now));
	let approved = risk.approved && plan.valid && onWatch && skeptic.verdict !== "BLOCK" && skeptic.verdict !== "DELAY";
	let riskReason = risk.reason;
	if (plan.valid && !onWatch) {
		approved = false;
		riskReason = "Not promoted. The scanner has not put this pair on the watchlist, so the executor will not trade it.";
	}
	messages.push(msg("risk", approved ? "Approved" : "Rejected", risk.gates.map((g) => `${g.pass ? "pass" : "fail"} · ${g.name}: ${g.detail}`).join(" "), approved ? "pass" : "block", packet.symbol, now));
	const memory = plan.valid && approved ? {
		id: uid("mem"),
		symbol: packet.symbol,
		setup: plan.setup,
		side: plan.side,
		funding: packet.fundingRate,
		ofi: flowUse.ofi,
		imbalance: flowUse.imbalance,
		vwapDev: flowUse.vwapDev,
		rr: plan.rr,
		rMultiple: null,
		outcome: "OPEN",
		ts: now
	} : null;
	const journal = {
		id: uid("tdr"),
		ts: now,
		kind: input.overrideReason ? "OVERRIDE" : approved ? "DECISION" : "SKIP",
		symbol: packet.symbol,
		title: approved ? `Paper ${plan.valid ? plan.side : ""} ${packet.symbol}` : `No fill · ${packet.symbol}`,
		body: [
			plan.valid ? plan.reason : plan.reason,
			`Skeptic ${skeptic.verdict}. ${skeptic.summary}`,
			riskReason,
			input.overrideReason ? `Override: ${input.overrideReason}` : "",
			similar.length ? `Similar history: ${similar.map((s) => `${s.memory.symbol} ${s.memory.rMultiple?.toFixed(2) ?? "n/a"}R`).join("; ")}.` : ""
		].filter(Boolean).join(" "),
		setup: plan.valid ? plan.setup : void 0,
		plannedRr: plan.valid ? plan.rr : void 0
	};
	messages.push(msg("executor", approved ? "Paper bracket armed" : "No order", approved && plan.valid ? `Isolated paper fill planned. Qty ${risk.qty.toPrecision(4)}, notional ${risk.notional.toFixed(0)}, leverage ${risk.leverage.toFixed(2)}x, stop ${plan.stop.toPrecision(6)}, target ${plan.target.toPrecision(6)}. STOP_MARKET and TAKE_PROFIT_MARKET are attached on the desk book.` : riskReason, approved ? "pass" : "warn", packet.symbol, now));
	messages.push(msg("journal", "Decision recorded", journal.body.slice(0, 420), "info", packet.symbol, now));
	return {
		messages,
		plan,
		skeptic,
		chart,
		sentiment,
		news,
		flow: flowUse,
		approved,
		qty: approved ? risk.qty : 0,
		leverage: risk.leverage,
		riskReason,
		gates: risk.gates,
		rrNet: risk.rrNet,
		journal,
		memory,
		similar
	};
}
function autopsy(pos) {
	const r = pos.rMultiple ?? 0;
	const planned = Math.abs(pos.target - pos.entry) / Math.max(Math.abs(pos.entry - pos.initialStop), 1e-9);
	const bits = [
		`${pos.symbol} ${pos.side} closed on ${pos.closeReason ?? "mark"} at ${r.toFixed(2)}R (planned structure about ${planned.toFixed(2)}R).`,
		`MAE ${pos.mae.toPrecision(4)}, MFE ${pos.mfe.toPrecision(4)} in price units.`,
		`Funding at entry ${(pos.fundingAtEntry * 100).toFixed(4)}%.`
	];
	if (pos.closeReason === "stop") bits.push(pos.breakevenArmed ? "Stop had already moved to entry. The give-back was a failed follow-through, not the original invalidation." : "The structural stop was tagged. If the wick only ran the node and reclaimed, the invalidation was too tight.");
	else if (pos.closeReason === "target") bits.push("Target tagged the opposing volume node. The path paid.");
	else if (pos.closeReason === "flow-reversal") bits.push("CVD and aggressive flow flipped before the hard stop. The desk flushed early.");
	else if (pos.closeReason === "kill") bits.push("Closed by the kill switch at the mark, not by the thesis.");
	if (pos.oiDeltaAtEntry != null && Math.abs(pos.oiDeltaAtEntry) > .03) bits.push(`Open interest was ${pos.oiDeltaAtEntry > 0 ? "building" : "unwinding"} into the entry (${(pos.oiDeltaAtEntry * 100).toFixed(1)}%).`);
	return bits.join(" ");
}
function buildBracket(plan, qty, leverage) {
	const side = plan.side === "LONG" ? "BUY" : "SELL";
	return {
		marginType: "ISOLATED",
		leverage: Math.max(1, Math.round(leverage * 100) / 100),
		venue: "paper",
		entry: {
			type: "MARKET",
			side,
			quantity: qty.toFixed(6)
		},
		protection: [{
			type: "STOP_MARKET",
			stopPrice: plan.stop.toPrecision(8),
			closePosition: true
		}, {
			type: "TAKE_PROFIT_MARKET",
			stopPrice: plan.target.toPrecision(8),
			closePosition: true
		}],
		note: "Paper venue. A live worker would submit these as native Binance brackets before returning, so the position survives a dead process. This desk enforces the same prices on every mark."
	};
}
function openPaper(input) {
	const { plan, qty, settings } = input;
	const slip = settings.slippageBps / 1e4;
	const dir = plan.side === "LONG" ? 1 : -1;
	const fill = plan.entry * (1 + slip * dir);
	const fee = Math.abs(fill * qty) * (settings.feeBps / 1e4);
	return {
		position: {
			id: uid("pos"),
			symbol: plan.symbol,
			contract: input.contract,
			side: plan.side,
			qty,
			entry: fill,
			stop: plan.stop,
			initialStop: plan.stop,
			target: plan.target,
			openedAt: input.now ?? Date.now(),
			status: "OPEN",
			fees: fee,
			mae: 0,
			mfe: 0,
			setup: plan.setup,
			fundingAtEntry: input.fundingRate,
			oiDeltaAtEntry: input.oiDeltaPct,
			breakevenArmed: false,
			bracket: buildBracket(plan, qty, input.leverage),
			overrideReason: input.overrideReason
		},
		fee
	};
}
/**
* Enforce stop, target, and breakeven on a single mark.
* If both stop and target are touched (gap), the stop wins.
*/
function markPosition(pos, price, settings, now = Date.now()) {
	if (pos.status !== "OPEN" || !(price > 0)) return {
		position: pos,
		closed: false,
		cashDelta: 0
	};
	const dir = pos.side === "LONG" ? 1 : -1;
	const excursion = (price - pos.entry) * dir;
	const next = {
		...pos,
		mae: Math.min(pos.mae, excursion),
		mfe: Math.max(pos.mfe, excursion)
	};
	const riskUnit = Math.abs(next.entry - next.initialStop);
	const rNow = riskUnit > 0 ? excursion / riskUnit : 0;
	if (!next.breakevenArmed && rNow >= settings.breakevenR) {
		next.stop = next.entry;
		next.breakevenArmed = true;
		next.bracket = {
			...next.bracket,
			protection: [{
				type: "STOP_MARKET",
				stopPrice: next.stop.toPrecision(8),
				closePosition: true
			}, next.bracket.protection[1]]
		};
	}
	const hitStop = dir === 1 ? price <= next.stop : price >= next.stop;
	const hitTarget = dir === 1 ? price >= next.target : price <= next.target;
	if (hitStop) return closeAt(next, next.stop, "stop", settings, now);
	if (hitTarget) return closeAt(next, next.target, "target", settings, now);
	return {
		position: next,
		closed: false,
		cashDelta: 0
	};
}
/** Exit before the hard stop when tape and CVD both flip. Never worse than the stop. */
function flowExit(pos, flow, price, settings, now = Date.now()) {
	if (pos.status !== "OPEN") return {
		position: pos,
		closed: false,
		cashDelta: 0
	};
	const againstFlow = pos.side === "LONG" ? flow.ofi < -.18 : flow.ofi > .18;
	const againstCvd = pos.side === "LONG" ? flow.divergence === "BEARISH" || flow.cvdSlope < 0 : flow.divergence === "BULLISH" || flow.cvdSlope > 0;
	if (!againstFlow || !againstCvd) return {
		position: pos,
		closed: false,
		cashDelta: 0
	};
	if ((pos.side === "LONG" ? 1 : -1) === 1 ? price <= pos.stop : price >= pos.stop) return markPosition(pos, price, settings, now);
	return closeAt(pos, price, "flow-reversal", settings, now);
}
function closeAt(pos, exit, reason, settings, now) {
	const dir = pos.side === "LONG" ? 1 : -1;
	const filled = exit * (1 - settings.slippageBps / 1e4 * dir);
	const exitFee = Math.abs(filled * pos.qty) * (settings.feeBps / 1e4);
	const gross = (filled - pos.entry) * dir * pos.qty;
	gross - exitFee;
	const riskCash = Math.abs(pos.entry - pos.initialStop) * pos.qty;
	const rMultiple = riskCash > 0 ? (gross - pos.fees - exitFee) / riskCash : 0;
	return {
		position: {
			...pos,
			status: "CLOSED",
			exit: filled,
			closedAt: now,
			closeReason: reason,
			fees: pos.fees + exitFee,
			realizedPnl: gross - exitFee - pos.fees,
			rMultiple
		},
		closed: true,
		cashDelta: gross - exitFee
	};
}
function flatten(pos, price, reason, settings, now = Date.now()) {
	if (pos.status !== "OPEN" || !(price > 0)) return {
		position: pos,
		closed: false,
		cashDelta: 0
	};
	return closeAt(pos, price, reason, settings, now);
}
/**
* Composite opportunity score, 0–100.
* Direction is contrarian to crowded funding: extreme positive funding biases SHORT.
* Missing OI does not zero the score — weights shift onto funding, divergence, and the book.
*/
function scoreSymbol(row, ctx = {}) {
	const f = row.fundingRate;
	const longCrowd = clamp(f / 5e-4, 0, 1);
	const shortCrowd = clamp(-f / 4e-4, 0, 1);
	const fundingExtreme = Math.max(longCrowd, shortCrowd);
	let bias = "NEUTRAL";
	if (longCrowd >= shortCrowd && longCrowd >= .35) bias = "SHORT";
	else if (shortCrowd > longCrowd && shortCrowd >= .35) bias = "LONG";
	const prev = ctx.prevFunding;
	const fundingVelocity = prev == null || !Number.isFinite(prev) ? 0 : clamp(Math.abs(f - prev) / 15e-5, 0, 1);
	const oiBurst = row.oiDeltaPct == null ? 0 : clamp(Math.abs(row.oiDeltaPct) / .08, 0, 1);
	let divergence = 0;
	const stalled = Math.abs(row.priceChangePct) < 1.4;
	if (row.oiDeltaPct != null && row.oiDeltaPct > .02 && Math.abs(row.priceChangePct) < 1.5) {
		divergence = .9;
		if (bias === "NEUTRAL") bias = row.priceChangePct <= 0 ? "SHORT" : "LONG";
	} else if (f > 25e-5 && row.priceChangePct < -.8) divergence = .75;
	else if (f < -2e-4 && row.priceChangePct > .8) divergence = .75;
	else if (fundingExtreme > .55 && stalled) divergence = .62;
	let liquidation = 0;
	if (row.liqCluster) liquidation = 1;
	else if (Math.abs(row.priceChangePct) > 7 && fundingExtreme > .45) liquidation = .85;
	else if (Math.abs(row.priceChangePct) > 12) liquidation = .45;
	const book = row.bookImbalance == null ? 0 : clamp(Math.abs(row.bookImbalance), 0, 1);
	const w = row.oiDeltaPct == null ? {
		f: .4,
		v: .14,
		o: 0,
		d: .2,
		l: .16,
		b: .1
	} : {
		f: .26,
		v: .1,
		o: .24,
		d: .18,
		l: .12,
		b: .1
	};
	const raw = w.f * fundingExtreme + w.v * fundingVelocity + w.o * oiBurst + w.d * divergence + w.l * liquidation + w.b * book;
	const dampener = clamp(ctx.dampener ?? 1, .55, 1.15);
	const score = clamp(raw * 100 * dampener, 0, 100);
	return {
		...row,
		fundingExtreme,
		fundingVelocity,
		oiBurst,
		divergence,
		liquidation,
		book,
		score,
		bias,
		dampener,
		status: "IDLE"
	};
}
function rankUniverse(rows, fundingMemory, dampeners) {
	return rows.map((row) => scoreSymbol(row, {
		prevFunding: fundingMemory[row.symbol],
		dampener: dampeners[row.symbol] ?? 1
	})).sort((a, b) => b.score - a.score || b.quoteVolume - a.quoteVolume);
}
/** Promote liquid names over the score floor; demote only after M consecutive misses. */
function nextWatch(ranked, prev, settings) {
	const state = {};
	const active = [];
	for (const row of ranked) {
		const prior = prev[row.symbol] ?? {
			below: 0,
			active: false
		};
		const liquid = row.quoteVolume >= settings.minQuoteVolume;
		const hot = row.score >= settings.scoreThreshold && liquid;
		let rec;
		if (hot) rec = {
			below: 0,
			active: true
		};
		else if (prior.active) {
			const below = prior.below + 1;
			rec = {
				below,
				active: below < settings.demoteScans
			};
		} else rec = {
			below: 0,
			active: false
		};
		state[row.symbol] = rec;
		if (rec.active) active.push(row);
	}
	active.sort((a, b) => b.score - a.score);
	const symbols = active.slice(0, settings.watchlistSize).map((r) => r.symbol);
	const keep = new Set(symbols);
	for (const sym of Object.keys(state)) if (state[sym].active && !keep.has(sym)) state[sym] = {
		...state[sym],
		active: false
	};
	return {
		state,
		symbols
	};
}
function withStatus(ranked, watch, settings) {
	return ranked.map((row) => ({
		...row,
		status: watch.has(row.symbol) ? "WATCH" : row.score >= settings.scoreThreshold * .85 && row.quoteVolume >= settings.minQuoteVolume ? "CANDIDATE" : "IDLE"
	}));
}
function dampenersFromMemory(memories) {
	const by = /* @__PURE__ */ new Map();
	for (const m of memories) {
		if (m.rMultiple == null) continue;
		const arr = by.get(m.symbol) ?? [];
		arr.push(m.rMultiple);
		by.set(m.symbol, arr);
	}
	const out = {};
	for (const [symbol, rs] of by) {
		if (rs.length < 3) continue;
		const wins = rs.filter((r) => r > 0).length / rs.length;
		const avg = rs.reduce((a, b) => a + b, 0) / rs.length;
		if (wins < .34 && avg < 0) out[symbol] = .68;
		else if (wins > .62 && avg > .35) out[symbol] = 1.08;
	}
	return out;
}
function freshClock(equity) {
	const now = /* @__PURE__ */ new Date();
	return {
		equity,
		dayKey: dayKey(now),
		weekKey: weekKey(now),
		dayStartNav: equity,
		weekStartNav: equity,
		weeklyLock: false,
		killed: false,
		entriesPaused: false,
		pauseReason: "",
		positions: [],
		journal: [],
		messages: [],
		memories: [],
		curve: [{
			t: Date.now(),
			nav: equity
		}],
		fundingMemory: {},
		watch: {}
	};
}
function pushCurve(curve, nav) {
	const last = curve[curve.length - 1];
	if (last && Date.now() - last.t < 2e4 && Math.abs(last.nav - nav) < .5) return curve;
	return [...curve, {
		t: Date.now(),
		nav
	}].slice(-400);
}
var useDesk = create()(persist((set) => ({
	settings: DEFAULT_SETTINGS,
	...freshClock(DEFAULT_SETTINGS.equityStart),
	deliberating: false,
	lastSymbol: null,
	lastPlan: null,
	lastSkeptic: null,
	lastFlow: null,
	busySymbol: null,
	commitScan: (ranked) => set((s) => {
		const { state } = nextWatch(ranked, s.watch, s.settings);
		const fundingMemory = {};
		for (const row of ranked.slice(0, 250)) fundingMemory[row.symbol] = row.fundingRate;
		return {
			watch: state,
			fundingMemory
		};
	}),
	patchSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch,
		riskPerTradePct: clampNum(patch.riskPerTradePct ?? s.settings.riskPerTradePct, .002, .01),
		maxHeatPct: clampNum(patch.maxHeatPct ?? s.settings.maxHeatPct, .005, .05),
		dailyLossPct: clampNum(patch.dailyLossPct ?? s.settings.dailyLossPct, .005, .1),
		weeklyLossPct: clampNum(patch.weeklyLossPct ?? s.settings.weeklyLossPct, .01, .2),
		minRr: clampNum(patch.minRr ?? s.settings.minRr, 1.2, 5),
		scoreThreshold: clampNum(patch.scoreThreshold ?? s.settings.scoreThreshold, 30, 90),
		events: patch.events ?? s.settings.events
	} })),
	addEvent: (event) => set((s) => ({ settings: {
		...s.settings,
		events: [...s.settings.events, event].slice(-20)
	} })),
	removeEvent: (id) => set((s) => ({ settings: {
		...s.settings,
		events: s.settings.events.filter((e) => e.id !== id)
	} })),
	setDeliberating: (symbol) => set({
		deliberating: Boolean(symbol),
		busySymbol: symbol
	}),
	applyDecision: (decision, packet) => set((s) => {
		let equity = s.equity;
		let positions = s.positions;
		const memories = decision.memory ? [decision.memory, ...s.memories].slice(0, 200) : s.memories;
		if (decision.approved && decision.plan.valid && decision.qty > 0) {
			if (!positions.some((p) => p.status === "OPEN" && p.symbol === packet.symbol)) {
				const opened = openPaper({
					plan: decision.plan,
					qty: decision.qty,
					leverage: Math.max(1, decision.leverage),
					settings: s.settings,
					fundingRate: packet.fundingRate,
					oiDeltaPct: packet.oiDeltaPct,
					contract: packet.contract,
					overrideReason: decision.journal.kind === "OVERRIDE" ? decision.journal.body : void 0
				});
				equity -= opened.fee;
				positions = [opened.position, ...positions];
			}
		}
		return {
			equity,
			positions,
			memories,
			messages: [...decision.messages, ...s.messages].slice(0, 140),
			journal: [decision.journal, ...s.journal].slice(0, 300),
			lastSymbol: packet.symbol,
			lastPlan: decision.plan,
			lastSkeptic: decision.skeptic,
			lastFlow: decision.flow,
			deliberating: false,
			busySymbol: null
		};
	}),
	markPrices: (prices) => set((s) => {
		const rolled = rollLimits(s, prices);
		let equity = rolled.equity;
		const journal = [...rolled.journal];
		const messages = [...rolled.messages];
		const memories = rolled.memories.map((m) => ({ ...m }));
		const positions = [];
		for (const pos of rolled.positions) {
			if (pos.status !== "OPEN") {
				positions.push(pos);
				continue;
			}
			const px = prices[pos.symbol];
			if (!(px > 0)) {
				positions.push(pos);
				continue;
			}
			const marked = markPosition(pos, px, rolled.settings);
			if (marked.closed) {
				equity += marked.cashDelta;
				positions.push(marked.position);
				settleClose(marked.position, memories, journal, messages);
			} else positions.push(marked.position);
		}
		const nav = navOf(equity, positions, prices);
		return {
			...applyBreaches({
				...rolled,
				equity,
				positions,
				journal,
				messages,
				memories
			}, nav),
			curve: pushCurve(rolled.curve, nav)
		};
	}),
	reviewFlow: (symbol, flow, price) => set((s) => {
		const idx = s.positions.findIndex((p) => p.status === "OPEN" && p.symbol === symbol);
		if (idx < 0) return {};
		const marked = flowExit(s.positions[idx], flow, price, s.settings);
		if (!marked.closed) return {};
		const positions = s.positions.slice();
		positions[idx] = marked.position;
		const memories = s.memories.map((m) => ({ ...m }));
		const journal = [...s.journal];
		const messages = [...s.messages];
		settleClose(marked.position, memories, journal, messages);
		const equity = s.equity + marked.cashDelta;
		return {
			positions,
			memories,
			journal: journal.slice(0, 300),
			messages: messages.slice(0, 140),
			equity
		};
	}),
	kill: (prices) => set((s) => {
		let equity = s.equity;
		const journal = [...s.journal];
		const messages = [...s.messages];
		const memories = s.memories.map((m) => ({ ...m }));
		const positions = s.positions.map((pos) => {
			if (pos.status !== "OPEN") return pos;
			const marked = flatten(pos, prices[pos.symbol] ?? pos.entry, "kill", s.settings);
			if (!marked.closed) return pos;
			equity += marked.cashDelta;
			settleClose(marked.position, memories, journal, messages);
			return marked.position;
		});
		const entry = {
			id: uid("kill"),
			ts: Date.now(),
			kind: "KILL",
			title: "Kill switch",
			body: "All paper positions flattened at the mark. Open brackets cancelled. New entries halted."
		};
		messages.unshift({
			id: uid("risk"),
			agent: "risk",
			ts: Date.now(),
			title: "Kill switch",
			body: entry.body,
			tone: "block"
		});
		return {
			equity,
			positions,
			memories,
			journal: [entry, ...journal].slice(0, 300),
			messages: messages.slice(0, 140),
			killed: true,
			entriesPaused: true,
			pauseReason: "Kill switch. Resume entries when you mean to trade again."
		};
	}),
	resumeEntries: () => set((s) => {
		if (s.weeklyLock) return {};
		return {
			killed: false,
			entriesPaused: false,
			pauseReason: ""
		};
	}),
	acknowledgeWeek: () => set((s) => ({
		weeklyLock: false,
		killed: false,
		entriesPaused: false,
		pauseReason: "",
		weekStartNav: navOf(s.equity, s.positions, Object.fromEntries(s.positions.filter((p) => p.status === "OPEN").map((p) => [p.symbol, p.entry]))),
		journal: [{
			id: uid("week"),
			ts: Date.now(),
			kind: "OVERRIDE",
			title: "Weekly halt acknowledged",
			body: "Manual re-enable after the weekly loss limit. The week baseline was reset to current NAV."
		}, ...s.journal].slice(0, 300)
	})),
	resetAccount: () => set((s) => ({
		...freshClock(s.settings.equityStart),
		settings: s.settings,
		deliberating: false,
		lastSymbol: null,
		lastPlan: null,
		lastSkeptic: null,
		lastFlow: null,
		busySymbol: null
	}))
}), {
	name: "volumetric-desk-v1",
	skipHydration: true,
	partialize: (s) => ({
		settings: s.settings,
		equity: s.equity,
		dayKey: s.dayKey,
		weekKey: s.weekKey,
		dayStartNav: s.dayStartNav,
		weekStartNav: s.weekStartNav,
		weeklyLock: s.weeklyLock,
		killed: s.killed,
		entriesPaused: s.entriesPaused,
		pauseReason: s.pauseReason,
		positions: s.positions,
		journal: s.journal.slice(0, 200),
		messages: s.messages.slice(0, 80),
		memories: s.memories.slice(0, 150),
		curve: s.curve.slice(-200),
		fundingMemory: s.fundingMemory,
		watch: s.watch
	})
}));
function clampNum(n, lo, hi) {
	if (!Number.isFinite(n)) return lo;
	return Math.min(hi, Math.max(lo, n));
}
function settleClose(pos, memories, journal, messages) {
	const mem = memories.find((m) => m.symbol === pos.symbol && m.outcome === "OPEN" && m.setup === pos.setup);
	if (mem && pos.rMultiple != null) {
		mem.rMultiple = pos.rMultiple;
		mem.outcome = pos.rMultiple > .05 ? "WIN" : pos.rMultiple < -.05 ? "LOSS" : "FLAT";
	}
	const body = autopsy(pos);
	journal.unshift({
		id: uid("close"),
		ts: pos.closedAt ?? Date.now(),
		kind: "CLOSE",
		symbol: pos.symbol,
		title: `${pos.symbol} ${pos.closeReason ?? "closed"} · ${(pos.rMultiple ?? 0).toFixed(2)}R`,
		body,
		rMultiple: pos.rMultiple,
		pnl: pos.realizedPnl,
		setup: pos.setup
	});
	messages.unshift({
		id: uid("journal"),
		agent: "journal",
		ts: pos.closedAt ?? Date.now(),
		symbol: pos.symbol,
		title: "Post-trade autopsy",
		body,
		tone: (pos.rMultiple ?? 0) >= 0 ? "pass" : "warn"
	});
}
function rollLimits(s, prices) {
	const nav = navOf(s.equity, s.positions, prices);
	const dk = dayKey();
	const wk = weekKey();
	if (dk === s.dayKey && wk === s.weekKey) return s;
	let entriesPaused = s.entriesPaused;
	let pauseReason = s.pauseReason;
	if (dk !== s.dayKey && pauseReason.startsWith("Daily")) {
		entriesPaused = s.weeklyLock || s.killed;
		pauseReason = entriesPaused ? s.pauseReason : "";
	}
	return {
		...s,
		dayKey: dk,
		weekKey: wk,
		dayStartNav: dk === s.dayKey ? s.dayStartNav : nav,
		weekStartNav: wk === s.weekKey ? s.weekStartNav : nav,
		entriesPaused,
		pauseReason
	};
}
function applyBreaches(s, nav) {
	if (weeklyBreach(nav, s.weekStartNav, s.settings)) return {
		...s,
		weeklyLock: true,
		entriesPaused: true,
		pauseReason: "Weekly loss limit. Entries stay off until you acknowledge it."
	};
	if (!s.weeklyLock && !s.killed && dailyBreach(nav, s.dayStartNav, s.settings)) return {
		...s,
		entriesPaused: true,
		pauseReason: "Daily loss limit. New entries halt until the next UTC day."
	};
	return s;
}
function pricesFrom(rows, positions) {
	const map = {};
	for (const row of rows) map[row.symbol] = row.lastPrice;
	for (const p of positions) if (map[p.symbol] == null) map[p.symbol] = p.entry;
	return map;
}
function accountNav(equity, positions, prices) {
	return navOf(equity, positions, prices);
}
function positionUpl(pos, price) {
	return unrealizedPnl(pos, price);
}
function ScannerView(props) {
	const filtered = props.rows.filter((r) => {
		if (!props.query) return true;
		return r.symbol.toLowerCase().includes(props.query.trim().toLowerCase());
	});
	const visible = props.showAll ? filtered : filtered.slice(0, 40);
	const watched = props.rows.filter((r) => r.status === "WATCH").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 md:flex-row md:items-end md:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-medium tracking-tight",
				children: "Universe"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 max-w-xl text-sm leading-relaxed text-muted",
				children: [
					props.universeCount,
					" perpetuals ranked. ",
					watched,
					" promoted to the watchlist. Promotion needs the score floor and a liquidity minimum — majors are not special."
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field sm:w-52",
						value: props.query,
						placeholder: "Filter symbol",
						"aria-label": "Filter symbol",
						onChange: (e) => props.onQuery(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => props.onShowAll(!props.showAll),
						children: props.showAll ? "Top of book" : "Full universe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: props.onScan,
						disabled: props.scanning,
						children: props.scanning ? "Scanning" : "Scan now"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "tape panel p-2 md:p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-separate border-spacing-0 text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs text-subtle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
						"Symbol",
						"Last",
						"24h",
						"Funding",
						"OI",
						"OI Δ",
						"Book",
						"Flags",
						"Score",
						""
					].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-2 py-2 font-medium",
						children: h
					}, h || "act")) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [visible.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-2 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: row.symbol.replace("USDT", "")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-subtle",
								children: row.status === "WATCH" ? "Watch" : row.status === "CANDIDATE" ? "Candidate" : "Idle"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-2 py-2",
							children: fmtPx(row.lastPrice)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `num px-2 py-2 ${signedClass(row.priceChangePct)}`,
							children: fmtPct(row.priceChangePct)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `num px-2 py-2 ${signedClass(row.fundingRate)}`,
							children: fmtFunding(row.fundingRate)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "num px-2 py-2 text-muted",
							children: row.oi == null ? "—" : compact(row.oi)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `num px-2 py-2 ${row.oiDeltaPct == null ? "text-subtle" : signedClass(row.oiDeltaPct)}`,
							children: row.oiDeltaPct == null ? "—" : fmtPct(row.oiDeltaPct * 100, 1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `num px-2 py-2 ${signedClass(row.bookImbalance ?? 0)}`,
							children: row.bookImbalance == null ? "—" : row.bookImbalance.toFixed(2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 text-xs text-muted",
							children: [
								row.divergence > .6 ? "DIV" : null,
								row.liqCluster || row.liquidation > .7 ? "LIQ" : null,
								row.bias !== "NEUTRAL" ? row.bias : null
							].filter(Boolean).join(" · ") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-2 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num text-sm",
								children: row.score.toFixed(1)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1 w-16 rounded-full bg-surface-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-1 rounded-full bg-accent",
									style: { width: `${Math.max(4, Math.min(100, row.score))}%` }
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost px-3",
								onClick: () => props.onStudy(row),
								disabled: props.busySymbol === row.symbol,
								children: props.busySymbol === row.symbol ? "Reading" : "Study"
							})
						})
					]
				}, row.symbol)), !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 10,
					className: "px-2 py-8 text-sm text-muted",
					children: "Nothing matched. Lower the score floor in Settings, or wait for the next scan."
				}) })] })]
			})
		})]
	});
}
function DeskView(props) {
	const profile = props.packet ? buildVolumeProfile(props.packet.candles5) : null;
	const maxBin = profile ? Math.max(...profile.bins.map((b) => b.volume), 1) : 1;
	const canOverride = props.plan?.valid && props.skeptic && (props.skeptic.verdict === "BLOCK" || props.skeptic.verdict === "DELAY");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(18rem,0.8fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel flex flex-col gap-3 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium tracking-tight",
					children: "Live desk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Scanner, microstructure, structure, sentiment, and news speak first. The Skeptic can block. Risk can still refuse. The executor only papers a bracket after both."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "flex flex-col gap-3",
					children: [props.messages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-lg border border-border bg-bg p-4 text-sm text-muted",
						children: props.busy ? "Agents are reading the tape." : "Pick a symbol on the scanner, or leave auto-study on. A quiet book is a valid outcome."
					}), props.messages.slice(0, 24).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-border bg-bg px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: AGENT_LABEL[m.agent]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "num text-xs text-subtle",
									children: fmtTime(m.ts)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `mt-1 text-sm ${m.tone === "block" ? "text-down" : m.tone === "pass" ? "text-up" : "text-fg"}`,
								children: m.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: m.body
							})
						]
					}, m.id))]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex flex-col gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Trade ticket"
					}),
					!props.plan && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "No plan yet."
					}),
					props.plan && !props.plan.valid && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: ["NO TRADE. ", props.plan.reason]
					}),
					props.plan?.valid && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Side",
								v: props.plan.side
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Setup",
								v: props.plan.setup
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Entry",
								v: fmtPx(props.plan.entry),
								mono: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Stop",
								v: fmtPx(props.plan.stop),
								mono: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Target",
								v: fmtPx(props.plan.target),
								mono: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Structural R",
								v: props.plan.rr.toFixed(2),
								mono: true
							})
						]
					}),
					props.skeptic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: `mt-3 text-sm leading-relaxed ${props.skeptic.verdict === "BLOCK" ? "text-down" : "text-muted"}`,
						children: [
							"Skeptic ",
							props.skeptic.verdict,
							". ",
							props.skeptic.objections[0]?.detail ?? props.skeptic.summary
						]
					}),
					canOverride && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverrideBox, { onOverride: props.onOverride })
				]
			}), profile && profile.bins.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Volume profile"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-subtle",
						children: [
							"POC ",
							fmtPx(profile.poc),
							" · VA ",
							fmtPx(profile.val),
							" – ",
							fmtPx(profile.vah)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex h-28 items-end gap-px",
						children: profile.bins.map((b) => {
							const poc = Math.abs(b.price - profile.poc) < Math.abs(profile.bins[1]?.price - profile.bins[0]?.price || 1);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: poc ? "bg-accent" : "bg-surface-2",
								style: {
									height: `${Math.max(6, b.volume / maxBin * 100)}%`,
									flex: 1
								},
								title: `${fmtPx(b.price)} · ${(b.share * 100).toFixed(1)}%`
							}, b.price);
						})
					})
				]
			})]
		})]
	});
}
function OverrideBox({ onOverride }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-4 flex flex-col gap-2",
		onSubmit: (e) => {
			e.preventDefault();
			const data = new FormData(e.currentTarget);
			const reason = String(data.get("reason") ?? "").trim();
			if (reason.length < 12) return;
			onOverride(reason);
			e.currentTarget.reset();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-xs text-subtle",
				htmlFor: "override-reason",
				children: "Human override. A block is otherwise final. Risk limits still apply. Say why."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "override-reason",
				name: "reason",
				required: true,
				minLength: 12,
				className: "field min-h-20 py-2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "btn btn-ghost",
				children: "Log override and resize"
			})
		]
	});
}
function Stat({ k, v, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-subtle",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: mono ? "num mt-1" : "mt-1",
		children: v
	})] });
}
function BookView(props) {
	const open = props.positions.filter((p) => p.status === "OPEN");
	const closed = props.positions.filter((p) => p.status === "CLOSED").slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
						label: "Portfolio heat",
						value: props.heat,
						cap: props.heatCap,
						text: `${(props.heat * 100).toFixed(2)}% / ${(props.heatCap * 100).toFixed(1)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
						label: "Day P&L vs halt",
						value: Math.max(0, -props.dayPnl / Math.max(props.nav - props.dayPnl, 1)),
						cap: props.dayLimit,
						text: fmtUsd(props.dayPnl),
						tone: props.dayPnl
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
						label: "Week P&L vs halt",
						value: Math.max(0, -props.weekPnl / Math.max(props.nav - props.weekPnl, 1)),
						cap: props.weekLimit,
						text: fmtUsd(props.weekPnl),
						tone: props.weekPnl
					})
				]
			}),
			props.pauseReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-down",
					children: props.pauseReason
				}), props.weeklyLock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					onClick: props.onAckWeek,
					children: "Acknowledge week"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Open positions"
					}),
					!open.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Flat. The book is empty, which is allowed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-3",
						children: open.map((p) => {
							const upl = positionUpl(p, props.prices[p.symbol] ?? p.entry);
							const risk = Math.abs(p.entry - p.initialStop) * p.qty;
							const r = risk > 0 ? upl / risk : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-lg border border-border bg-bg p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-medium",
											children: [
												p.symbol,
												" · ",
												p.side
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `num ${signedClass(upl)}`,
											children: [
												fmtUsd(upl),
												" · ",
												r.toFixed(2),
												"R"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "num mt-2 text-xs text-muted",
										children: [
											"Entry ",
											fmtPx(p.entry),
											" · Stop ",
											fmtPx(p.stop),
											p.breakevenArmed ? " (entry)" : "",
											" · Target ",
											fmtPx(p.target),
											" · Qty ",
											fmtQty(p.qty)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-subtle",
										children: p.bracket.note
									})
								]
							}, p.id);
						})
					})
				]
			}),
			closed.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Recent closes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 flex flex-col gap-2 text-sm",
					children: closed.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							p.symbol,
							" · ",
							p.closeReason
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `num ${signedClass(p.realizedPnl ?? 0)}`,
							children: [(p.rMultiple ?? 0).toFixed(2), "R"]
						})]
					}, p.id))
				})]
			})
		]
	});
}
function Gauge({ label, value, cap, text, tone = 0 }) {
	const pct = Math.max(0, Math.min(100, cap > 0 ? value / cap * 100 : 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-subtle",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `num mt-2 text-lg ${signedClass(tone)}`,
				children: text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-1.5 rounded-full bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `h-1.5 rounded-full ${pct > 85 ? "bg-down" : "bg-accent"}`,
					style: { width: `${pct}%` }
				})
			})
		]
	});
}
function JournalView(props) {
	const closes = props.journal.filter((j) => j.kind === "CLOSE" && j.rMultiple != null);
	const wins = closes.filter((j) => (j.rMultiple ?? 0) > 0).length;
	const bySetup = /* @__PURE__ */ new Map();
	for (const j of closes) {
		const key = j.setup ?? "Other";
		const cur = bySetup.get(key) ?? {
			n: 0,
			r: 0
		};
		cur.n += 1;
		cur.r += j.rMultiple ?? 0;
		bySetup.set(key, cur);
	}
	const bars = [...bySetup.entries()].map(([setup, v]) => ({
		setup,
		avg: v.r / v.n,
		n: v.n
	}));
	const rs = closes.map((j) => ({ r: Number((j.rMultiple ?? 0).toFixed(2)) }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-subtle",
							children: "Closed trades"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num mt-2 text-lg",
							children: closes.length
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-subtle",
							children: "Win rate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num mt-2 text-lg",
							children: closes.length ? `${(wins / closes.length * 100).toFixed(0)}%` : "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-subtle",
							children: "Average R"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num mt-2 text-lg",
							children: closes.length ? (closes.reduce((s, j) => s + (j.rMultiple ?? 0), 0) / closes.length).toFixed(2) : "—"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "Equity"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-52",
					children: props.mounted && props.curve.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: props.curve,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "t",
									hide: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									hide: true,
									domain: ["auto", "auto"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									formatter: (v) => fmtUsd(Number(v)),
									labelFormatter: (t) => fmtTime(Number(t)),
									contentStyle: {
										background: "var(--color-surface)",
										border: "1px solid var(--color-border)",
										borderRadius: 12,
										color: "var(--color-fg)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									dataKey: "nav",
									stroke: "var(--color-accent)",
									fill: "var(--color-surface-2)",
									strokeWidth: 1.5
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "The curve starts after the first marks. One point is not a result."
					})
				})]
			}),
			props.mounted && rs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "R multiples"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: rs,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "r",
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "r",
										fill: "var(--color-muted)"
									})
								]
							})
						})
					}),
					bars.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 text-sm text-muted",
						children: bars.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							b.setup,
							": ",
							b.n,
							" trades, avg ",
							b.avg.toFixed(2),
							"R"
						] }, b.setup))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Decision record"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 flex flex-col gap-3",
					children: [props.journal.slice(0, 30).map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-border pt-3 first:border-0 first:pt-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: j.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "num text-xs text-subtle",
								children: fmtTime(j.ts)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: j.body
						})]
					}, j.id)), !props.journal.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: "No decisions yet. Skips are recorded too."
					})]
				})]
			})
		]
	});
}
function SettingsView(props) {
	const s = props.settings;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel flex flex-col gap-4 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Risk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Risk per trade",
						suffix: "%",
						value: s.riskPerTradePct * 100,
						min: .2,
						max: 1,
						step: .05,
						onChange: (n) => props.onPatch({ riskPerTradePct: n / 100 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Max portfolio heat",
						suffix: "%",
						value: s.maxHeatPct * 100,
						min: .5,
						max: 5,
						step: .1,
						onChange: (n) => props.onPatch({ maxHeatPct: n / 100 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Daily loss halt",
						suffix: "%",
						value: s.dailyLossPct * 100,
						min: .5,
						max: 10,
						step: .1,
						onChange: (n) => props.onPatch({ dailyLossPct: n / 100 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Weekly loss halt",
						suffix: "%",
						value: s.weeklyLossPct * 100,
						min: 1,
						max: 20,
						step: .5,
						onChange: (n) => props.onPatch({ weeklyLossPct: n / 100 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Minimum structural R:R",
						value: s.minRr,
						min: 1.2,
						max: 5,
						step: .1,
						onChange: (n) => props.onPatch({ minRr: n })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Max correlated alts",
						value: s.maxCorrelated,
						min: 1,
						max: 6,
						step: 1,
						onChange: (n) => props.onPatch({ maxCorrelated: n })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel flex flex-col gap-4 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Scanner"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Score threshold",
						value: s.scoreThreshold,
						min: 30,
						max: 90,
						step: 1,
						onChange: (n) => props.onPatch({ scoreThreshold: n })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Watchlist size",
						value: s.watchlistSize,
						min: 5,
						max: 30,
						step: 1,
						onChange: (n) => props.onPatch({ watchlistSize: n })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Demote after misses",
						value: s.demoteScans,
						min: 1,
						max: 8,
						step: 1,
						onChange: (n) => props.onPatch({ demoteScans: n })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Min 24h quote volume",
						suffix: "M",
						value: s.minQuoteVolume / 1e6,
						min: .5,
						max: 100,
						step: .5,
						onChange: (n) => props.onPatch({ minQuoteVolume: n * 1e6 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "News blackout",
						suffix: "min",
						value: s.newsBlackoutMin,
						min: 5,
						max: 180,
						step: 5,
						onChange: (n) => props.onPatch({ newsBlackoutMin: n })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "Scan every",
						suffix: "s",
						value: s.scanIntervalSec,
						min: 20,
						max: 180,
						step: 5,
						onChange: (n) => props.onPatch({ scanIntervalSec: n })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center justify-between gap-3 text-sm",
						children: ["Auto-study the top watch name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: s.autoDeliberate,
							onChange: (e) => props.onPatch({ autoDeliberate: e.target.checked })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel flex flex-col gap-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Macro calendar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Entries block inside the blackout window around each event. Empty means the news agent only watches headlines."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex flex-col gap-2 sm:flex-row",
						onSubmit: (e) => {
							e.preventDefault();
							const data = new FormData(e.currentTarget);
							const name = String(data.get("name") ?? "").trim();
							const when = String(data.get("when") ?? "");
							const at = Date.parse(when);
							if (!name || !Number.isFinite(at)) return;
							props.onAddEvent(name, at);
							e.currentTarget.reset();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "name",
								required: true,
								placeholder: "CPI, FOMC, unlock",
								"aria-label": "Event name",
								className: "field"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "when",
								required: true,
								type: "datetime-local",
								"aria-label": "Event time",
								className: "field"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn btn-ghost",
								children: "Add"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2 text-sm",
						children: s.events.map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								ev.name,
								" · ",
								new Date(ev.at).toLocaleString()
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost px-3",
								onClick: () => props.onRemoveEvent(ev.id),
								children: "Remove"
							})]
						}, ev.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel flex flex-col gap-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Venue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: "This hosted desk does not place live orders. API keys are not requested and are not stored. A self-hosted worker would still need an environment flag, this confirmation, and a futures-enabled key — three gates — before any order left the machine. Here, all three stay shut."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "list-decimal pl-5 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Live environment flag: off." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Explicit confirmation: not available." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Exchange keys: not collected." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [(props.paused || props.killed) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: props.onResume,
							children: "Resume paper entries"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: props.onReset,
							children: "Reset paper account"
						})]
					})
				]
			})
		]
	});
}
function NumberField(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline justify-between text-muted",
			children: [props.label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "num text-fg",
				children: [props.value.toFixed(props.step < 1 ? 2 : 0), props.suffix ? ` ${props.suffix}` : ""]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: props.min,
			max: props.max,
			step: props.step,
			value: props.value,
			onChange: (e) => props.onChange(Number(e.target.value)),
			className: "w-full accent-current"
		})]
	});
}
function Modal(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
		role: "presentation",
		onClick: props.onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "modal-title",
			className: "panel w-full max-w-md p-5",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "modal-title",
					className: "text-lg font-medium",
					children: props.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: props.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: props.onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: props.onConfirm,
						children: props.confirm
					})]
				})
			]
		})
	});
}
var NAV = [
	{
		id: "scan",
		label: "Scanner",
		icon: ScanSearch
	},
	{
		id: "desk",
		label: "Desk",
		icon: MessagesSquare
	},
	{
		id: "book",
		label: "Book",
		icon: Briefcase
	},
	{
		id: "journal",
		label: "Journal",
		icon: BookOpen
	},
	{
		id: "settings",
		label: "Settings",
		icon: SlidersHorizontal
	}
];
var inflight = /* @__PURE__ */ new Set();
function DeskApp({ initial }) {
	const [view, setView] = (0, import_react.useState)("scan");
	const [rows, setRows] = (0, import_react.useState)(initial.rows);
	const [note, setNote] = (0, import_react.useState)(initial.note);
	const [venue, setVenue] = (0, import_react.useState)(initial.venue);
	const [fetchedAt, setFetchedAt] = (0, import_react.useState)(initial.fetchedAt);
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(initial.error ?? "");
	const [query, setQuery] = (0, import_react.useState)("");
	const [showAll, setShowAll] = (0, import_react.useState)(false);
	const [killOpen, setKillOpen] = (0, import_react.useState)(false);
	const [resetOpen, setResetOpen] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [packet, setPacket] = (0, import_react.useState)(null);
	const busy = (0, import_react.useRef)(false);
	const lastAuto = (0, import_react.useRef)("");
	const settings = useDesk((s) => s.settings);
	const equity = useDesk((s) => s.equity);
	const positions = useDesk((s) => s.positions);
	const watch = useDesk((s) => s.watch);
	const messages = useDesk((s) => s.messages);
	const journal = useDesk((s) => s.journal);
	const curve = useDesk((s) => s.curve);
	const killed = useDesk((s) => s.killed);
	const entriesPaused = useDesk((s) => s.entriesPaused);
	const pauseReason = useDesk((s) => s.pauseReason);
	const weeklyLock = useDesk((s) => s.weeklyLock);
	const fundingMemory = useDesk((s) => s.fundingMemory);
	const memories = useDesk((s) => s.memories);
	const dayStartNav = useDesk((s) => s.dayStartNav);
	const weekStartNav = useDesk((s) => s.weekStartNav);
	const lastPlan = useDesk((s) => s.lastPlan);
	const lastSkeptic = useDesk((s) => s.lastSkeptic);
	const busySymbol = useDesk((s) => s.busySymbol);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		Promise.resolve(useDesk.persist.rehydrate()).finally(() => setHydrated(true));
	}, []);
	const damp = (0, import_react.useMemo)(() => dampenersFromMemory(memories), [memories]);
	const watchSet = (0, import_react.useMemo)(() => new Set(Object.entries(watch).filter(([, v]) => v.active).map(([k]) => k)), [watch]);
	const ranked = (0, import_react.useMemo)(() => withStatus(rankUniverse(rows, fundingMemory, damp), watchSet, settings), [
		rows,
		fundingMemory,
		damp,
		watchSet,
		settings
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const state = useDesk.getState();
		const rankedNow = rankUniverse(rows, state.fundingMemory, dampenersFromMemory(state.memories));
		state.commitScan(rankedNow);
		state.markPrices(pricesFrom(rows, state.positions));
	}, [
		fetchedAt,
		hydrated,
		rows,
		settings.scoreThreshold,
		settings.minQuoteVolume,
		settings.watchlistSize,
		settings.demoteScans
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated || venue === "sim" || !rows.length) return;
		let cancel = false;
		const state = useDesk.getState();
		const active = new Set(Object.entries(state.watch).filter(([, v]) => v.active).map(([k]) => k));
		const pool = rankUniverse(rows, state.fundingMemory, dampenersFromMemory(state.memories));
		const picks = (active.size ? pool.filter((r) => active.has(r.symbol)) : pool).filter((r) => r.oiDeltaPct == null).slice(0, 6);
		if (!picks.length) return;
		fetchEnrichment({ data: { items: picks.map((p) => ({
			symbol: p.symbol,
			contract: p.contract,
			venue: p.venue
		})) } }).then((found) => {
			if (cancel || !found?.length) return;
			setRows((prev) => prev.map((row) => {
				const e = found.find((x) => x.symbol === row.symbol);
				if (!e) return row;
				return {
					...row,
					oi: e.oi ?? row.oi,
					oiDeltaPct: e.oiDeltaPct,
					longShortRatio: e.longShortRatio,
					liqCluster: e.liqCluster || row.liqCluster,
					liqNotional: e.liqNotional
				};
			}));
		}).catch(() => void 0);
		return () => {
			cancel = true;
		};
	}, [
		fetchedAt,
		hydrated,
		venue
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const ms = Math.max(20, settings.scanIntervalSec) * 1e3;
		const id = window.setInterval(() => void refresh(), ms);
		return () => window.clearInterval(id);
	}, [hydrated, settings.scanIntervalSec]);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !settings.autoDeliberate) return;
		const state = useDesk.getState();
		if (state.killed || state.weeklyLock || state.entriesPaused || state.deliberating) return;
		const top = ranked.find((r) => r.status === "WATCH" && !state.positions.some((p) => p.status === "OPEN" && p.symbol === r.symbol));
		if (!top) return;
		const key = `${fetchedAt}:${top.symbol}`;
		if (lastAuto.current === key) return;
		lastAuto.current = key;
		study(top, false);
	}, [
		fetchedAt,
		hydrated,
		ranked,
		settings.autoDeliberate
	]);
	async function refresh() {
		setScanning(true);
		try {
			const snap = await fetchUniverse();
			setRows(snap.rows);
			setNote(snap.note);
			setVenue(snap.venue);
			setFetchedAt(snap.fetchedAt);
			setError(snap.error ?? "");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Scan failed");
		} finally {
			setScanning(false);
		}
	}
	async function study(row, focusDesk) {
		if (busy.current || inflight.has(row.symbol)) return;
		busy.current = true;
		inflight.add(row.symbol);
		if (focusDesk) setView("desk");
		useDesk.getState().setDeliberating(row.symbol);
		try {
			const next = await fetchPacket({ data: {
				symbol: row.symbol,
				contract: row.contract,
				venue: row.venue,
				lastPrice: row.lastPrice,
				fundingRate: row.fundingRate
			} });
			setPacket(next);
			const state = useDesk.getState();
			const had = state.positions.some((p) => p.status === "OPEN" && p.symbol === row.symbol);
			const prices = pricesFrom(rows, state.positions);
			if (next.lastPrice > 0) prices[row.symbol] = next.lastPrice;
			const nav = accountNav(state.equity, state.positions, prices);
			const decision = decide({
				packet: next,
				scored: {
					...row,
					oiDeltaPct: next.oiDeltaPct ?? row.oiDeltaPct,
					longShortRatio: next.longShortRatio ?? row.longShortRatio,
					liqCluster: next.liqCluster || row.liqCluster,
					status: state.watch[row.symbol]?.active ? "WATCH" : row.status
				},
				settings: state.settings,
				nav,
				equity: state.equity,
				positions: state.positions,
				prices,
				dayStartNav: state.dayStartNav,
				weekStartNav: state.weekStartNav,
				weeklyLock: state.weeklyLock,
				killed: state.killed,
				entriesPaused: state.entriesPaused,
				memories: state.memories
			});
			state.applyDecision(decision, next);
			if (had) useDesk.getState().reviewFlow(row.symbol, decision.flow, next.lastPrice || row.lastPrice);
			setError("");
		} catch (err) {
			useDesk.getState().setDeliberating(null);
			setError(err instanceof Error ? err.message : "The packet failed.");
		} finally {
			inflight.delete(row.symbol);
			busy.current = false;
		}
	}
	function override(reason) {
		const state = useDesk.getState();
		const row = ranked.find((r) => r.symbol === state.lastSymbol);
		if (!packet || !row || !state.lastPlan?.valid) return;
		const prices = pricesFrom(rows, state.positions);
		const nav = accountNav(state.equity, state.positions, prices);
		const decision = decide({
			packet,
			scored: {
				...row,
				status: state.watch[row.symbol]?.active ? "WATCH" : row.status
			},
			settings: state.settings,
			nav,
			equity: state.equity,
			positions: state.positions,
			prices,
			dayStartNav: state.dayStartNav,
			weekStartNav: state.weekStartNav,
			weeklyLock: state.weeklyLock,
			killed: state.killed,
			entriesPaused: state.entriesPaused,
			memories: state.memories,
			overrideReason: reason
		});
		state.applyDecision(decision, packet);
	}
	const prices = (0, import_react.useMemo)(() => pricesFrom(rows, positions), [rows, positions]);
	const nav = accountNav(equity, positions, prices);
	const open = positions.filter((p) => p.status === "OPEN");
	const heat = open.reduce((s, p) => s + Math.abs(p.entry - p.stop) * p.qty, 0) / Math.max(nav, 1);
	const dayPnl = nav - dayStartNav;
	const weekPnl = nav - weekStartNav;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-4 py-3 md:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-4xl text-xs leading-relaxed text-muted md:text-sm",
					children: "Most systematic strategies do not keep a durable edge. This desk measures and refuses trades. It does not promise profit. Fills are paper. Stops live in this book, not on an exchange. Simulated losses are the honest version of real ones."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-bg px-4 py-3 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-subtle",
						children: "PAPER"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-medium tracking-tight md:text-2xl",
						children: "Volumetric Desk"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: () => setKillOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Octagon, {
							className: "size-4",
							"aria-hidden": true
						}), "Kill"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["NAV ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "num",
							children: fmtUsd(nav)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Day ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `num ${signedClass(dayPnl)}`,
							children: fmtUsd(dayPnl)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Heat ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "num",
							children: [(heat * 100).toFixed(2), "%"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [open.length, " open"]
						}),
						(killed || entriesPaused) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-down",
							children: "Halted"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:grid md:grid-cols-[11rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden border-r border-border md:flex md:flex-col md:gap-1 md:p-3",
					"aria-label": "Sections",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						item,
						active: view === item.id,
						onClick: () => setView(item.id)
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "min-w-0 px-4 py-4 pb-24 md:px-6 md:pb-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 text-xs leading-relaxed text-subtle",
							children: note
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 text-sm text-down",
							children: error
						}),
						view === "scan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScannerView, {
							rows: ranked,
							query,
							onQuery: setQuery,
							showAll,
							onShowAll: setShowAll,
							universeCount: rows.length,
							scanning,
							onScan: () => void refresh(),
							onStudy: (row) => void study(row, true),
							busySymbol
						}),
						view === "desk" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskView, {
							messages,
							plan: lastPlan,
							skeptic: lastSkeptic,
							packet,
							busy: Boolean(busySymbol),
							onOverride: override
						}),
						view === "book" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookView, {
							positions,
							prices,
							nav,
							heat,
							heatCap: settings.maxHeatPct,
							dayPnl,
							weekPnl,
							dayLimit: settings.dailyLossPct,
							weekLimit: settings.weeklyLossPct,
							pauseReason,
							weeklyLock,
							onAckWeek: () => useDesk.getState().acknowledgeWeek()
						}),
						view === "journal" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalView, {
							curve,
							journal,
							mounted
						}),
						view === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {
							settings,
							paused: entriesPaused,
							killed,
							onPatch: (patch) => useDesk.getState().patchSettings(patch),
							onAddEvent: (name, at) => useDesk.getState().addEvent({
								id: uid("ev"),
								name,
								at
							}),
							onRemoveEvent: (id) => useDesk.getState().removeEvent(id),
							onReset: () => setResetOpen(true),
							onResume: () => useDesk.getState().resumeEntries()
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-surface md:hidden",
				"aria-label": "Sections",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `flex min-h-14 flex-1 flex-col items-center justify-center gap-1 text-xs ${view === item.id ? "text-fg" : "text-subtle"}`,
					onClick: () => setView(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
						className: "size-4",
						"aria-hidden": true
					}), item.label]
				}, item.id))
			}),
			killOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				title: "Flatten the book",
				body: "Cancel every working paper bracket and close every open position at the last mark. New entries stay halted until you resume.",
				confirm: "Kill switch",
				onClose: () => setKillOpen(false),
				onConfirm: () => {
					useDesk.getState().kill(pricesFrom(rows, useDesk.getState().positions));
					setKillOpen(false);
					setView("book");
				}
			}),
			resetOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				title: "Reset the paper account",
				body: "Clears positions, the journal, and the equity curve. Scanner settings stay. This cannot be undone.",
				confirm: "Reset account",
				onClose: () => setResetOpen(false),
				onConfirm: () => {
					useDesk.getState().resetAccount();
					setResetOpen(false);
				}
			})
		]
	});
}
function NavButton({ item, active, onClick }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `flex min-h-11 items-center gap-2 rounded-md px-3 text-left text-sm ${active ? "bg-surface-2 text-fg" : "text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			"aria-hidden": true
		}), item.label]
	});
}
function Home() {
	const initial = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskApp, { initial });
}
//#endregion
export { Home as component };
