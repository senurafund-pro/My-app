//#region node_modules/.nitro/vite/services/ssr/assets/math-B29EofKM.js
function clamp(n, lo, hi) {
	if (!Number.isFinite(n)) return lo;
	return Math.min(hi, Math.max(lo, n));
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36)}`;
}
function atr(candles, n = 14) {
	if (candles.length < 2) return 0;
	const trs = [];
	for (let i = 1; i < candles.length; i++) {
		const c = candles[i];
		const prev = candles[i - 1].c;
		trs.push(Math.max(c.h - c.l, Math.abs(c.h - prev), Math.abs(c.l - prev)));
	}
	const slice = trs.slice(-n);
	if (!slice.length) return 0;
	return slice.reduce((a, b) => a + b, 0) / slice.length;
}
/** Kaufman efficiency: 1 is a straight line, ~0 is noise. */
function trendEfficiency(candles) {
	if (candles.length < 5) return 0;
	const net = Math.abs(candles[candles.length - 1].c - candles[0].c);
	let path = 0;
	for (let i = 1; i < candles.length; i++) path += Math.abs(candles[i].c - candles[i - 1].c);
	return path === 0 ? 0 : net / path;
}
function ema(values, n) {
	if (!values.length) return 0;
	const k = 2 / (n + 1);
	let e = values[0];
	for (let i = 1; i < values.length; i++) e = values[i] * k + e * (1 - k);
	return e;
}
function dayKey(d = /* @__PURE__ */ new Date()) {
	return d.toISOString().slice(0, 10);
}
function weekKey(d = /* @__PURE__ */ new Date()) {
	const date = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
	const day = date.getUTCDay() || 7;
	date.setUTCDate(date.getUTCDate() + 4 - day);
	const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
	const week = Math.ceil(((date.getTime() - yearStart.getTime()) / 864e5 + 1) / 7);
	return `${date.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}
function cosine(a, b) {
	let dot = 0;
	let na = 0;
	let nb = 0;
	const n = Math.min(a.length, b.length);
	for (let i = 0; i < n; i++) {
		dot += a[i] * b[i];
		na += a[i] * a[i];
		nb += b[i] * b[i];
	}
	if (na === 0 || nb === 0) return 0;
	return dot / Math.sqrt(na * nb);
}
function mean(xs) {
	if (!xs.length) return 0;
	return xs.reduce((a, b) => a + b, 0) / xs.length;
}
function median(xs) {
	if (!xs.length) return 0;
	const s = [...xs].sort((a, b) => a - b);
	const m = Math.floor(s.length / 2);
	return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
//#endregion
export { ema as a, trendEfficiency as c, dayKey as i, uid as l, clamp as n, mean as o, cosine as r, median as s, atr as t, weekKey as u };
