import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { s as median } from "./math-B29EofKM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-2T1O5i0P.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var NAMES = [
	"BTC",
	"ETH",
	"SOL",
	"BNB",
	"XRP",
	"DOGE",
	"ADA",
	"AVAX",
	"LINK",
	"SUI",
	"WLD",
	"INJ",
	"TIA",
	"SEI",
	"NEAR",
	"APT",
	"ARB",
	"OP",
	"FIL",
	"LTC",
	"BCH",
	"AAVE",
	"PENDLE",
	"ENA",
	"WIF",
	"PEPE",
	"TON",
	"DOT",
	"ATOM",
	"RUNE"
];
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function simulateUniverse(tick = 0) {
	mulberry32(20973 ^ tick % 997);
	return NAMES.map((base, i) => {
		const r = mulberry32((i + 1) * 997 + tick % 50);
		const price = (8 + r() * 200) * (base === "BTC" ? 400 : base === "ETH" ? 20 : 1);
		const funding = (r() - .42) * .0011;
		const change = (r() - .48) * 18;
		const imb = r() * 2 - 1;
		return {
			symbol: `${base}USDT`,
			contract: `${base}_USDT`,
			venue: "sim",
			lastPrice: price,
			markPrice: price * (1 + (r() - .5) * 4e-4),
			priceChangePct: change,
			quoteVolume: 2e6 + r() * 8e8,
			fundingRate: funding,
			nextFundingTime: null,
			oi: price * (1e3 + r() * 5e4),
			oiDeltaPct: (r() - .45) * .12,
			bookImbalance: imb * .6,
			longShortRatio: .7 + r() * 1.1,
			liqCluster: Math.abs(change) > 8 && Math.abs(funding) > 4e-4,
			liqNotional: Math.abs(change) > 8 ? price * 1e3 : 0
		};
	});
}
function simulatePacket(row, tick = 0) {
	const rand = mulberry32(row.symbol.split("").reduce((a, c) => a + c.charCodeAt(0), tick + 11));
	const price = row.lastPrice;
	const candles5 = walk(price, 100, .004, rand, 3e5);
	const candles15 = walk(price, 80, .007, rand, 9e5);
	const candles1h = walk(price, 60, .012, rand, 36e5);
	const buyBias = row.fundingRate < 0 ? .62 : row.fundingRate > 3e-4 ? .38 : .5;
	const trades = [];
	for (let i = 0; i < 180; i++) {
		const buy = rand() < buyBias;
		trades.push({
			p: price * (1 + (rand() - .5) * .0015),
			q: .2 + rand() * 4,
			m: !buy,
			T: Date.now() - (180 - i) * 1e3
		});
	}
	const book = (sign) => Array.from({ length: 12 }, (_, i) => [price * (1 + sign * (i + 1) * 15e-5), 1 + rand() * 20]);
	return {
		symbol: row.symbol,
		contract: row.contract,
		venue: "sim",
		lastPrice: price,
		fundingRate: row.fundingRate,
		fundingHistory: [{
			t: Date.now() - 288e5,
			rate: row.fundingRate * .4
		}, {
			t: Date.now(),
			rate: row.fundingRate
		}],
		oi: row.oi,
		oiDeltaPct: row.oiDeltaPct,
		longShortRatio: row.longShortRatio,
		liqCluster: row.liqCluster,
		liqNotional: row.liqNotional ?? 0,
		candles5,
		candles15,
		candles1h,
		trades,
		bids: book(-1),
		asks: book(1),
		headlines: [],
		spreadBps: 1.6,
		bookImbalance: row.bookImbalance ?? 0
	};
}
function walk(price, n, step, rand, barMs) {
	const out = [];
	let px = price * (1 - step * n * .15);
	const start = Date.now() - n * barMs;
	for (let i = 0; i < n; i++) {
		const drift = (price - px) * .04;
		const o = px;
		const move = drift + (rand() - .48) * price * step;
		const c = Math.max(price * .2, o + move);
		const h = Math.max(o, c) * (1 + rand() * step * .4);
		const l = Math.min(o, c) * (1 - rand() * step * .4);
		const near = Math.abs(c - price) / price < .01 || Math.abs(c - price * .985) / price < .008;
		out.push({
			t: start + i * barMs,
			o,
			h,
			l,
			c,
			v: (near ? 8 : 1) * (.5 + rand())
		});
		px = c;
	}
	out[out.length - 1].c = price;
	out[out.length - 1].h = Math.max(out[out.length - 1].h, price);
	out[out.length - 1].l = Math.min(out[out.length - 1].l, price);
	return out;
}
var UA = "VolumetricDesk/1.0";
async function getJson(url, ms = 8e3) {
	const res = await fetch(url, {
		signal: AbortSignal.timeout(ms),
		headers: {
			accept: "application/json",
			"user-agent": UA
		}
	});
	const text = await res.text();
	if (!res.ok) throw new Error(`${res.status} ${text.slice(0, 160)}`);
	return JSON.parse(text);
}
function num(v) {
	const n = typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN;
	return Number.isFinite(n) ? n : 0;
}
function asRecord(v) {
	return v && typeof v === "object" ? v : null;
}
var headlineCache = {
	at: 0,
	items: []
};
async function loadHeadlines() {
	if (Date.now() - headlineCache.at < 3e5 && headlineCache.items.length) return headlineCache.items;
	try {
		const res = await fetch("https://www.coindesk.com/arc/outboundfeeds/rss/", {
			signal: AbortSignal.timeout(3500),
			headers: {
				"user-agent": UA,
				accept: "application/rss+xml, application/xml, text/xml"
			}
		});
		if (!res.ok) return headlineCache.items;
		const titles = [...(await res.text()).matchAll(/<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/title>/g)].map((m) => m[1].replace(/&/g, "&").replace(/&#39;/g, "'").trim()).filter((t) => t && !/coindesk|rss/i.test(t)).slice(0, 8);
		if (titles.length) headlineCache = {
			at: Date.now(),
			items: titles
		};
		return titles.length ? titles : headlineCache.items;
	} catch {
		return headlineCache.items;
	}
}
function fromGateTicker(t) {
	const contract = String(t.contract ?? "");
	if (!contract.endsWith("_USDT")) return null;
	const last = num(t.last);
	if (!(last > 0)) return null;
	const bid = num(t.highest_bid);
	const ask = num(t.lowest_ask);
	const bidSz = num(t.highest_size);
	const askSz = num(t.lowest_size);
	const bookDenom = bidSz + askSz;
	const quanto = num(t.quanto_multiplier) || 1;
	const oiContracts = num(t.total_size);
	return {
		symbol: contract.replace("_", ""),
		contract,
		venue: "gate",
		lastPrice: last,
		markPrice: num(t.mark_price) || last,
		priceChangePct: num(t.change_percentage),
		quoteVolume: num(t.volume_24h_quote),
		fundingRate: num(t.funding_rate),
		nextFundingTime: null,
		oi: oiContracts > 0 ? oiContracts * quanto * last : null,
		oiDeltaPct: null,
		bookImbalance: bookDenom > 0 ? (bidSz - askSz) / bookDenom : bid > 0 && ask > 0 ? 0 : null,
		longShortRatio: null,
		liqCluster: false,
		liqNotional: null
	};
}
async function loadGateUniverse() {
	const raw = await getJson("https://api.gateio.ws/api/v4/futures/usdt/tickers", 12e3);
	if (!Array.isArray(raw)) throw new Error("Unexpected ticker payload");
	const rows = [];
	for (const item of raw) {
		const rec = asRecord(item);
		if (!rec) continue;
		const row = fromGateTicker(rec);
		if (row && row.quoteVolume > 0) rows.push(row);
	}
	if (!rows.length) throw new Error("No USDT perpetuals returned");
	return rows;
}
async function loadBinanceUniverse() {
	const [premium, tickers, info] = await Promise.all([
		getJson("https://fapi.binance.com/fapi/v1/premiumIndex", 6e3),
		getJson("https://fapi.binance.com/fapi/v1/ticker/24hr", 6e3),
		getJson("https://fapi.binance.com/fapi/v1/exchangeInfo", 6e3)
	]);
	const perp = /* @__PURE__ */ new Set();
	const infoRec = asRecord(info);
	const symbols = infoRec && Array.isArray(infoRec.symbols) ? infoRec.symbols : [];
	for (const item of symbols) {
		const s = asRecord(item);
		if (!s) continue;
		if (s.contractType === "PERPETUAL" && s.quoteAsset === "USDT" && s.status === "TRADING") perp.add(String(s.symbol));
	}
	const tickerMap = /* @__PURE__ */ new Map();
	if (Array.isArray(tickers)) for (const item of tickers) {
		const t = asRecord(item);
		if (t) tickerMap.set(String(t.symbol), t);
	}
	if (!Array.isArray(premium)) throw new Error("Bad premium index");
	const rows = [];
	for (const item of premium) {
		const p = asRecord(item);
		if (!p) continue;
		const symbol = String(p.symbol);
		if (!perp.has(symbol)) continue;
		const t = tickerMap.get(symbol);
		const last = num(t?.lastPrice) || num(p.markPrice);
		if (!(last > 0)) continue;
		rows.push({
			symbol,
			contract: symbol,
			venue: "binance",
			lastPrice: last,
			markPrice: num(p.markPrice) || last,
			priceChangePct: num(t?.priceChangePercent),
			quoteVolume: num(t?.quoteVolume),
			fundingRate: num(p.lastFundingRate),
			nextFundingTime: num(p.nextFundingTime) || null,
			oi: null,
			oiDeltaPct: null,
			bookImbalance: null,
			longShortRatio: null,
			liqCluster: false,
			liqNotional: null
		});
	}
	if (!rows.length) throw new Error("Binance universe empty");
	return rows;
}
var fetchUniverse_createServerFn_handler = createServerRpc({
	id: "d95d5001a40fb8b5829123c7963496e39b79e5fb73a69449e633ac8e1c27b7ba",
	name: "fetchUniverse",
	filename: "src/lib/desk/market.ts"
}, (opts) => fetchUniverse.__executeServer(opts));
var fetchUniverse = createServerFn({ method: "GET" }).handler(fetchUniverse_createServerFn_handler, async () => {
	const headlines = await loadHeadlines();
	const fetchedAt = Date.now();
	try {
		return {
			venue: "binance",
			note: "Live Binance USDT-M public data. Execution is paper only.",
			fetchedAt,
			headlines,
			rows: await loadBinanceUniverse()
		};
	} catch (binanceError) {
		const reason = binanceError instanceof Error ? binanceError.message : "unavailable";
		try {
			const rows = await loadGateUniverse();
			return {
				venue: "gate",
				note: `Binance USDT-M is blocked from this host (${reason.slice(0, 80)}). Live tape is the full Gate.io USDT perpetual universe — funding, open interest, liquidations, depth, and trades. Orders stay on the paper book.`,
				fetchedAt,
				headlines,
				rows
			};
		} catch (gateError) {
			const gateReason = gateError instanceof Error ? gateError.message : "unavailable";
			return {
				venue: "sim",
				note: `Live venues failed (${gateReason.slice(0, 80)}). Showing a simulated perp tape so the desk still deliberates. Nothing here is a real market.`,
				fetchedAt,
				headlines,
				rows: simulateUniverse(Math.floor(fetchedAt / 6e4)),
				error: gateReason
			};
		}
	}
});
function parseStats(symbol, raw) {
	if (!Array.isArray(raw) || raw.length < 2) return null;
	const rows = raw.map(asRecord).filter((r) => Boolean(r)).sort((a, b) => num(a.time) - num(b.time));
	if (rows.length < 2) return null;
	const oi0 = num(rows[0].open_interest);
	const oi1 = num(rows[rows.length - 1].open_interest);
	const oiUsd = num(rows[rows.length - 1].open_interest_usd);
	const delta = oi0 > 0 ? (oi1 - oi0) / oi0 : null;
	const liqs = rows.map((r) => num(r.long_liq_usd) + num(r.short_liq_usd) + num(r.long_liq_usd_new) + num(r.short_liq_usd_new));
	const recent = liqs.slice(-4).reduce((a, b) => a + b, 0);
	const med = median(liqs.filter((n) => n > 0));
	const liqCluster = recent > 0 && (med === 0 || recent > med * 2.5);
	const lsr = num(rows[rows.length - 1].lsr_account);
	return {
		symbol,
		oi: oiUsd > 0 ? oiUsd : null,
		oiDeltaPct: delta,
		longShortRatio: lsr > 0 ? lsr : null,
		liqCluster,
		liqNotional: recent
	};
}
var fetchEnrichment_createServerFn_handler = createServerRpc({
	id: "3be34c8782e8e708bd9c5a23bc4a81c2827fbbf2fb0757b99c69fa9558aacbb2",
	name: "fetchEnrichment",
	filename: "src/lib/desk/market.ts"
}, (opts) => fetchEnrichment.__executeServer(opts));
var fetchEnrichment = createServerFn({ method: "POST" }).validator((data) => {
	return { items: (Array.isArray(data?.items) ? data.items : []).filter((i) => typeof i?.contract === "string" && typeof i.symbol === "string").slice(0, 6).map((i) => ({
		symbol: String(i.symbol),
		contract: String(i.contract),
		venue: i.venue ?? "gate"
	})) };
}).handler(fetchEnrichment_createServerFn_handler, async ({ data }) => {
	return (await Promise.all(data.items.map(async (item) => {
		if (item.venue === "sim") return null;
		try {
			if (item.venue === "binance") {
				const hist = await getJson(`https://fapi.binance.com/futures/data/openInterestHist?symbol=${encodeURIComponent(item.symbol)}&period=15m&limit=20`, 7e3);
				if (!Array.isArray(hist) || hist.length < 2) return null;
				const ordered = hist.map(asRecord).filter((r) => Boolean(r));
				const a = num(ordered[0]?.sumOpenInterest);
				const b = num(ordered[ordered.length - 1]?.sumOpenInterest);
				const lsrRaw = await getJson(`https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=${encodeURIComponent(item.symbol)}&period=15m&limit=1`, 7e3).catch(() => null);
				const lsrRow = Array.isArray(lsrRaw) ? asRecord(lsrRaw[0]) : null;
				return {
					symbol: item.symbol,
					oi: b || null,
					oiDeltaPct: a > 0 ? (b - a) / a : null,
					longShortRatio: lsrRow ? num(lsrRow.longShortRatio) || null : null,
					liqCluster: false,
					liqNotional: 0
				};
			}
			const stats = await getJson(`https://api.gateio.ws/api/v4/futures/usdt/contract_stats?contract=${encodeURIComponent(item.contract)}&interval=15m&limit=16`, 7e3);
			return parseStats(item.symbol, stats);
		} catch {
			return null;
		}
	}))).filter((e) => Boolean(e));
});
function gateCandles(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		const c = asRecord(item);
		if (!c) return null;
		const candle = {
			t: num(c.t) > 1e10 ? num(c.t) : num(c.t) * 1e3,
			o: num(c.o),
			h: num(c.h),
			l: num(c.l),
			c: num(c.c),
			v: num(c.v) || num(c.sum)
		};
		return candle.c > 0 ? candle : null;
	}).filter((c) => Boolean(c)).sort((a, b) => a.t - b.t);
}
function binanceCandles(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		if (!Array.isArray(item)) return null;
		const candle = {
			t: num(item[0]),
			o: num(item[1]),
			h: num(item[2]),
			l: num(item[3]),
			c: num(item[4]),
			v: num(item[5])
		};
		return candle.c > 0 ? candle : null;
	}).filter((c) => Boolean(c));
}
var fetchPacket_createServerFn_handler = createServerRpc({
	id: "2469c55cdbfeb0d586daa9c4e62fbbde687b903e448afeea7840ffb55e0a165b",
	name: "fetchPacket",
	filename: "src/lib/desk/market.ts"
}, (opts) => fetchPacket.__executeServer(opts));
var fetchPacket = createServerFn({ method: "POST" }).validator((data) => {
	const symbol = String(data?.symbol ?? "").toUpperCase();
	const contract = String(data?.contract ?? "");
	const venue = data?.venue ?? "gate";
	if (!/^[A-Z0-9]{2,20}USDT$/.test(symbol)) throw new Error("Bad symbol");
	return {
		symbol,
		contract,
		venue,
		lastPrice: num(data?.lastPrice),
		fundingRate: num(data?.fundingRate)
	};
}).handler(fetchPacket_createServerFn_handler, async ({ data }) => {
	const headlines = await loadHeadlines();
	if (data.venue === "sim") {
		const row = simulateUniverse(Math.floor(Date.now() / 6e4)).find((r) => r.symbol === data.symbol);
		if (!row) throw new Error("Unknown simulated symbol");
		return {
			...simulatePacket(row, Math.floor(Date.now() / 6e4)),
			headlines
		};
	}
	if (data.venue === "binance") {
		const sym = encodeURIComponent(data.symbol);
		const [k5, k15, k1h, depth, trades, oiHist, lsr, funding] = await Promise.all([
			getJson(`https://fapi.binance.com/fapi/v1/klines?symbol=${sym}&interval=5m&limit=120`),
			getJson(`https://fapi.binance.com/fapi/v1/klines?symbol=${sym}&interval=15m&limit=80`),
			getJson(`https://fapi.binance.com/fapi/v1/klines?symbol=${sym}&interval=1h&limit=48`),
			getJson(`https://fapi.binance.com/fapi/v1/depth?symbol=${sym}&limit=20`),
			getJson(`https://fapi.binance.com/fapi/v1/aggTrades?symbol=${sym}&limit=400`),
			getJson(`https://fapi.binance.com/futures/data/openInterestHist?symbol=${sym}&period=15m&limit=20`).catch(() => []),
			getJson(`https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=${sym}&period=15m&limit=1`).catch(() => []),
			getJson(`https://fapi.binance.com/fapi/v1/fundingRate?symbol=${sym}&limit=8`).catch(() => [])
		]);
		const depthRec = asRecord(depth);
		const bids = Array.isArray(depthRec?.bids) ? depthRec.bids.map((l) => [num(Array.isArray(l) ? l[0] : 0), num(Array.isArray(l) ? l[1] : 0)]) : [];
		const asks = Array.isArray(depthRec?.asks) ? depthRec.asks.map((l) => [num(Array.isArray(l) ? l[0] : 0), num(Array.isArray(l) ? l[1] : 0)]) : [];
		const tape = Array.isArray(trades) ? trades.map((item) => {
			const t = asRecord(item);
			return {
				p: num(t?.p),
				q: num(t?.q),
				m: Boolean(t?.m),
				T: num(t?.T)
			};
		}) : [];
		const oiRows = Array.isArray(oiHist) ? oiHist.map(asRecord).filter((r) => Boolean(r)) : [];
		const oiA = num(oiRows[0]?.sumOpenInterest);
		const oiB = num(oiRows.at(-1)?.sumOpenInterest);
		const lsrRow = Array.isArray(lsr) ? asRecord(lsr[0]) : null;
		const last = tape.at(-1)?.p || data.lastPrice || asks[0]?.[0] || 0;
		const bid = bids[0]?.[0] ?? 0;
		const ask = asks[0]?.[0] ?? 0;
		const mid = bid && ask ? (bid + ask) / 2 : last;
		const bSum = bids.reduce((s, x) => s + x[1], 0);
		const aSum = asks.reduce((s, x) => s + x[1], 0);
		return {
			symbol: data.symbol,
			contract: data.symbol,
			venue: "binance",
			lastPrice: last,
			fundingRate: num(asRecord(Array.isArray(funding) ? funding.at(-1) : null)?.fundingRate),
			fundingHistory: Array.isArray(funding) ? funding.map((f) => {
				const r = asRecord(f);
				return {
					t: num(r?.fundingTime),
					rate: num(r?.fundingRate)
				};
			}) : [],
			oi: oiB || null,
			oiDeltaPct: oiA > 0 ? (oiB - oiA) / oiA : null,
			longShortRatio: lsrRow ? num(lsrRow.longShortRatio) || null : null,
			liqCluster: false,
			liqNotional: 0,
			candles5: binanceCandles(k5),
			candles15: binanceCandles(k15),
			candles1h: binanceCandles(k1h),
			trades: tape,
			bids,
			asks,
			headlines,
			spreadBps: mid > 0 && ask >= bid ? (ask - bid) / mid * 1e4 : 5,
			bookImbalance: bSum + aSum > 0 ? (bSum - aSum) / (bSum + aSum) : 0
		};
	}
	const c = encodeURIComponent(data.contract || data.symbol.replace("USDT", "_USDT"));
	const [k5, k15, k1h, book, trades, stats, funding] = await Promise.all([
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${c}&interval=5m&limit=120`),
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${c}&interval=15m&limit=80`),
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${c}&interval=1h&limit=48`),
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/order_book?contract=${c}&limit=20`),
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/trades?contract=${c}&limit=300`),
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/contract_stats?contract=${c}&interval=15m&limit=16`).catch(() => []),
		getJson(`https://api.gateio.ws/api/v4/futures/usdt/funding_rate?contract=${c}&limit=8`).catch(() => [])
	]);
	const bookRec = asRecord(book);
	const bids = Array.isArray(bookRec?.bids) ? bookRec.bids.map((l) => {
		const r = asRecord(l);
		return r ? [num(r.p), num(r.s)] : null;
	}).filter((x) => Boolean(x)) : [];
	const asks = Array.isArray(bookRec?.asks) ? bookRec.asks.map((l) => {
		const r = asRecord(l);
		return r ? [num(r.p), num(r.s)] : null;
	}).filter((x) => Boolean(x)) : [];
	const tape = Array.isArray(trades) ? trades.map((item) => {
		const t = asRecord(item);
		if (!t) return null;
		const size = num(t.size);
		return {
			p: num(t.price),
			q: Math.abs(size),
			m: size < 0,
			T: Math.round(num(t.create_time_ms) || num(t.create_time) * 1e3)
		};
	}).filter((t) => Boolean(t && t.p > 0 && t.q > 0)).sort((a, b) => a.T - b.T) : [];
	const enrichment = parseStats(data.symbol, stats);
	const fundRows = Array.isArray(funding) ? funding.map(asRecord).filter((r) => Boolean(r)).sort((a, b) => num(a.t) - num(b.t)) : [];
	const lastFund = fundRows.length ? num(fundRows[fundRows.length - 1].r) : data.fundingRate;
	const last = tape.at(-1)?.p || data.lastPrice || bids[0]?.[0] || 0;
	const bid = bids[0]?.[0] ?? 0;
	const ask = asks[0]?.[0] ?? 0;
	const mid = bid && ask ? (bid + ask) / 2 : last;
	const bSum = bids.reduce((s, x) => s + x[1], 0);
	const aSum = asks.reduce((s, x) => s + x[1], 0);
	return {
		symbol: data.symbol,
		contract: data.contract || data.symbol,
		venue: "gate",
		lastPrice: last,
		fundingRate: lastFund,
		fundingHistory: fundRows.map((r) => ({
			t: num(r.t) * 1e3,
			rate: num(r.r)
		})),
		oi: enrichment?.oi ?? null,
		oiDeltaPct: enrichment?.oiDeltaPct ?? null,
		longShortRatio: enrichment?.longShortRatio ?? null,
		liqCluster: enrichment?.liqCluster ?? false,
		liqNotional: enrichment?.liqNotional ?? 0,
		candles5: gateCandles(k5),
		candles15: gateCandles(k15),
		candles1h: gateCandles(k1h),
		trades: tape,
		bids,
		asks,
		headlines,
		spreadBps: mid > 0 && ask >= bid ? (ask - bid) / mid * 1e4 : 5,
		bookImbalance: bSum + aSum > 0 ? (bSum - aSum) / (bSum + aSum) : 0
	};
});
//#endregion
export { fetchEnrichment_createServerFn_handler, fetchPacket_createServerFn_handler, fetchUniverse_createServerFn_handler };
