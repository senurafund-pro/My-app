//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-L-XqyDsY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-PHB_hBLu.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-PHB_hBLu.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D-UgebU6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
